package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*
import kotlin.math.round

class ArcAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var center: PointF? = null  // arc center
    private var startPoint: PointF? = null
    private var startAngle: Float? = null  // start angle
    private var radius: Float? = null  // arc radius
    private var draggingPointer = false

    override fun beforeAction(): ArcAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false
                when
                {
                    // set center
                    center == null -> center = logicalTouchLocation

                    // set start point, start angle and radius
                    startAngle == null ->
                    {
                        startPoint = startPoint( center!!, logicalTouchLocation,
                                        if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul else -1f )
                        startAngle = (startPoint!! - center!!).arg()
                        radius = (startPoint!! - center!!).length()
                    }
                    else ->
                    {
                        // add arc to exercise
                        val endPoint = endPoint( center!!, startAngle!!, logicalTouchLocation,
                                                 Ctx.ctx.fixedAngles, radius!!,
                                                 if ( Ctx.ctx.useProtractor )
                                                     Ctx.ctx.protractorAngle
                                                 else
                                                     -1f )
                        var endAngle = (endPoint - center!!).arg()

                        if ( !Ctx.ctx.useProtractor && Ctx.ctx.protractorMode == 3 /*CONJUGATE*/ )  // swap start-end
                        {
                            val aux = endAngle
                            endAngle = startAngle!!
                            startAngle = aux
                        }

                        var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                                  color = Ctx.ctx.strokeColor,
                                                  cap = Ctx.ctx.cap,
                                                  join = Ctx.ctx.join,
                                                  dash = Ctx.ctx.dashPathEffect )

                        val arc = ExerciseShape(
                                "",
                                str(R.string.new_arc),
                                SerialPath().storeArc( center!!, radius!!, startAngle!!, endAngle ),
                                paint.asSerialPaint( Ctx.ctx.fillColor ) )
                        Ctx.ctx.exercise.add( arc )

                        val undoRedoArc = UndoRedoableNewShape( arc, Ctx.ctx.exercise.indexOf(arc),
                                                                str(R.string.new_arc) )

                        if ( Ctx.ctx.addExtremes || Ctx.ctx.addAuxiliaryShapes )
                        {
                            val transaction = object : UndoRedoTransaction() {
                                override fun getDescription() = "${str(R.string.new_arc)} ${if(Ctx.ctx.addExtremes) str(R.string.undoredo_and_extremes).format(2) else ""} ${if(Ctx.ctx.addAuxiliaryShapes) str(R.string.desc_auxiliary_shapes) else ""}"
                            }

                            transaction.add( undoRedoArc )

                            paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor)

                            // add center
                            if ( Ctx.ctx.addAuxiliaryShapes )
                            {
                                ExerciseShape( "",
                                               str(R.string.new_center_arc,
                                                Ctx.ctx.getHexColor(R.color.name_item),
                                                elvis(arc.name, "?")),
                                        SerialPath().storePoint(center!!),
                                        paint.asSerialPaint()).run {
                                    Ctx.ctx.exercise.add(this)
                                    transaction.add(UndoRedoableNewShape(
                                            this,
                                            Ctx.ctx.exercise.indexOf(this),
                                            "${str(R.string.new_point)} [center]"))
                                }
                            }
                            // add extremes
                            if ( Ctx.ctx.addExtremes )
                            {
                                for (extreme in arrayOf(startPoint!!, endPoint))
                                    ExerciseShape(
                                            "",
                                            str(R.string.desc_extremes2,
                                                    Ctx.ctx.getHexColor(R.color.name_item),
                                                    elvis(arc.name, "?")),
                                            SerialPath().storePoint(extreme),
                                            paint.asSerialPaint()).run {
                                        Ctx.ctx.exercise.add(this)
                                        transaction.add(UndoRedoableNewShape(
                                                this,
                                                Ctx.ctx.exercise.indexOf(this),
                                                "${str(R.string.new_point)} [extreme]"))
                                    }
                            }

                            Ctx.ctx.undoRedoManager.addItem( transaction )
                        }
                        // only the arc
                        else
                            Ctx.ctx.undoRedoManager.addItem( undoRedoArc )

                        // update or keep tool
                        Ctx.ctx.currentActionForCanvas.value =
                                (if ( Ctx.ctx.keepTool ) ArcAction() else defaultAction)
                                        .beforeAction()
                    }  // else
                }  // when
            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        center ?: return

        // draw circle centered in center
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( center!! ) )

        // draw segment center-{startPoint|touch}
        val extreme = startPoint ?: startPoint( center!!, logicalTouchLocation,
                                        if (Ctx.ctx.useRuler) Ctx.ctx.rulerDistanceMul else -1f )

        exCanvas.usePhysicalViewport {
            val c = it.toPhysicalViewport( center!! )
            val ex = it.toPhysicalViewport( extreme )
            it.canvas.drawLine( c.x, c.y, ex.x, ex.y, toolPaint )
        }

        startPoint ?: return

        // draw circle centered in start point
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( startPoint!! ) )

        // draw arc
        exCanvas.usePhysicalViewport {
            val endPoint = endPoint( center!!, startAngle!!, logicalTouchLocation,
                                     Ctx.ctx.fixedAngles, radius!!,
                                     if ( Ctx.ctx.useProtractor ) Ctx.ctx.protractorAngle else -1f )
            var endAngle = (endPoint - center!!).arg()
            var startAngle = startAngle!!
            if ( !Ctx.ctx.useProtractor && Ctx.ctx.protractorMode == 3 /*CONJUGATE*/ )
            {
                val aux = endAngle
                endAngle = startAngle
                startAngle = aux
            }

            it.canvas.drawPath( it.transformedShapeToPhysical(
                    SerialPath().storeArc( center!!, radius!!, startAngle!!, endAngle ) ).asPath(),
                    toolPaint )
            val extent = (if (endAngle >= startAngle!!) endAngle - startAngle!!
                          else PI2f + endAngle - startAngle!!).toDouble()
            val pEndPoint = it.toPhysicalViewport( endPoint )
            toolPaint.pathEffect = null
            it.canvas.drawText( "%.2fº".format( Math.toDegrees(extent) ),
                              pEndPoint.x + 4, pEndPoint.y + 4, toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            center == null -> str(R.string.status_arc2,Ctx.ctx.getHexColor(R.color.tool_item))

            startPoint == null ->
                str(R.string.status_arc3,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_arc4,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_arc1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

    private companion object
    {
        fun startPoint( center: PointF,
                        logicalTouchLocation: PointF,
                        rulerDist: Float = -1f ) = when {
                rulerDist < 0 -> logicalTouchLocation
                else -> center + (logicalTouchLocation - center).normalize() * rulerDist
            }

        fun endPoint(center: PointF,
                     startAngle: Float,
                     logicalTouchLocation: PointF,
                     fixedAngles: Boolean,
                     radius: Float,
                     protractorAngle: Float = -1f )
            : PointF
        {
            val v = logicalTouchLocation - center

            return when
            {
                protractorAngle >= 0f -> {
                    val ccw = logicalTouchLocation.relativeTo( PathSegment(
                                    center, 0f,
                                    center.pointRelativeToCenter(startAngle, radius), 1f ) ) < 0f
                    center.pointRelativeToCenter(
                    startAngle + (if ( ccw ) protractorAngle else - protractorAngle), radius )
                }
                fixedAngles -> center.pointRelativeToCenter( Math.toRadians( round( Math.toDegrees( (v.arg() - startAngle).toDouble() ) ) ).toFloat() + startAngle, radius )
                else -> center + v.normalize() * radius
            }
        }
    }

}  // class ArcAction
