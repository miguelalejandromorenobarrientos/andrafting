package masca.andrafting.ui.main.controllers

import android.net.Uri
import android.view.InputEvent
import android.view.View
import masca.andrafting.CREATE_SVG
import masca.andrafting.MAct
import masca.andrafting.createFile
import java.util.*

class SaveSvgAction: ActionListener
{
    override fun action(view: View?, evt: InputEvent?)
    {
        val rightNow: Calendar = Calendar.getInstance()
        val offset = rightNow.get(Calendar.ZONE_OFFSET) + rightNow.get(Calendar.DST_OFFSET)
        val sinceMid = (rightNow.timeInMillis + offset) / 1000 % 86400

        MAct.act.createFile( Uri.EMPTY,
                             "application/svg",
                             "vector$sinceMid.svg",
                             CREATE_SVG )
    }

}  // class SaveSvgAction
