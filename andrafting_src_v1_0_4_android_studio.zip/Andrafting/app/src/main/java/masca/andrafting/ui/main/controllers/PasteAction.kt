package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.ExerciseShape
import masca.andrafting.R
import masca.andrafting.UndoRedoableNewShape
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.UndoRedoTransaction
import masca.andrafting.ui.main.str

class PasteAction: ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        if ( Ctx.ctx.clipBoardShapes.isNullOrEmpty() )
        {
            Toast.makeText( Ctx.ctx, R.string.toast_empty_clipboard, Toast.LENGTH_SHORT ).show()
            return
        }

        // create transaction
        val transaction = object: UndoRedoTransaction() {
            override fun getDescription() = str(R.string.desc_paste,Ctx.ctx.clipBoardShapes!!.size)
        }

        val arrayShapes = arrayListOf<ExerciseShape>()
        Ctx.ctx.clipBoardShapes!!.forEach {
            val newShape = it.copy()
            arrayShapes.add( newShape )
            Ctx.ctx.exercise.add( newShape )
            transaction.add( UndoRedoableNewShape( newShape,
                                                   Ctx.ctx.exercise.indexOf( newShape ),
                                                   "COPIED SHAPE" ) )
        }

        Ctx.ctx.undoRedoManager.addItem( transaction )

        Ctx.ctx.selectedShapes = arrayShapes

        Toast.makeText( Ctx.ctx, "${transaction.size} ${str(R.string.toast_paste)}",
                        Toast.LENGTH_SHORT ).show()
    }

}  // class PasteAction
