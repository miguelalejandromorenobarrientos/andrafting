package masca.andrafting.ui.main.controllers

import android.graphics.DashPathEffect
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.*
import masca.andrafting.ui.main.*
import kotlin.math.max

class RulerAction : ActionListener
{
    private var start: PointF? = null
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var initSecondPoint = false

    override fun beforeAction(): RulerAction
    {
        setStatusBar(null)

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get activity and canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!!
                               else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                if ( start != null )
                    initSecondPoint = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                if ( start == null )  // first point
                {
                    start = logicalTouchLocation
                }
                else  // second point
                {
                    // measure length
                    val dist = start!!.distance( logicalTouchLocation )
                    Ctx.ctx.rulerLength = when {
                        isAdditive -> Ctx.ctx.rulerLength + dist
                        isSubtractive -> max( 0f, Ctx.ctx.rulerLength - dist )
                        else -> dist
                    }
                    Toast.makeText( MAct.act, "${str(R.string.btn_ruler)} ${Ctx.ctx.rulerLength}",
                                    Toast.LENGTH_SHORT ).show()

                    // update tool and switch
                    Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
                    MAct.act.binding.switchRuler.isChecked = true
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar(evt)

        exCanvas.invalidate()

        return true
    }

    private val isAdditive: Boolean
        get() = Ctx.ctx.rulerMode == RULER_MODE_ADDITIVE

    private val isSubtractive: Boolean
        get() = Ctx.ctx.rulerMode == RULER_MODE_SUBTRACTIVE

    private val modifiers
        get() = when { isAdditive -> "[+]"; isSubtractive -> "[-]"; else -> "" }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch start
        if ( start != null )
            drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )
        else
        {
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )
            return
        }

        if ( initSecondPoint )
        {
            // draw circle centered in touch end
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

            // draw segment
            val physicalStart = exCanvas.toPhysicalViewport( start!! )
            val physicalTouch = exCanvas.toPhysicalViewport( logicalTouchLocation )

            with( exCanvas.canvas )
            {
                save()
                setMatrix( exCanvas.matrixChangeOrientation )

                toolPaint.textSize = 12f
                drawText( start!!.distance(logicalTouchLocation).toString(),
                        physicalTouch.x + 5, physicalTouch.y - 14, toolPaint )

                toolPaint.pathEffect = DashPathEffect( floatArrayOf( 10f, 10f, 5f, 5f ), 0f )

                drawLine( physicalStart.x, physicalStart.y,
                          physicalTouch.x, physicalTouch.y,
                          toolPaint )

                restore()
            }
        }  // if
    }

    private fun setStatusBar( evt: MotionEvent? )
    {
        val txt = when {

            !this::logicalTouchLocation.isInitialized ->
                str(R.string.status_ruler2,Ctx.ctx.getHexColor(R.color.tool_item))

            start == null ->
                str(R.string.status_ruler3,Ctx.ctx.getHexColor(R.color.tool_item))

            start != null && evt?.action != MotionEvent.ACTION_MOVE ->
                str(R.string.status_ruler4,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_ruler5,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_ruler1,Ctx.ctx.getHexColor(R.color.tool_name))}$modifiers: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class RulerAction
