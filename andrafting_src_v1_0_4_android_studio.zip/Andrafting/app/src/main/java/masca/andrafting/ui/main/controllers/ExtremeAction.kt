package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.*

class ExtremeAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var shape: ExerciseShape? = null  // touched shape
    private var extremes: Pair<PointF,PointF>? = null

    override fun beforeAction(): ExtremeAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            in setOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE) ->
            {
                // get shape
                shape = exCanvas.getShapeAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation)  )
                // don't take account points bounds
                if ( shape?.path?.isPoint() == true )
                    shape = null

                // set extremes
                if ( shape != null )
                    extremes = shape!!.path.getPolySegments().first().start to
                               shape!!.path.getPolySegments().last().end
            }
            MotionEvent.ACTION_UP ->
            {
                if ( shape != null )
                {
                    if ( extremes!!.first == extremes!!.second )  // closed shape, no extremes
                        AlertDialog.Builder(MAct.act)
                                .setIcon( R.mipmap.error_icon )
                                .setTitle( R.string.btn_extremes )
                                .setMessage( R.string.warmsg_no_open_shape )
                                .show()
                    else
                    {
                        // add vertices to exercise
                        val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor )

                        val transaction = object: UndoRedoTransaction() {
                            override fun getDescription() = str(R.string.desc_extremes3)
                        }

                        for ( extreme in extremes!!.toList() )
                            ExerciseShape(
                                    "",
                                    str(R.string.desc_extremes2,
                                        Ctx.ctx.getHexColor(R.color.name_item),
                                        elvis(shape!!.name,"?")),
                                    SerialPath().storePoint( extreme ),
                                    paint.asSerialPaint() ).run {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                        this,
                                        Ctx.ctx.exercise.indexOf(this),
                                        "${str(R.string.new_point)} [extreme]" ) )
                            }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if (Ctx.ctx.keepTool) ExtremeAction() else defaultAction).beforeAction()
                }
            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation,
                         adjusted && shape != null )

        shape ?: return

        // draw shape and extremes
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( shape!!.path ).asPath(), toolPaint )
            toolPaint.strokeWidth = Ctx.ctx.pointWidth
            if ( extremes!!.first != extremes!!.second )
            {
                val pExtreme1 = it.toPhysicalViewport(extremes!!.first)
                val pExtreme2 = it.toPhysicalViewport(extremes!!.second)
                it.canvas.drawPoint(pExtreme1.x, pExtreme1.y, toolPaint)
                it.canvas.drawPoint(pExtreme2.x, pExtreme2.y, toolPaint)
            }
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            else -> str(R.string.status_extremes2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_extremes1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class ExtremeAction
