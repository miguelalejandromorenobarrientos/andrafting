package masca.andrafting.ui.main.controllers

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.PointF
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.*
import masca.andrafting.ui.main.controllers.PolygonAction.PolygonOpType.*
import kotlin.math.cos
import kotlin.math.sqrt

class PolygonAction : ActionListenerDoubleTap()
{
    private var points = mutableListOf<PointF>()
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF  // physical touch
    private var draggingPointer = false
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var updatedNode = true  // flag to hide cross-pointer after adding a node
    private var type = REGULAR  // type of polygon
    private var numSides = 5  // sides for regular polygon
    private var radiusMeasure = true  // use radius instead of side length
    private var center: PointF? = null  // center of the regular polygon

    private enum class PolygonOpType { REGULAR, POLYGON, POLYLINE }

    companion object
    {
        lateinit var self: PolygonAction
    }

    init
    {
        self = this
    }

    inner class PolygonDialog( context: Context ): Dialog( context ), View.OnClickListener
    {
        private val editSides: EditText by lazy { findViewById(R.id.edit_num_sides) }
        private val switchRadius: CheckBox by lazy { findViewById(R.id.switch_radius_measure) }

        override fun onCreate(savedInstanceState: Bundle?)
        {
            super.onCreate(savedInstanceState)

            setContentView( R.layout.polygon_dialog )

            findViewById<ImageButton>(R.id.btn_regular_polygon).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_polygon).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_polyline).setOnClickListener( this )
            findViewById<Button>(R.id.btn_dec_num_sides).setOnClickListener( this )
            findViewById<Button>(R.id.btn_inc_num_sides).setOnClickListener( this )

            editSides.setOnEditorActionListener { _, _, _ ->
                val imm: InputMethodManager? =
                    MAct.act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
                imm?.hideSoftInputFromWindow(MAct.act.currentFocus?.windowToken, 0)
                true
            }

            editSides.setText( numSides.toString() )

            switchRadius.setOnCheckedChangeListener { _, checked -> radiusMeasure = checked }

            setOnCancelListener {
                Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
            }

            window?.setBackgroundDrawable( ColorDrawable( Color.TRANSPARENT ) )
        }

        @SuppressLint("SetTextI18n")
        override fun onClick(v: View) {
            when( v.id ) {
                R.id.btn_regular_polygon -> {
                    try
                    {
                        numSides = editSides.text.toString().toInt()
                        if ( numSides !in 3..10000 )
                            throw NumberFormatException( str(R.string.errmsg_poly_sides) )
                        type = REGULAR
                    }
                    catch ( e: NumberFormatException )
                    {
                        AlertDialog.Builder(MAct.act)
                                .setTitle( str(R.string.new_polygon) )
                                .setIcon( R.mipmap.error_icon )
                                .setMessage( e.message?.html() )
                                .show()
                        return
                    }
                }
                R.id.btn_polygon -> type = POLYGON
                R.id.btn_polyline -> type = POLYLINE
                R.id.btn_dec_num_sides ->
                {
                    try
                    {
                        editSides.setText(
                                (editSides.text.toString().toInt() - 1).clip(3..10000).toString() )
                    }
                    catch (ignored: NumberFormatException) {}
                    return
                }
                R.id.btn_inc_num_sides ->
                {
                    try
                    {
                        editSides.setText(
                                (editSides.text.toString().toInt() + 1).clip(3..10000).toString() )
                    }
                    catch (ignored: NumberFormatException) {}
                    return
                }
                else -> cancel()
            }
            dismiss()
            setStatusBar()
        }

    }  // class PolygonDialog

    override fun beforeAction(): PolygonAction
    {
        PolygonDialogFragment().show( MAct.act.supportFragmentManager, "tag PolygonDialog" )

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        updatedNode = false

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!!
                               else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                when
                {
                    // regular polygon
                    type == REGULAR ->
                    {
                        // set center
                        if (center == null)
                            center = logicalTouchLocation
                        // add polygon
                        else
                        {
                            var radius = if (Ctx.ctx.useRuler) Ctx.ctx.rulerDistanceMul
                                         else (center!! - logicalTouchLocation).length()
                            if ( !radiusMeasure )
                                radius = radiusFromSide( radius, numSides )

                            var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                                      color = Ctx.ctx.strokeColor,
                                                      cap = Ctx.ctx.cap,
                                                      join = Ctx.ctx.join,
                                                      dash = Ctx.ctx.dashPathEffect )

                            val polygon = ExerciseShape(
                                    "",
                                    str(R.string.new_reg_polygon),
                                    SerialPath().storeRegularPolygon( center!!, radius, numSides ),
                                    paint.asSerialPaint( Ctx.ctx.fillColor ) ).apply {
                                Ctx.ctx.exercise.add(this)
                            }

                            val undoRedoPolygon = UndoRedoableNewShape(
                                                    polygon, Ctx.ctx.exercise.indexOf(polygon),
                                                    str(R.string.new_reg_polygon) )

                            if ( Ctx.ctx.addAuxiliaryShapes )
                            {
                                val transaction = object: UndoRedoTransaction() {
                                    override fun getDescription() = str(R.string.desc_polygon_tr)
                                }

                                transaction.add( undoRedoPolygon )

                                // add circumscribed circumference
                                ExerciseShape( "",
                                               str(R.string.new_circumscribed_polygon,
                                                   Ctx.ctx.getHexColor(R.color.tool_item),
                                                   elvis(polygon.name,"?") ),
                                               SerialPath().storeCircle( center!!, radius ),
                                               paint.asSerialPaint( Ctx.ctx.fillColor ) ).apply {
                                    Ctx.ctx.exercise.add(this)
                                    transaction.add( UndoRedoableNewShape( this,
                                                                Ctx.ctx.exercise.indexOf(this),
                                                                "CIRCUMSCRIBED CIRCUMFERENCE" ) )
                                }
                                // add center
                                paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                      color = Ctx.ctx.pointColor )

                                ExerciseShape( "",
                                               str(R.string.new_center_polygon,
                                                   Ctx.ctx.getHexColor(R.color.tool_item),
                                                   elvis(polygon.name,"?") ),
                                               SerialPath().storePoint( center!! ),
                                               paint.asSerialPaint() ).apply {
                                    Ctx.ctx.exercise.add(this)
                                    transaction.add( UndoRedoableNewShape( this,
                                                        Ctx.ctx.exercise.indexOf(this),
                                                        "CENTER OF CIRCUMSCRIBED CIRCUMFERENCE" ) )
                                }

                                Ctx.ctx.undoRedoManager.addItem( transaction )
                            }
                            else
                                Ctx.ctx.undoRedoManager.addItem( undoRedoPolygon )

                            // update or keep tool
                            Ctx.ctx.currentActionForCanvas.value =
                                (if (Ctx.ctx.keepTool) PolygonAction() else defaultAction)
                                    .beforeAction()
                        }
                    }
                    // finish polygon/polyline
                    checkDoubleTap() ->
                    {
                        // add polygon/polyline to exercise
                        var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                                  color = Ctx.ctx.strokeColor,
                                                  cap = Ctx.ctx.cap,
                                                  join = Ctx.ctx.join,
                                                  dash = Ctx.ctx.dashPathEffect )

                        val poly = if ( points.size > 1 )
                        {
                            if ( type == POLYGON )
                                SerialPath().storePolygon(*points.toTypedArray())
                            else
                                SerialPath().storePolyline(*points.toTypedArray())
                        }
                        else
                            SerialPath().storePoint( points[0] )
                        val shape = ExerciseShape( "",
                                str( if (type == POLYGON) R.string.new_polygon
                                     else R.string.new_polyline ),
                                poly,
                                paint.asSerialPaint() )

                        Ctx.ctx.exercise.add( shape )

                        // add extremes
                        if ( type == POLYLINE && Ctx.ctx.addExtremes )
                        {
                            val transaction = object: UndoRedoTransaction() {
                                override fun getDescription()
                                        = "${str(R.string.new_spline)} ${str(R.string.undoredo_and_extremes).format(2)}"
                            }

                            transaction.add( UndoRedoableNewShape(
                                    shape, Ctx.ctx.exercise.indexOf(shape), str(R.string.new_spline) ) )

                            paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor )

                            for ( extreme in arrayOf(points[0],points.last()) )
                                ExerciseShape(
                                        "",
                                        str(R.string.desc_extremes),
                                        SerialPath().storePoint(extreme),
                                        paint.asSerialPaint() ).run {
                                    Ctx.ctx.exercise.add(this)
                                    transaction.add( UndoRedoableNewShape(
                                            this,
                                            Ctx.ctx.exercise.indexOf(this),
                                            str(R.string.desc_extremes) ) )
                                }

                            Ctx.ctx.undoRedoManager.addItem( transaction )
                        }
                        // only the shape
                        else
                            Ctx.ctx.undoRedoManager.addItem( UndoRedoableNewShape(
                                shape, Ctx.ctx.exercise.indexOf(shape), str(R.string.new_spline) ) )

                        // update or keep tool
                        Ctx.ctx.currentActionForCanvas.value =
                            (if (Ctx.ctx.keepTool) PolygonAction() else defaultAction).beforeAction()
                    }

                    // new point for polygon/polyline
                    else ->
                    {
                        points.add( if (points.isEmpty())
                                        logicalTouchLocation
                                    else
                                        endPoint( points.last(),
                                                  logicalTouchLocation,
                                                  Ctx.ctx.fixedAngles,
                                                  if (Ctx.ctx.useRuler)
                                                      Ctx.ctx.rulerLength * Ctx.ctx.rulerMultiplier
                                                  else -1f ) )
                        updatedNode = true
                    }
                }  // when
            }  // case ACTION_UP
        }  // when event

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw regular polygon
        if ( type == REGULAR )
        {
            // draw touch
            if ( draggingPointer )
                drawCircleTouch(exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted)

            // draw polygon
            if ( center != null )
            {
                drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(center!!))

                var radius = if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                             else (logicalTouchLocation - center!!).length()
                if ( !radiusMeasure )
                    radius = radiusFromSide( radius, numSides )

                val regPoly = SerialPath().storeRegularPolygon( center!!, radius, numSides )
                exCanvas.usePhysicalViewport {
                        it.canvas.drawPath( it.transformedShapeToPhysical( regPoly ).asPath(),
                        toolPaint )
                }
            }
        }
        // draw polygon or polyline
        else
        {
            // draw nodes
            for (node in points)
                drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(node))

            // draw circle centered in touch
            if (!updatedNode)
                drawCircleTouch(exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted)

            if (points.isNotEmpty())
            {
                toolPaint.pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)

                // add touch point an convert to array
                val tmpPoints = points.toMutableList().apply {
                    add( endPoint( points.last(),
                                   logicalTouchLocation,
                                   Ctx.ctx.fixedAngles,
                                   if (Ctx.ctx.useRuler) Ctx.ctx.rulerDistanceMul else -1f ) ) }
                        .toTypedArray()

                // draw polygon
                exCanvas.usePhysicalViewport {
                    it.canvas.drawPath(
                            it.transformedShapeToPhysical( SerialPath().apply {
                                if ( type == POLYGON ) storePolygon(*tmpPoints)
                                else storePolyline(*tmpPoints) } )
                               .asPath(), toolPaint )
                }
            }
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            type == REGULAR && center == null ->
                str(R.string.status_polygon2,Ctx.ctx.getHexColor(R.color.tool_item))

            type == REGULAR ->
                str(R.string.status_polygon5,Ctx.ctx.getHexColor(R.color.tool_item))

            type != REGULAR && updatedNode ->
                str(R.string.status_polygon3,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_polygon4,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_polygon1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
            // update
            Ctx.ctx.statusBarMsg.value = txt
    }

    /**
     * Circumscribed Radius of a regular polygon from side length:
     * **<code>R = L / (sqrt(2) x sqrt(1-cos(2pi/N)))</code>**
     */
    private fun radiusFromSide( side: Float, sides: Int )
        = side / ( RT2 * sqrt( 1 - cos( PI2f / sides ) ) )

}  // class PolygonAction


class PolygonDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return PolygonAction.self.PolygonDialog( MAct.act )
    }
}  // class PolygonDialogFragment
