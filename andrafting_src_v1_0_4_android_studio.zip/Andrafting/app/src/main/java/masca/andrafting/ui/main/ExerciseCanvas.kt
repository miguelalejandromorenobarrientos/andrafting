package masca.andrafting.ui.main

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.core.graphics.PathSegment
import androidx.core.graphics.transform
import masca.andrafting.*
import masca.andrafting.ui.main.controllers.HandAction
import java.util.function.Predicate
import kotlin.math.*

@SuppressLint("ClickableViewAccessibility")
class ExerciseCanvas( context : Context, attr : AttributeSet ) : View( context, attr )
{
    private val activity by lazy { context as MainActivity }
    private lateinit var bitmap: Bitmap
    private lateinit var mCanvas: Canvas
    private val matrixIdentity = Matrix()
    val matrixChangeOrientation : Matrix
        get() = Matrix().apply {
                            preTranslate( 0f, height.toFloat() )
                            preScale( 1f, -1f ) }
    private val physicalViewport
        get() = RectF( 0f, 0f, width.toFloat(), height.toFloat() )
    var logicalViewport: RectF
        get() = Ctx.ctx.logicalViewport
        set( lv ) { Ctx.ctx.logicalViewport = lv }
    /** matrix to go from **logical to physical** viewport (don't take account orientation)*/
    private val transformMatrix : Matrix
        get() = logicalViewport.getTransformMatrix( physicalViewport )
    /** matrix to go from **physical to logical** viewport (don't take account orientation) */
    private val inverseTransformMatrix : Matrix
        get() = Matrix().apply { transformMatrix.invert( this ) }
    val scaleGestureDetector by lazy { ScaleCanvasGestureDetector( activity, this ) }

    val canvas: Canvas
        get() = mCanvas

    init
    {
        if ( !isInEditMode )
        {
            setOnTouchListener( CanvasTouchListener() )
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int)
    {
        super.onSizeChanged(w, h, oldw, oldh)

        // avoid failure on full screen when orientation change
        // (canvas and buffer image must be the same size as the parent view)
        bitmap = Bitmap.createBitmap( w, h, Bitmap.Config.ARGB_8888 )
        mCanvas = Canvas( bitmap )

        // reorient logical viewport on change orientation or adjust on resize
        logicalViewport = createRectFFromCenter( logicalViewport.center(),
                                                 logicalViewport.width(),
                                                 logicalViewport.width() * (h.toFloat() / w) )
    }

    override fun onDraw( canvas : Canvas )
    {
        val exercise = if ( isInEditMode ) testExercise else Ctx.ctx.exercise

        // adjust logical viewport factor to physical viewport factor
        val factor = physicalViewport.width() / physicalViewport.height()
        logicalViewport = createRectF( logicalViewport.left, logicalViewport.bottom,
                                       logicalViewport.width(),
                                       logicalViewport.width() / factor  )

        // DRAW exercise in bitmap
        val transform = transformMatrix
        mCanvas.setMatrix( transform )

        drawExercise( exercise, mCanvas, logicalViewport, Ctx.ctx.selectedShapes,
                      Ctx.ctx.scaleStrokeWidth, Ctx.ctx.showNames, drawBounds = true )

        // draw tool shapes
        activity.applicationContext.currentActionForCanvas.value.paintTool( this )

        // check max bitmap size
        if ( canvas.maximumBitmapHeight < bitmap.height || canvas.maximumBitmapWidth < bitmap.width )
        {
            Toast.makeText( context,"Can't render, too big image", Toast.LENGTH_LONG ).show()
            return
        }

        // invert canvas Y axis
        canvas.save()
        canvas.concat( matrixChangeOrientation )

        // draw current bitmap in canvas
        canvas.drawBitmap( bitmap, matrixIdentity, null )

        canvas.restore()

        // DRAW current frame if presentation mode
        if ( !Ctx.ctx.exercise.frameIndexAtEnd )
        {
            canvas.setMatrix( null )
            val paintFrame = defaultPaint(5f).apply {
                style = Paint.Style.FILL
                color = Color.WHITE
                textSize = 36f
                setShadowLayer( 1f, 1f, 1f, Color.BLACK )
            }
            val txt = "Frame ${Ctx.ctx.exercise.frameIndex + 1}/${Ctx.ctx.exercise.size}"
            canvas.drawText( txt,
                             width - paintFrame.measureText(txt) - 8f,
                             paintFrame.textSize + 2f,
                             paintFrame )
        }
    }

    private fun PointF.toLogicalViewport() =
                mapPoint( inverseTransformMatrix.apply { preConcat( matrixChangeOrientation ) } )

    @JvmName("toLogicalViewport1")
    fun toLogicalViewport( point : PointF ) = point.toLogicalViewport()

    private fun PointF.toPhysicalViewport() =
                mapPoint( transformMatrix.apply { postConcat( matrixChangeOrientation ) } )

    @JvmName( "toPhysicalViewport1" )
    fun toPhysicalViewport( point: PointF ) = point.toPhysicalViewport()

    private fun SerialPath.transformedShapeToPhysical() =
            copy().apply {
                transform( transformMatrix.apply { postConcat( matrixChangeOrientation ) } )
            }

    @JvmName( "transformedShapeToPhysical1" )
    fun transformedShapeToPhysical( serialPath: SerialPath ) =
                serialPath.transformedShapeToPhysical()

    fun getShapeAtCanvasPoint( point: PointF ): ExerciseShape?
    {
        val points = getShapesAtCanvasPoint( point )

        return if ( points.isEmpty() ) null else points.first()
    }

    private fun getShapesAtCanvasPoint(point: PointF,
                                       limit: Int = 1,
                                       accept: Predicate<ExerciseShape> = Predicate { true } )
        : MutableList<ExerciseShape>
    {
        val exercise = Ctx.ctx.exercise
        val lstShapes = mutableListOf<ExerciseShape>()

        for ( shape in exercise/*.reversed()*/.sortedWith { a, b ->
                // first, points, otherwise, reversed order of the index
                if ( a.path.isPoint() )
                {
                    if ( b.path.isPoint() )
                        -exercise.indexOf(a).compareTo(exercise.indexOf(b))
                    else
                        -1
                }
                else
                {
                    if ( b.path.isPoint() )
                        1
                    else
                        -exercise.indexOf(a).compareTo(exercise.indexOf(b))
                }
            })
        {
            if ( !accept.test(shape) )
                continue

            // set intersecting square touch-centered
            val rectSize = max( 8f, shape.paint.strokeWidth )
            val pointer = createRectFFromCenter( point, rectSize, rectSize )
            val logicalPointer = pointer.transform(
                            inverseTransformMatrix.apply { preConcat( matrixChangeOrientation ) } )

            // check whether square contains a shape that is a point
            if ( shape.path.isPoint()
                 && logicalPointer.contains( shape.path[0].coords[0], shape.path[0].coords[1] ) )
                lstShapes.add( shape )
            // no point
            else
            {
                // optimization, check whether pointer intersects shape bounds
                val shapeBounds = shape.getBounds()
                if ( !shapeBounds.intersects( logicalPointer.left, logicalPointer.top,
                                              logicalPointer.right, logicalPointer.bottom ) ) {
                    continue
                }
                // check square intersection with shape sides
                for ( segment in shape.path.getPolySegments() )
                    if (segmentRectangleIntersects(segment.start, segment.end, logicalPointer))
                    {
                        lstShapes.add(shape)
                        break
                    }
            }

            // check limit
            if ( lstShapes.size >= limit )
                return lstShapes
        }

        return lstShapes
    }

    /**
     * Get side of a shape in touch point
     * @param touchPoint physical touch
     * @return null if no side at touch point or shape and segment
     */
    fun getSideAtCanvasPoint( touchPoint: PointF ): Pair<ExerciseShape,PathSegment>?
    {
        val shape = getShapeAtCanvasPoint( touchPoint ) ?: return null
        if ( shape.path.isPoint() )
            return null

        // set intersecting square touch-centered
        val rectSize = max( 8f, shape.paint.strokeWidth )
        val pointer = createRectFFromCenter( touchPoint, rectSize, rectSize )
        val logicalPointer = pointer.transform(
                inverseTransformMatrix.apply { preConcat( matrixChangeOrientation ) } )

        // check first square intersection with shape sides
        for ( side in shape.path.getPolySegments() )
            if ( segmentRectangleIntersects( side.start, side.end, logicalPointer ) )
                return Pair(shape,side)

        return null  // shouldn't be reached
    }

    private fun adjustToVertexOrPoint(touchPoint: PointF ): PointF?
    {
        val shape = getShapeAtCanvasPoint( touchPoint ) ?: return null
        val vertices = shape.path.getPolyVertices()

        for ( vertex in vertices )
            if ( toPhysicalViewport(vertex).distance(touchPoint) < 8f )
                return vertex

        return null
    }

    private fun adjustToIntersection(touchPoint: PointF ): PointF?
    {
        // get two shapes at canvas point (or one for autointersections)
        val shapes = getShapesAtCanvasPoint( touchPoint, 2 )

        // no shapes
        if ( shapes.isEmpty() )
            return null

        // one or two shapes for intersecting
        val intersectionPoints = if ( shapes.size == 1 )
                                     shapes.first().autoIntersections()
                                 else
                                     shapes.first().intersections( shapes[1] )

        // return nearest intersection point to touch
        return intersectionPoints
                .filter { touchPoint.distance( toPhysicalViewport(it) ) <= 8f }
                .minByOrNull { it.distance( toLogicalViewport( touchPoint ) ) }
    }

    fun adjustToPoint( touchPoint: PointF ): PointF?
    {
        for ( shape in Ctx.ctx.exercise.shapes.reversed() )
            if ( shape.path.isPoint() )
            {
                val point = shape.path.getPolyVertices()[0]
                if ( touchPoint.distance( toPhysicalViewport( point ) ) <= 8f )
                    return point
            }

        return null
    }

    private fun adjustToExtremes(touchPoint: PointF ): PointF?
    {
        for ( shape in Ctx.ctx.exercise.shapes.reversed() )
        {
            val vertex = shape.path.getPolyVertices()
            if ( vertex.size >= 2 )
            {
                if ( touchPoint.distance(toPhysicalViewport( vertex.first() ) ) <= 8f )
                    return vertex.first()
                if ( touchPoint.distance(toPhysicalViewport( vertex.last() ) ) <= 8f )
                    return vertex.last()
            }
        }

        return null
    }

    override fun onGenericMotionEvent(event: MotionEvent?): Boolean
    {
        event ?: return super.onGenericMotionEvent(event)

        // Zoom with mouse wheel
        if ((event.source and InputDevice.SOURCE_CLASS_POINTER) != 0 )  {
            when (event.action) {
                MotionEvent.ACTION_SCROLL ->
                {
                    // get location in touch
                    val location = event.location()
                    val logicalTouchLocation = adjustToPoint(location)
                                               ?: toLogicalViewport(location)

                    val axisValue = event.getAxisValue( MotionEvent.AXIS_VSCROLL )

                    logicalViewport.zoom( logicalTouchLocation,
                                          if ( axisValue > 0f ) 1f / 1.1f.pow(axisValue)
                                          else 1.1f.pow(-axisValue),
                                          MIN_WIDTH, MAX_WIDTH )
                    invalidate()
                }
            }  // when
        }  // if

        return super.onGenericMotionEvent(event)
    }

    fun adjustTo( touchPoint: PointF ) = adjustToPoint( touchPoint )
                                         ?: adjustToExtremes( touchPoint )
                                         ?: adjustToIntersection( touchPoint )
                                         ?: adjustToVertexOrPoint( touchPoint )

    inner class CanvasTouchListener : OnTouchListener
    {
        override fun onTouch( v: View?, event: MotionEvent? ): Boolean
        {
            // perform action
            val returned = Ctx.ctx.currentActionForCanvas.value.action( v, event )
            if ( Ctx.ctx.currentActionForCanvas.value is HandAction )
                return true
            // zoom
            /*val consumed = */scaleGestureDetector.onTouchEvent( event )

            return returned as? Boolean ?: true
        }
    }

}  // class ExerciseCanvas


fun drawExercise( exercise: Exercise,
                  canvas: Canvas,
                  logicalViewport: RectF,
                  selected: ArrayList<ExerciseShape> = arrayListOf(),
                  scaleStroke: Boolean = true,
                  showNames: Boolean = true,
                  showArrows: Boolean = true,
                  drawBackground: Boolean = true,
                  drawBounds: Boolean = false )
{
    // BACKGROUND
    if ( drawBackground )
        drawBackground( exercise, canvas )

    // DRAW SHAPES

    // order shapes by index, but selected ones at the end
    val sortCriterion = { s1: ExerciseShape, s2: ExerciseShape ->
        val selS1 = selected.contains(s1)
        val selS2 = selected.contains(s2)
        val s1Idx = exercise.indexOf(s1)
        val s2Idx = exercise.indexOf(s2)
        if ( selS1 xor selS2 )  // one selected and one unselected
        {
            if ( selS1 ) 1 else -1
        }
        else  // two selected or two unselected
            s1Idx.compareTo( s2Idx )
    }

    // draw visible and selected shapes
    for ( shape in LinkedHashSet( exercise.shapesUntilFrameIndex.sortedWith( sortCriterion ) + selected ) )
    {
        val bounds = shape.getBounds()
        // optimization: draw only visible shapes
        if ( logicalViewport.intersects( bounds.left, bounds.top, bounds.right, bounds.bottom ) )
        {
            val shapePaint = if ( selected.contains( shape ) )
                                defaultPaint( shape.paint.strokeWidth + 4f,
                                    Color.argb( 0.5f, 1f, 0.1f, 0.1f ),
                                    Paint.Style.STROKE )
                             else
                                shape.paint.asPaint()

            // adjust stroke to scale
            shapePaint.strokeWidth = if ( scaleStroke )
                                         scaleStrokeWidth( shapePaint.strokeWidth,
                                                           logicalViewport.width(),
                                                           logicalViewport.height(),
                                                           canvas.width,
                                                           canvas.height )
                                     else
                                         fixedStrokeWidth( shapePaint.strokeWidth,
                                                           logicalViewport.width(),
                                                           logicalViewport.height(),
                                                           canvas.width,
                                                           canvas.height )

            // adjust dash path effect to stroke and scale
            if ( shapePaint.pathEffect is FriendlyDashPathEffect )
            {
                val fdpe = shapePaint.pathEffect as FriendlyDashPathEffect
                val meanRatio = geometricMeanRatio( logicalViewport.width(),
                                                    logicalViewport.height(),
                                                    canvas.width,
                                                    canvas.height )
                shapePaint.pathEffect = FriendlyDashPathEffect(
                        fdpe.intervals.copyOf().apply {
                            for ( i in 0 until size )
                                this[i] = this[i] * meanRatio + shapePaint.strokeWidth
                        })
            }

            // draw shape fill
            if ( !selected.contains(shape) && shape.paint.fill != null )
            {
                shapePaint.style = Paint.Style.FILL
                shapePaint.color = shape.paint.fill!!
                canvas.drawPath( shape.path.asPath(), shapePaint )
                shapePaint.style = Paint.Style.STROKE
                shapePaint.color = shape.paint.color
            }

            // draw shape stroke
            when
            {
                // arrows
                shape.isArrow -> if ( showArrows || selected.contains(shape) )
                                    drawArrow( shape, canvas, logicalViewport, shapePaint )
                // box comments
                shape.isComment -> drawComment( shape, canvas, logicalViewport, shapePaint )
                // normal shape
                else -> canvas.drawPath( shape.path.asPath(), shapePaint )
            }

            // draw names
            if ( showNames && shape.name.isNotBlank() )
            {
                canvas.save()

                // text position (logical/physical)
                val logicalNamePos = getShapeNamePosition( shape, bounds )
                val physicalNamePos = logicalNamePos.mapPoint(
                        logicalViewport,
                        RectF( 0f, 0f, canvas.width.toFloat(), canvas.height.toFloat() ) )

                // invert text
                canvas.setMatrix( Matrix().apply {
                    preTranslate( physicalNamePos.x, physicalNamePos.y )
                    preScale( 1f, -1f )
                    preTranslate( -physicalNamePos.x, -physicalNamePos.y )
                })

                // draw
                canvas.drawText( shape.name, physicalNamePos.x, physicalNamePos.y,
                                 defaultShapeNamePaint( shape ).apply {
                                     if ( selected.contains(shape) )
                                         color = Color.argb( 0.5f, 1f, 0.1f, 0.1f )
                                 })

                canvas.restore()
            }
        }
    }

    // draw bounds
    if ( drawBounds )
        canvas.drawRect( exercise.bounds, defaultPaint().apply { color = Color.argb( 0.1f, 0f, 0f, 0f ) } )
}

/**
 * Draw exercise background
 */
fun drawBackground( exercise: Exercise, canvas : Canvas )
{
    canvas.drawColor( exercise.background )
}

/** draw arrows */
fun drawArrow( shape: ExerciseShape, canvas: Canvas, logicalViewport: RectF, paint: Paint )
{
    val la = shape.path.getPolySegments().first().start
    val lb = shape.path.getPolySegments().last().end
    val ang = (lb - la).arg()
    val r = 36f  // suitable value for drafting-alike arrows
    val beta = PIf / 20f  // suitable value for drafting-alike arrows
    val transform = logicalViewport.getTransformMatrix(
                        RectF( 0f, 0f, canvas.width.toFloat(), canvas.height.toFloat() ) )
    val pa = la.mapPoint( transform )
    val pb = lb.mapPoint( transform )

    canvas.save()
    canvas.setMatrix( Matrix() )
    // draw arrow segment
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = shape.paint.strokeWidth
    if ( shape.paint.dashPathEffect != null )
        canvas.drawLineDashedFromPath( Path(), pa, pb, paint, shape.paint.dashPathEffect!! )
    else
        canvas.drawLine( pa.x, pa.y, pb.x, pb.y, paint )
    // draw main arrowhead
    paint.style = Paint.Style.FILL_AND_STROKE
    var arrowHead = Path().apply {
        moveTo( pb.x, pb.y )
        lineTo( pb.x + r*cos( ang + beta + PIf ), pb.y + r*sin( ang + beta + PIf ) )
        lineTo( pb.x + r*cos( ang - beta + PIf ), pb.y + r*sin( ang - beta + PIf ) )
        close()
    }
    canvas.drawPath( arrowHead, paint )
    // draw second arrowhead
    if ( shape.arrowType == ExerciseShape.Arrow.DOUBLE )
    {
        arrowHead = Path().apply {
            moveTo( pa.x, pa.y )
            lineTo( pa.x + r*cos( ang + beta ), pa.y + r*sin( ang + beta ) )
            lineTo( pa.x + r*cos( ang - beta ), pa.y + r*sin( ang - beta ) )
            close()
        }
        canvas.drawPath( arrowHead, paint )
    }

    canvas.restore()
}

/**
 * Draw comments
 * @param shape shape with description to draw
 * @param canvas current canvas
 * @param logicalViewport current logical viewport
 */
fun drawComment( shape: ExerciseShape, canvas: Canvas, logicalViewport: RectF, shapePaint: Paint )
{
    val rows = shape.description.split( "\n" )
    val position = PointF( shape.getBounds().left, shape.getBounds().bottom )
    val textBounds = multiLineTextBounds( rows, shape.paint.asPaint() )
    val textSize = getFontAdjustedToBounds( shape.getBounds(), textBounds, shape.paint.textSize )
    val paint = shapePaint.apply {
        this.textSize = textSize
        this.typeface = shape.paint.asPaint().typeface
        style = Paint.Style.FILL
    }

    // invert text and draw
    canvas.save()

    canvas.setMatrix( Matrix().apply {
        postTranslate( -position.x, -position.y )
        postScale( 1f, -1f )
        postTranslate( position.x, position.y )
        postConcat( logicalViewport.getTransformMatrix(
                            RectF( 0f, 0f, canvas.width.toFloat(), canvas.height.toFloat() ) ) )
    })

    canvas.drawText( position.x, position.y, rows, paint )

    canvas.restore()
}

fun getShapeNamePosition( shape: ExerciseShape, bounds: RectF = shape.getBounds() )
    = bounds.center() + PointF( shape.textPosition.first * bounds.width(),
                                shape.textPosition.second * bounds.height() )

fun pointerLocation( location: PointF,
                     exerciseCanvas: ExerciseCanvas,
                     tool: Int = MotionEvent.TOOL_TYPE_FINGER )
    = if ( tool != MotionEvent.TOOL_TYPE_FINGER )
          location
      else
          PointF( location.x,
                  location.y - convertPixelsToDp(exerciseCanvas.height/6, exerciseCanvas.context) )

/**
 * Get stroke width adjusted to final viewport size (canvas size) to keep the shape specified
 * stroke width
 */
fun scaleStrokeWidth( strokeWidth: Float,
                      logicalWidth: Float, logicalHeight: Float,
                      canvasWidth: Int, canvasHeight: Int )
    = strokeWidth * geometricMeanRatio( logicalWidth, logicalHeight, canvasWidth, canvasHeight )

/**
 * Get shape stroke but adjusted to a minimum for avoiding hiding lines (stroke will be scaled
 * by logical/canvas size ratio)
 */
fun fixedStrokeWidth( strokeWidth: Float,
                      logicalWidth: Float, logicalHeight: Float,
                      canvasWidth: Int, canvasHeight: Int )
    = max( strokeWidth,
           0.25f * geometricMeanRatio( logicalWidth, logicalHeight, canvasWidth, canvasHeight ) )

fun geometricMeanRatio( logicalWidth: Float, logicalHeight: Float,
                        canvasWidth: Int, canvasHeight: Int )
    = sqrt( logicalWidth / canvasWidth * logicalHeight / canvasHeight )

const val SHAPE_NAME_SIZE = 20f

const val MIN_WIDTH = 0.1f  // min logical width of viewport
const val MAX_WIDTH = 1E6f  // max logical width of viewport