package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.UndoRedoTransaction
import masca.andrafting.ui.main.str

class FusionAction: ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        if (Ctx.ctx.selectedShapes.size < 2 )
        {
            Toast.makeText( Ctx.ctx, R.string.warmsg_two_or_more_shapes, Toast.LENGTH_SHORT ).show()
            return
        }

        val shapes = Ctx.ctx.selectedShapes

        // create new shape by fusion
        val serialPath = SerialPath()
        for ( shape in shapes )
            serialPath += shape.path
        serialPath.forceUpdate()

        // add new shape and remove originals
        val transaction = object: UndoRedoTransaction() {
            override fun getDescription() = str(R.string.desc_fusion,shapes.size)
        }

        for ( shape in shapes )  // remove shapes
        {
            val index = Ctx.ctx.exercise.indexOf( shape )
            Ctx.ctx.exercise.remove( shape )
            transaction.add( UndoRedoableRemoveShape( shape, index,
                                                      "REMOVE ORIGINAL SHAPE ${shape.name}" ) )
        }

        val paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                  color = Ctx.ctx.strokeColor,
                                  cap = Ctx.ctx.cap,
                                  join = Ctx.ctx.join,
                                  dash = Ctx.ctx.dashPathEffect )

        ExerciseShape( "",
                       str(R.string.desc_fusion,shapes.joinToString(",") {
                           "<font color=%s><b>[${elvis(it.name,"?")}]</b></font>"
                           .format(Ctx.ctx.getHexColor(R.color.name_item)) }),
                       serialPath,
                       paint.asSerialPaint( Ctx.ctx.fillColor ) ).run {
            Ctx.ctx.exercise.add(this)
            transaction.add( UndoRedoableNewShape( this,
                                                   Ctx.ctx.exercise.indexOf(this),
                                                   "SHAPE BY FUSION" ) )
        }

        Ctx.ctx.undoRedoManager.addItem( transaction )

        MAct.act.getCanvas()?.invalidate()
    }

}  // class FusionAction
