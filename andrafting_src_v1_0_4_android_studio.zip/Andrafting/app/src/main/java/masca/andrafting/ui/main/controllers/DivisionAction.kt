package masca.andrafting.ui.main.controllers

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.PointF
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.*

class DivisionAction: ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    internal var shape: ExerciseShape? = null  // touched shape
    internal var divisions: Int? = null

    companion object
    {
        lateinit var self: DivisionAction
    }

    init
    {
        self = this
    }

    override fun beforeAction(): DivisionAction
    {
        setStatusBar()

        return this
    }

    override fun action(view: View?, evt: InputEvent?): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            in setOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE) ->
            {
                // get shape
                shape = exCanvas.getShapeAtCanvasPoint(
                        exCanvas.toPhysicalViewport(logicalTouchLocation)  )
                // don't take account points
                if ( shape?.path?.isPoint() == true )
                    shape = null
            }
            MotionEvent.ACTION_UP ->
            {
                if ( shape != null )
                {
                    if ( Ctx.ctx.useRuler )
                        addPointsToExercise( Ctx.ctx.rulerDistanceMul )
                    else
                        DivisionsDialogFragment()
                                    .show( MAct.act.supportFragmentManager, "tag DivisionsDialog" )
                }
            }
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    internal fun addPointsToExercise( lengthInterval: Float )
    {
        // add points to exercise
        val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                  color = Ctx.ctx.pointColor )

        val points = getPoints( lengthInterval )

        val transaction = object: UndoRedoTransaction() {
            override fun getDescription()
                    = str(R.string.desc_division_trans,points.size)
        }

        for ( pointD in points )
            ExerciseShape(
                    "",
                    str(R.string.desc_division,
                            Ctx.ctx.getHexColor(R.color.name_item),
                            elvis(shape!!.name,"?")),
                    SerialPath().storePoint( pointD ),
                    paint.asSerialPaint() ).run {
                Ctx.ctx.exercise.add(this)
                transaction.add( UndoRedoableNewShape(
                        this,
                        Ctx.ctx.exercise.indexOf(this),
                        "${str(R.string.new_point)} [divider]" ) )
            }

        Ctx.ctx.undoRedoManager.addItem( transaction )

        // update or keep tool
        Ctx.ctx.currentActionForCanvas.value =
            (if (Ctx.ctx.keepTool) DivisionAction() else defaultAction).beforeAction()
    }

    private fun getPoints( lengthInterval: Float ): List<PointF>
    {
        val points = mutableListOf<PointF>()

        val polyPath = shape!!.path.asPolyPath()

        var currentPoint = polyPath[0].getPoint(0)

        // if open shape, add start vertex
        if ( shape!!.path.isOpen() )
            points.add(currentPoint)

        var remainingDistance = lengthInterval

        // iterate over shape
        val iterator = polyPath.iterator()
        var segment = iterator.next()

        loop@do
        {
            if ( segment.type != SerialPath.SegmentType.MOVE )
            {
                val distance = currentPoint.distance( segment.getPoint(0) )
                if ( distance >= remainingDistance )
                {
                    val v = segment.getPoint(0) - currentPoint
                    val point = currentPoint + v.normalize() * remainingDistance
                    points.add( point )
                    currentPoint = point
                    remainingDistance = lengthInterval
                    continue@loop
                }
                else
                    remainingDistance -= distance
            }

            if ( !iterator.hasNext() )
                break@loop
            currentPoint = segment.getPoint(0)
            segment = iterator.next()
        }
        while ( true )

        // solve BU for missing last node
        if ( points.size < divisions ?: -1 && shape!!.path.isClosed() ||
             points.size <= divisions ?: -1 && shape!!.path.isOpen() )
            points.add( shape!!.path.getPolySegments().last().end )

        return points
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation,
                        adjusted && shape != null )

        shape ?: return

        // draw shape
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( shape!!.path ).asPath(), toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            else -> str(R.string.status_divisions2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_divisions1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class DivisionAction


class DivisionsDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return DivisionsDialog( MAct.act )
    }
}  // class DivisionsDialogFragment


class DivisionsDialog( context: Context): Dialog( context ), View.OnClickListener
{
    private val editDivisions: EditText by lazy { findViewById(R.id.edit_num_div) }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        setContentView( R.layout.divisions_dialog )

        findViewById<Button>(R.id.btn_ok).setOnClickListener( this )
        findViewById<Button>(R.id.btn_dec_num_div).setOnClickListener( this )
        findViewById<Button>(R.id.btn_inc_num_div).setOnClickListener( this )

        editDivisions.setOnEditorActionListener { _, _, _ ->
            val imm: InputMethodManager? =
                    MAct.act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
            imm?.hideSoftInputFromWindow(MAct.act.currentFocus?.windowToken, 0)
            true
        }

        editDivisions.setText( 2.toString() )

        setOnCancelListener {
            Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
        }

        window?.setBackgroundDrawable( ColorDrawable( Color.TRANSPARENT ) )
    }

    @SuppressLint("SetTextI18n")
    override fun onClick(v: View)
    {
        when( v.id )
        {
            R.id.btn_ok ->
            {
                DivisionAction.self.divisions = editDivisions.text.toString().toInt()
                if ( DivisionAction.self.divisions !in 2..10000 )
                    return
                DivisionAction.self.addPointsToExercise(
                        DivisionAction.self.shape!!.path.length / (DivisionAction.self.divisions!! + 1E-5f) )
            }
            R.id.btn_dec_num_div ->
            {
                try
                {
                    editDivisions.setText(
                            (editDivisions.text.toString().toInt() - 1).clip(2..1000).toString() )
                }
                catch (ignored: NumberFormatException) {}
                return
            }
            R.id.btn_inc_num_div ->
            {
                try
                {
                    editDivisions.setText(
                            (editDivisions.text.toString().toInt() + 1).clip(2..1000).toString() )
                }
                catch (ignored: NumberFormatException) {}
                return
            }
            else -> cancel()
        }
        dismiss()
    }

}  // class DivisionsDialog
