package masca.andrafting

/**
 * Observable property with subscribers
 */
open class ObserverProperty<T>(
        initialValue: T,
        private val observersList: MutableList<ObserverPropertyListener<T>> = mutableListOf() )
    : MutableList<ObserverProperty.ObserverPropertyListener<T>> by observersList
{
    var value = initialValue
        set( newValue )
        {
            val oldValue = field
            field = newValue
            for ( observer in observersList )
                observer.onChange( newValue, oldValue )
        }

    /**
     * Implement by subscribers
     */
    interface ObserverPropertyListener<T>
    {
        fun onChange( newValue: T, oldValue: T )
    }
}
