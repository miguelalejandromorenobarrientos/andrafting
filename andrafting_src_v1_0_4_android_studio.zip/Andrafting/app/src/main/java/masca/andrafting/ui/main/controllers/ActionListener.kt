package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import masca.andrafting.ui.main.ExerciseCanvas

interface ActionListener
{
    fun beforeAction(): ActionListener = this

    fun action( view: View? = null, evt: InputEvent? = null ) : Any?

    fun paintTool( exCanvas: ExerciseCanvas ) {}
}

abstract class ActionListenerDoubleTap: ActionListener
{
    protected var timestamp: Long = Long.MIN_VALUE
    protected var awaiting = false

    protected fun resetTimeStamp()
    {
        timestamp = System.currentTimeMillis()
        awaiting = true
    }

    protected fun checkDoubleTap()
        = if ( !awaiting )
          {
              resetTimeStamp()
              false
          }
          else
          {
              val accept = System.currentTimeMillis() - timestamp < DOUBLE_TAP_LAPSE
              if ( accept )
                  awaiting = false
              else
                  timestamp = System.currentTimeMillis()
              accept
          }
}

const val DOUBLE_TAP_LAPSE = 500  // ms
