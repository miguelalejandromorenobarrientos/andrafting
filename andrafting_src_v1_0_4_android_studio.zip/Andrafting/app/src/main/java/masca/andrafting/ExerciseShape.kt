package masca.andrafting

import android.graphics.PointF
import android.graphics.Region
import java.io.Serializable

data class ExerciseShape(
        var name: String = "",
        var description: String = "",
        var path: SerialPath = SerialPath(),
        var paint: SerialPaint = SerialPaint(),
        var textPosition: Pair<Float,Float> = Pair( 0.5f, 0.5f ) )
    : Serializable
{
    /** arrow types */
    enum class Arrow { NONE, SINGLE, DOUBLE }

    fun copy()
        = ExerciseShape( name, description, path.copy(), paint.copy(), textPosition.copy() ).also {
                it.isComment = isComment
                it.arrowType = arrowType
            }

    /**
     * Only equals for same reference, avoiding confusions with shapes with the same field values.
     * Another approximation would be adding a unique ID field
     */
    override fun equals( other: Any? ) = this === other

    /** flag for comments */
    var isComment = false

    /** type of arrow or NONE */
    var arrowType = Arrow.NONE

    /** flag for arrows */
    val isArrow
        get() = arrowType != Arrow.NONE

    /**
     * Bounds of the path
     * @param clip clip region
     * @return shape bounds
     */
    fun getBounds( clip: Region = Region( Integer.MIN_VALUE,
                                          Integer.MIN_VALUE,
                                          Integer.MAX_VALUE,
                                          Integer.MAX_VALUE ) )
        = getPathBounds( path.asPath(), clip )

    /*
     * Bounds in canvas taking account line width
     * @param matrix transform matrix to canvas
     * @return canvas (physical) bounds adjusted to width
     */
    /*fun getShapeCanvasBounds( matrix: Matrix ): RectF
    {
        return getBounds().transform( matrix ).apply {
            inset( -paint.strokeWidth / 2f, -paint.strokeWidth / 2f )
        }
    }*/

    /**
     * Get all intersection points between this shape and the other
     * @param other the other shape (order is irrelevant)
     * @return intersection points list
     */
    fun intersections( other: ExerciseShape ): MutableList<PointF>
    {
        val segments1 = path.getPolySegments()
        val segments2 = other.path.getPolySegments()

        val intersectionsList = mutableListOf<PointF>()

        for ( segment1 in segments1 )
            for ( segment2 in segments2 )
            {
                val intersection = segmentsIntersection( segment1.start, segment1.end,
                                                         segment2.start, segment2.end )
                if ( intersection != null )
                    intersectionsList.add( intersection )
            }

        return intersectionsList
    }

    fun autoIntersections(): MutableList<PointF>
    {
        val segments = path.getPolySegments()

        val intersectionsList = mutableListOf<PointF>()

        for ( i in 0 until segments.size - 1 )
            for ( j in i+1 until segments.size )
            {
                val intersection = segmentsIntersection( segments[i].start, segments[i].end,
                                                         segments[j].start, segments[j].end )
               if ( intersection != null )
                    intersectionsList.add( intersection )
            }

        return intersectionsList
    }

    override fun hashCode(): Int
    {
        var result = name.hashCode()
        result = 31 * result + description.hashCode()
        result = 31 * result + path.hashCode()
        result = 31 * result + paint.hashCode()
        result = 31 * result + textPosition.hashCode()
        result = 31 * result + isComment.hashCode()
        result = 31 * result + arrowType.hashCode()
        return result
    }

}  // class ExerciseShape
