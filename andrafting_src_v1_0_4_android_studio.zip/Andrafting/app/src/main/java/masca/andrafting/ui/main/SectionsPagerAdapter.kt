package masca.andrafting.ui.main

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import masca.andrafting.R

val TAB_TITLES = arrayOf(
    R.string.tab_text_1,
    R.string.tab_text_2
)

class SectionsPagerAdapter( fActivity : FragmentActivity )
    : FragmentStateAdapter(fActivity)
{
    override fun getItemCount() = 2

    override fun createFragment(position: Int) =
            when ( position )
            {
                0 -> CanvasFragment.newInstance()
                1 -> ToolsFragment.newInstance()
                else -> throw IllegalArgumentException()
            }
}
