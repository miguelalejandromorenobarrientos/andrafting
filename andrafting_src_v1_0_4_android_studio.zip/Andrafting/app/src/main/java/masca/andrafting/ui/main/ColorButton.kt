package masca.andrafting.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.AppCompatButton
import androidx.core.graphics.drawable.toBitmap
import masca.andrafting.R
import masca.andrafting.ui.main.Ctx


abstract class ColorButton( context : Context, attr : AttributeSet ) : AppCompatButton( context, attr )
{
    abstract fun getColor(): Int?
    private val paint by lazy { Paint( Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG ) }
    private val bounds by lazy { Rect() }
    private val mat by lazy { Matrix() }

    init
    {
        this.setBackgroundColor( Color.TRANSPARENT )
    }

    override fun onDraw( canvas: Canvas? )
    {
        val mCanvas = canvas ?: return

        val w = width.toFloat()
        val h = height.toFloat()

        paint.strokeWidth = 3f

        // draw background
        val radius = resources.getDimension(R.dimen.buttons_radius)

        getColor()?.run {
            val hStroke = paint.strokeWidth / 2f
            mCanvas.drawRoundRect( hStroke, hStroke, w - hStroke - 1, h - hStroke - 1, radius, radius,
                               paint.also { it.color = getColor()!!; it.style = Paint.Style.FILL })
            mCanvas.drawRoundRect( hStroke, hStroke, w - paint.strokeWidth, h - paint.strokeWidth,
                radius, radius, paint.also { it.color = Color.BLACK; it.style = Paint.Style.STROKE })
        } ?: run {
            mCanvas.drawBitmap( AppCompatResources.getDrawable(
                                                            Ctx.ctx, R.mipmap.no_color_pattern )!!
                                .toBitmap( w.toInt(), h.toInt() ),
                                mat,
                                null )
        }
        // draw text
        val txt = text.toString().uppercase()
        paint.textSize = textSize
        paint.getTextBounds( txt, 0, txt.length, bounds )

        val mat = mat.apply {
            val cx = w / 2f
            val cy = h / 2f
            postTranslate( -cx, -cy )
            postRotate( 45f )
            postTranslate( cx, cy )
        }

        mCanvas.setMatrix( mat )

        mat.reset()

        paint.run {
            setShadowLayer( 1f, 1f, 1f, Color.WHITE )
            color = Color.BLACK
            style = Paint.Style.FILL
            mCanvas.drawText( txt, (w - bounds.width()) / 2f, (h + bounds.height()) / 2f, this )
            setShadowLayer( 0f, 0f, 0f, Color.WHITE )  // remove shadow (radius 0)
        }

    }

}  // class ColorButton


class ColorButtonColor( context : Context, attr : AttributeSet ) : ColorButton( context, attr )
{
    override fun getColor() = if ( isInEditMode ) Color.BLACK else Ctx.ctx.strokeColor
}

class ColorButtonFill( context : Context, attr : AttributeSet ) : ColorButton( context, attr )
{
    override fun getColor() = if ( isInEditMode ) null else Ctx.ctx.fillColor
}

class ColorButtonPoint( context : Context, attr : AttributeSet ) : ColorButton( context, attr )
{
    override fun getColor() = if ( isInEditMode ) Color.DKGRAY else Ctx.ctx.pointColor
}

class ColorButtonBg( context : Context, attr : AttributeSet ) : ColorButton( context, attr )
{
    override fun getColor() = if ( isInEditMode ) Color.WHITE else Ctx.ctx.exercise.background
}
