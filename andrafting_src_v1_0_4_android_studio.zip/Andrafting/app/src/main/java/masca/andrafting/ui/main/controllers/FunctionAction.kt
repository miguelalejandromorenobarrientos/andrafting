package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Path
import android.graphics.PointF
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.util.Log
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import jme.Expresion
import jme.abstractas.Numero
import jme.excepciones.JMEInterruptedException
import jme.terminales.Vector
import jme.terminales.VectorEvaluado
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.pointerLocation
import masca.andrafting.ui.main.str
import java.util.*
import kotlin.math.abs
import kotlin.math.atan2

class FunctionAction: ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var start: PointF? = null
    private var graphPoints: Array<PointF?>? = null
    private var calculateThread: CalculateGraphThread? = null

    companion object
    {
        val isExpressionInitialized
            get() = Companion::expression.isInitialized
        lateinit var expression: Expresion
        var minExp = Expresion("-10")
        var min = -10.0
        var maxExp = Expresion("10")
        var max = 10.0
        var intervalsExp = Expresion("1000")
        var intervals = 1000
    }

    override fun beforeAction(): ActionListener
    {
        FunctionDialogFragment().show( MAct.act.supportFragmentManager, "tag FunctionDialog" )

        setStatusBar()

        return this
    }

    override fun action(view: View?, evt: InputEvent?): Any
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            MotionEvent.ACTION_MOVE -> {
                if( draggingPointer )
                {
                    calculateThread?.interrupt()
                    calculateThread = CalculateGraphThread( expression, min, max, intervals, 100L ).apply {
                        start()
                        join()
                    }
                }
            }
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( start == null )  // set start
                    start = logicalTouchLocation
                else  //
                {
                    calculateThread?.interrupt()
                    calculateThread = CalculateGraphThread( expression, min, max, intervals ).apply {
                        start()
                        join()
                    }

                    graphPoints?.run {

                        val end = endPoint( start!!, logicalTouchLocation, Ctx.ctx.fixedAngles,
                                            if( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul else -1f )

                        val paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                                  color = Ctx.ctx.strokeColor,
                                                  cap = Ctx.ctx.cap,
                                                  join = Ctx.ctx.join,
                                                  dash = Ctx.ctx.dashPathEffect )

                        val path = scaleGraph( graphToPath(), end ).approximateAsSerialPath()

                        val graph = ExerciseShape( calculateThread!!.func.toString(),
                                                   calculateThread!!.func.entrada(),
                                                   path,
                                                   paint.asSerialPaint( Ctx.ctx.fillColor ) )

                        Ctx.ctx.exercise.add( graph )

                        Ctx.ctx.undoRedoManager.addItem( UndoRedoableNewShape( graph,
                                Ctx.ctx.exercise.indexOf(graph), str(R.string.new_rectangle) ) )
                    } ?: run {
                        // time expired
                        AlertDialog.Builder(MAct.act)
                                .setIcon( R.mipmap.error_icon )
                                .setTitle( R.string.title_error_time_expired )
                                .setMessage( Ctx.ctx.getString(
                                    R.string.errmsg_function, calculateThread!!.func )
                                        .html() )
                                .setPositiveButton( R.string.btn_ok, null )
                                .show()
                    }

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if ( Ctx.ctx.keepTool ) FunctionAction() else defaultAction)
                                    .beforeAction()
                }
            }
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun graphToPath(): Path
    {
        val path = Path()
        val max = calculateThread!!.max
        val min = calculateThread!!.min
        val delta = max - min
        val intervals = calculateThread!!.intervals
        val limitAngle = Math.toRadians(89.9)

        for ( (idx,point) in graphPoints!!.withIndex() )
            point?.run {
                if ( abs(y) < delta )
                {
                    val isLine = idx > 0 && graphPoints!![idx - 1] != null &&
                                 abs(graphPoints!![idx - 1]!!.y) < delta &&
                                 abs( atan2( (graphPoints!![idx - 1]!!.y - y).toDouble(),
                                          delta / intervals) ) < limitAngle
                    if (isLine)
                        path.lineTo(x, y)
                    else
                        path.moveTo(x, y)
                }
            }

        return path
    }

    private fun scaleGraph( graph: Path, endPoint: PointF ): Path
    {
        val transform = Matrix().apply {
            postTranslate( -calculateThread!!.min.toFloat(), 0f )
            val length = ((endPoint - start!!).length() / ( calculateThread!!.max - calculateThread!!.min )).toFloat()
            postScale( length, length )
            postRotate( Math.toDegrees( (endPoint - start!!).arg().toDouble() ).toFloat() )
            postTranslate( start!!.x, start!!.y )
        }

        return graph.apply { transform( transform ) }
    }

    inner class CalculateGraphThread( val func: Expresion,
                                      val min: Double,  // min x
                                      val max: Double,  // max x
                                      val intervals: Int,
                                      private val delay: Long = 1000L )
        : Thread( "Calculate Graph Thread: $func" )
    {
        override fun run()
        {
            graphPoints = null

            graphPoints = arrayOfNulls( intervals + 1 )

            val timer = Timer( "Stop Calculus Timer" ).apply {
                schedule( object: TimerTask() {
                    override fun run()
                    {
                        if ( this@CalculateGraphThread.isAlive )
                        {
                            Log.i( "MYAPP interrupting thread", this@CalculateGraphThread.name )
                            this@CalculateGraphThread.interrupt()
                        }
                    }
                }, delay )
            }

            for ( i in 0..intervals )
            {
                val x = min + ( max - min ) * i / intervals
                func.setVariable( "x", x ).setVariable( "t", x )
                try
                {
                    val res = func.evaluar()
                    if ( res.esNumero() )  // explicit function
                    {
                        res as Numero
                        if ( !res.esComplejo() && !res.doble().isNaN() && res.doble().isFinite() )
                            graphPoints!![i] = PointF( x.toFloat(), res.doble().toFloat() )
                    }
                    else if ( res.esVectorReal() && (res as Vector).dimension() == 2 )  // parametric curve
                    {
                        res as VectorEvaluado
                        val (a,b) = res.componentes
                        graphPoints!![i] = PointF( (a as Numero).doble().toFloat(),
                                                   (b as Numero).doble().toFloat() )
                    }
                }
                catch ( ex: JMEInterruptedException )  // calculus interrupted
                {
                    graphPoints = null
                    timer.cancel()
                    return
                }
                catch ( ignored: Exception ) {}  // fails in single point, ignore point
            }  // for i

            timer.cancel()
        }  // run
    }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        start ?: return

        // draw start point
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        graphPoints?.run {

            val end = endPoint( start!!, logicalTouchLocation, Ctx.ctx.fixedAngles,
                                if( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul else -1f )

            val path = scaleGraph( graphToPath(), end ).approximateAsSerialPath()

            // draw function
            exCanvas.usePhysicalViewport {
                it.canvas.drawPath( it.transformedShapeToPhysical( path ).asPath(), toolPaint )
            }
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            start == null ->
                str(R.string.status_function2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_function3,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_function1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class FunctionAction


class FunctionDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return FunctionDialog( MAct.act )
    }
}  // class FunctionDialogFragment


/**
 * Dialog to enter explicit or parametric functions, and their x or parameter limits and intervals
 */
private class FunctionDialog( ctx: Context ): Dialog( ctx )
{
    private val editExpression: EditText by lazy { findViewById(R.id.edit_function) }
    private val editMin: EditText by lazy { findViewById(R.id.edit_min_x) }
    private val editMax: EditText by lazy { findViewById(R.id.edit_max_x) }
    private val editIntervals: EditText by lazy { findViewById(R.id.edit_intervals) }
    private val btnOk: Button by lazy { findViewById(R.id.btn_ok) }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.function_dialog)

        // documentation link
        findViewById<TextView>(R.id.txt_link).movementMethod = LinkMovementMethod.getInstance()

        // init from companion
        if (FunctionAction.isExpressionInitialized)
            editExpression.setText( FunctionAction.expression.entrada() )
        editMin.setText( FunctionAction.minExp.entrada() )
        editMax.setText( FunctionAction.maxExp.entrada() )
        editIntervals.setText( FunctionAction.intervalsExp.entrada() )

        btnOk.setOnClickListener {
            var edit: EditText = editExpression
            try
            {
                FunctionAction.expression = Expresion( edit.text.toString() )
                edit = editMin
                FunctionAction.minExp = Expresion( edit.text.toString() )
                FunctionAction.min = FunctionAction.minExp.evaluarANumero().doble()  // TODO no time expired control
                edit = editMax
                FunctionAction.maxExp = Expresion( edit.text.toString() )
                FunctionAction.max = FunctionAction.maxExp.evaluarANumero().doble()  // TODO no time expired control
                edit = editIntervals
                FunctionAction.intervalsExp = Expresion( edit.text.toString() )
                FunctionAction.intervals = FunctionAction.intervalsExp.evaluarANumero().ent()  // TODO no time expired control
            }
            catch ( ex: Exception )
            {
                AlertDialog.Builder( MAct.act )
                        .setIcon(R.mipmap.error_icon)
                        .setTitle( "JME error" )
                        .setMessage( "${edit.text}\n\n$ex" )
                        .setPositiveButton( R.string.btn_ok, null )
                        .show()
                return@setOnClickListener
            }
            dismiss()
        }

        //setCanceledOnTouchOutside(true)
        setOnCancelListener {
            Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
        }

        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

}  // class FunctionDialog
