package masca.andrafting

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.provider.DocumentsContract
import android.text.Html
import android.text.Spanned
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.widget.TextView
import androidx.core.graphics.PathSegment
import androidx.core.graphics.component1
import androidx.core.graphics.component2
import androidx.core.graphics.luminance
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.SHAPE_NAME_SIZE
import masca.andrafting.ui.main.UndoRedoable
import java.text.DecimalFormat
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min


private const val storeCircleK = 0.5522847f  // 4/3*tan(pi/8)

/**
 * Create RectF from upper-left corner and dimensions
 * @param x upper-left x  (left)
 * @param y upper-left y  (bottom, criterion of retarded)
 * @param width rectangle width
 * @param height rectangle height
 * @return new rectangle
 */
fun createRectF( x : Float = 0f, y : Float = 0f, width : Float, height : Float ) =
                                                    RectF( x, y - height, x + width, y )

fun createRectFFromCenter( center: PointF = PointF(), width: Float, height: Float ) =
                    createRectF( center.x - width / 2, center.y + height / 2, width, height )

/**
 * Create RectF from upper-left and bottom-right corners or upper-right and bottom-left corners
 * @param p a corner
 * @param q opposite corner
 * @return new rectangle
 */
fun createRectFFromCorners( p: PointF, q: PointF ) =
        RectF( min( p.x, q.x ), min( p.y, q.y ), max( p.x, q.x ), max( p.y, q.y ) )

fun RectF.center() = PointF( centerX(), centerY() )

fun SerialPath.storeCircle( center : PointF = PointF(), radius : Float = 1f ): SerialPath
{
    val K = radius * storeCircleK
    val (cx,cy) = center

    reset()
    moveTo( cx + radius, cy )
    cubicTo( cx + radius, cy + K, cx + K, cy + radius, cx, center.y + radius )
    cubicTo( cx - K, cy + radius, cx - radius, cy + K, cx - radius, cy )
    cubicTo( cx - radius, cy - K, cx - K, cy - radius, cx, cy - radius )
    cubicTo( cx + K, cy - radius, cx + radius, cy - K, cx + radius, cy )

    return this
}

fun SerialPath.storePoint( point : PointF ): SerialPath
{
    reset()
    moveTo( point )
    close()

    return this
}

fun SerialPath.storeSegment( start : PointF, end : PointF ) : SerialPath
{
    reset()
    moveTo( start )
    lineTo( end )

    return this
}

fun SerialPath.storeSegment( segment : PathSegment ) = storeSegment( segment.start, segment.end )

fun SerialPath.storeEllipse( center : PointF = PointF(),
                             xSemiAxis : Float,
                             ySemiAxis : Float ): SerialPath
{
    storeCircle( center, max( xSemiAxis, ySemiAxis ) )
    transform( Matrix().apply {
        postTranslate( -center.x, -center.y )
        postScale( if (xSemiAxis >= ySemiAxis) 1f else xSemiAxis / ySemiAxis,
                   if (xSemiAxis >= ySemiAxis) ySemiAxis / xSemiAxis else 1f )
        postTranslate( center.x, center.y )
    })

    return this
}

fun SerialPath.storeArc( center : PointF = PointF(), radius : Float,
                         startAng : Float, endAng : Float ) : SerialPath
{
    val start = ( startAng + PI2f ) % PI2f
    val end = ( endAng + PI2f ) % PI2f
    val extent = if ( end >= start ) end - start else PI2f + end - start
    val N = 60  // nº segments
    val step = extent / N
    val nodeList = mutableListOf<PointF>()

    for ( i in 0..N )
        center.pointRelativeToCenter( start + i * step, radius ).run {
            nodeList.add( this ) }

    storeSpline( *nodeList.toTypedArray() )

    return this
}

fun SerialPath.storeRectangle( left : Float, top : Float, right : Float, bottom : Float ): SerialPath
{
    reset()
    moveTo( left, top )
    lineTo( left, bottom )
    lineTo( right, bottom )
    lineTo( right, top )
    close()

    return this
}

fun SerialPath.storeRectangle( rect : RectF ) : SerialPath =
                                    storeRectangle( rect.left, rect.top, rect.right, rect.bottom )

fun SerialPath.storeTriangle( a: PointF, b: PointF, c: PointF ) = storePolygon( a, b, c )

fun SerialPath.storePolyline( vararg points : PointF ) : SerialPath
{
    reset()
    if ( points.isEmpty() )
        return this
    moveTo( points[0] )
    points.slice(1 until points.size).forEach { lineTo( it ) }

    return this
}

fun SerialPath.storePolygon( vararg points : PointF ) : SerialPath
{
    storePolyline( *points )
    close()

    return this
}

/**
 * Store regular polygon given the center and radius of the circumscribed circumference
 * @param center center of the circumscribed circumference
 * @param radius radius of the circumscribed circumference
 * @param sides nº sides
 * @return the own path
 */
fun SerialPath.storeRegularPolygon( center : PointF = PointF(),
                                    radius : Float = 1f,
                                    sides : Int ): SerialPath
{
    reset()
    moveTo( center.pointRelativeToCenter(-PIf / sides - HPIf, radius ) )
    for ( i in 1 until sides )
        lineTo( center.pointRelativeToCenter(i * PI2f / sides -PIf / sides - HPIf, radius ) )
    close()

    return this
}

/**
 * Create an spline from a set of points
 * Note: the spline doesn't adjust control points globally
 * and it doesn't follow any known algorithm (I think)
 * TODO improve the spline algorithm
 * @param points nodes (size > 1)
 * @return the spline as a serialPath
 */
fun SerialPath.storeSpline( vararg points: PointF ): SerialPath
{
    reset()
    moveTo( points[0] )

    val ratio = 3f
    val n = points.size
    val ctrlPoints = Array(n) { arrayOfNulls<PointF>(2) }

    //ctrlPoints[0][0] = null
    ctrlPoints[0][1] = points[0] + (points[1]-points[0])*(1f/ratio)
    ctrlPoints[n-1][0] = points[n-1] + (points[n-1]-points[n-2])*(-1f/ratio)
    //ctrlPoints[n-1][1] = null

    for ( i in 1 until n-1 )
    {
        val p = points.slice((i-1)..(i+1) )

        // calculate control points
        val v1 = p[1]-p[0]
        val v2 = p[2]-p[1]
        val ang1 = v1.arg()
        val ang2 = v2.arg()
        val ang = if ( abs(ang2 - ang1) > PIf ) (ang1 + ang2) / 2f + PIf else (ang1 + ang2) / 2f
        ctrlPoints[i][0] = p[1].pointRelativeToCenter( ang + PIf, v1.length() / ratio )
        ctrlPoints[i][1] = p[1].pointRelativeToCenter( ang, v2.length() / ratio )

        // add cubic arc to path
        cubicTo( ctrlPoints[i-1][1]!!, ctrlPoints[i][0]!!, p[1] )
    }
    // last cubic arc
    cubicTo( ctrlPoints[n-2][1]!!, ctrlPoints[n-1][0]!!, points[n-1] )

    return this
}

/**
 * Bounds of a path
 */
fun getPathBounds( path : Path, clip : Region ) : RectF
{
    val intBounds = Region().apply { setPath( path, clip ) }.bounds

    return if ( intBounds.width() > 10 && intBounds.height() > 10 ) {
        RectF(intBounds)
    }
    else {
        var fBounds = RectF()
        path.computeBounds( fBounds, true )
        fBounds = createRectF( fBounds.left, fBounds.bottom,
                               max( 0.001f, fBounds.width() ),
                               max( 0.001f, fBounds.height() ) )  // points, horizontal/vertical segments,...
        fBounds
    }
}

fun elvis( value: String?, def: String) = if (value == null || value.isEmpty()) def else value

fun MotionEvent.location() = PointF( x, y )

fun TextView.html( txt: String, flag: Int = Html.FROM_HTML_MODE_COMPACT ): CharSequence = run {
    text = txt.html( flag )
    text
}

fun String.html( flag: Int = Html.FROM_HTML_MODE_COMPACT ): Spanned = Html.fromHtml( this, flag )

fun defaultPaint( width: Float = 1f,
                  color: Int = Color.BLACK,
                  style: Paint.Style = Paint.Style.STROKE,
                  cap: Paint.Cap = Paint.Cap.ROUND,
                  join: Paint.Join = Paint.Join.ROUND,
                  dash: FloatArray? = null ) = Paint().apply {
    strokeWidth = width
    this.color = color
    this.style = style
    pathEffect = if ( dash != null ) FriendlyDashPathEffect( dash ) else null
    strokeCap = cap
    strokeJoin = join
    //strokeMiter = 1f
    isAntiAlias = true
    isDither = true
    textSize = SHAPE_NAME_SIZE
}

fun defaultToolPaint( background: Int, width: Float = 1f ) = defaultPaint( width ).apply {
    color = if ( Color.luminance( background ) < 0.5f ) Color.rgb( 0.5f, 0.5f, 1f )
            else Color.rgb( 0f, 0f, 0.5f )
    pathEffect = FriendlyDashPathEffect( floatArrayOf( 10f, 10f ), 0f )
}

fun defaultShapeNamePaint( shape: ExerciseShape ) = defaultPaint().apply {
    strokeWidth = SHAPE_NAME_SIZE
    color = shape.paint.color
    style = Paint.Style.FILL
    setShadowLayer( 1f, 1f, 1f,
                    if( color.luminance < 0.5f )
                        Color.argb( 0.75f, 1f, 1f, 1f )
                    else
                        Color.argb( 0.75f, 0f, 0f, 0f ) )
    typeface = Typeface.create("Arial", Typeface.BOLD )
}

/**
 * Rectangle vertex
 * @return array **{upper-left,upper-right,lower-right,lower-left}**
 */
fun RectF.vertex() = arrayOf( PointF( left, bottom ),
                              PointF( right, bottom ),
                              PointF( right, top ),
                              PointF( left, top ) )

fun FloatArray.toPoints2D() = if ( size and 1 == 0 ) mutableListOf<PointF>().also {
        for ( i in 0 until size step 2 )
            it.add( PointF( this[i], this[i+1] ) )
    }
    else throw IllegalArgumentException( "Array with odd elements" )

fun drawCircleTouch( exCanvas: ExerciseCanvas,
                     toolPaint: Paint,
                     cross: Boolean = true,
                     location: PointF,
                     logicalTouchLocation: PointF? = null,
                     adjusted: Boolean = false )
{
    // draw circle centered in touch
    with( exCanvas.canvas )
    {
        save()
        setMatrix( exCanvas.matrixChangeOrientation )

        val point = if ( adjusted ) exCanvas.toPhysicalViewport( logicalTouchLocation!! )
                    else location

        val oldDash = toolPaint.pathEffect
        toolPaint.pathEffect = null
        drawCircle( point.x, point.y, if ( adjusted ) 16f else 8f, toolPaint )
        val path = Path()
        if ( cross )
        {
            if ( adjusted )
                toolPaint.strokeWidth *= 2f
            drawLineDashedFromPath( path,
                                    PointF( 0f, point.y ),
                                    PointF( width.toFloat(), point.y ),
                                    toolPaint,
                                    floatArrayOf( 5f, 20f ) )
            drawLineDashedFromPath( path,
                                    PointF( point.x, 0f ),
                                    PointF( point.x, height.toFloat() ),
                                    toolPaint,
                                    floatArrayOf( 5f, 20f ) )
            if ( adjusted )
                toolPaint.strokeWidth /= 2f
        }
        toolPaint.pathEffect = oldDash

        restore()
    }
}

/**
 * @param path will be modified
 * @param paint won't be modified
 */
fun Canvas.drawLineDashedFromPath( path: Path,
                                   start: PointF,
                                   end: PointF,
                                   paint: Paint,
                                   pattern: FloatArray,
                                   phase: Float = 0f )
{
    with( path )
    {
        reset()
        moveTo(start.x, start.y)
        lineTo(end.x, end.y)
        val pathEffect = paint.pathEffect
        paint.pathEffect = DashPathEffect( pattern, phase )
        drawPath( this, paint )
        paint.pathEffect = pathEffect
    }
}

fun Context.getHexColor( id: Int ) = Integer.toHexString(getColor(id)).run {
    if (length > 6)  // remove alpha
        "#${this.substring(2)}"
    else
        "#$this"
}

// spread segment into extremes
operator fun PathSegment.component1() = start
operator fun PathSegment.component2() = end

inline fun ExerciseCanvas.usePhysicalViewport( action: (ExerciseCanvas) -> Unit ) = canvas.let {
        it.save()
        it.setMatrix( matrixChangeOrientation )
        action(this)
        it.restore()
}

fun convertPixelsToDp( px: Int, context: Context )
    = px / (context.resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)

fun format2( value: Float ) = DecimalFormat( "#.##" ).format(value)!!

fun multiLineTextBounds( rows: List<String>, paint: Paint ): RectF
{
    var maxWidth = 0f
    var maxHeight = 0f
    val bounds = Rect()

    rows.forEach {
        paint.getTextBounds( it, 0, it.length, bounds )
        maxWidth = max( maxWidth, bounds.width().toFloat() )
        maxHeight += paint.fontMetrics.run { descent - ascent }
    }

    return createRectF( width = maxWidth, height = maxHeight )
}

fun Canvas.drawText( x: Float, y: Float, rows: List<String>, paint: Paint )
{
    var yPos = y - paint.fontMetrics.descent
    val bounds = Rect()

    rows.forEach {
        paint.getTextBounds( it, 0, it.length, bounds )
        yPos += paint.fontMetrics.run { descent - ascent }
        drawText( it, x, yPos, paint )
    }
}

fun getFontAdjustedToBounds( bounds: RectF, sampleBounds: RectF, fontSize: Float ): Float
{
    val wRatio = bounds.width() / sampleBounds.width()
    val hRatio = bounds.height() / sampleBounds.height()
    val ratio = min( wRatio, hRatio )

    return fontSize * ratio
}

fun colorIntToColorHex6Or8( color: Int ) = Integer.toHexString(color).run {
    "#${if ( startsWith( "ff" ) ) substring(2) else this}"
}

// Request code for creating a document.
const val CREATE_FILE = 1

// Request code for selecting a document.
const val LOAD_FILE = 2

// Request code for creating a PNG
const val CREATE_SCREENSHOT = 3

// Request code for creating a SVG
const val CREATE_SVG = 4


fun Activity.createFile( pickerInitialUri: Uri, type: String, filename: String,
                         requestCode: Int = CREATE_FILE )
{
    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE)
        this.type = type
        putExtra( Intent.EXTRA_TITLE, filename )

        // Optionally, specify a URI for the directory that should be opened in
        // the system file picker before your app creates the document.
        putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri)
    }
    startActivityForResult( intent, requestCode )
}

fun Activity.openFile( pickerInitialUri: Uri, type: String ) {
    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE)
        this.type = type

        // Optionally, specify a URI for the file that should appear in the
        // system file picker when it loads.
        putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri)
    }

    startActivityForResult(intent, LOAD_FILE )
}


class UndoRedoableNewShape( private val shape: ExerciseShape,
                            private val index: Int,
                            private val description: String )
    : UndoRedoable()
{
    override fun undo()
    {
        Ctx.ctx.exercise.removeAt( index )
    }

    override fun redo()
    {
        Ctx.ctx.exercise.add( index, shape )
    }

    override fun getDescription() = description
}

class UndoRedoableRemoveShape( private val shape: ExerciseShape,
                               private val index: Int,
                               private val description: String )
    : UndoRedoable()
{
    override fun undo()
    {
        Ctx.ctx.exercise.add( index, shape )
    }

    override fun redo()
    {
        Ctx.ctx.exercise.removeAt( index )
    }

    override fun getDescription() = description
}

class UndoRedoableTransformShape( private val shape: ExerciseShape,
                                  private val description: String,
                                  private val transform: Matrix )
    : UndoRedoable()
{
    override fun undo()
    {
        shape.path.transform( Matrix().apply { transform.invert(this) } )
    }

    override fun redo()
    {
        shape.path.transform( transform )
    }

    override fun canUndo() = transform.invert( Matrix() )

    override fun getDescription() = description
}
