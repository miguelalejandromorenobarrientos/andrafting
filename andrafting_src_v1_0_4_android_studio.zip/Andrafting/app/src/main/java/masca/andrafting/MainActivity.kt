package masca.andrafting

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import masca.andrafting.databinding.ActivityMainBinding
import masca.andrafting.ui.main.*
import masca.andrafting.ui.main.controllers.*
import java.io.IOException
import kotlin.system.exitProcess


const val CANVAS_FRAGMENT_INDEX = 0

typealias MAct = MainActivity

class MainActivity : FragmentActivity()
{
    lateinit var binding: ActivityMainBinding


    ////////////////// RESOURCES //////////////////////
    private val tabIconArray = arrayOf(
        R.mipmap.canvas,
        R.mipmap.tools )


    /////////////////// LIFE-CYCLE ////////////////////

    override fun onAttachedToWindow()
    {
        super.onAttachedToWindow()

        // set static access to this activity
        act = this
    }

    override fun onResume()
    {
        super.onResume()

        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height = displayMetrics.heightPixels
        val width = displayMetrics.widthPixels

        Log.i( "MYAPP dp WIDTH", convertPixelToDp( width ).toString() )
        Log.i( "MYAPP dp HEIGHT", convertPixelToDp( height ).toString() )
    }

    override fun onCreate( savedInstanceState: Bundle? )
    {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Switch ruler
        with( binding.switchRuler )
        {
            isChecked = applicationContext.useRuler
            setOnCheckedChangeListener { _, isChecked -> applicationContext.useRuler = isChecked }
        }

        // Switch protractor
        with( binding.switchProtractor )
        {
            isChecked = applicationContext.useProtractor
            setOnCheckedChangeListener { _, isChecked -> applicationContext.useProtractor = isChecked }
        }

        // Switch Scale Stroke
        with ( binding.switchScaleStroke )
        {
            isChecked = applicationContext.scaleStrokeWidth
            setOnCheckedChangeListener { _, isChecked ->
                applicationContext.scaleStrokeWidth = isChecked
                // refresh canvas
                getCanvas()?.invalidate()
                updateShapeList()
            }
        }

        // Switch Show Names
        with( binding.switchShowNames )
        {
            isChecked = applicationContext.showNames
            setOnCheckedChangeListener { _, isChecked ->
                applicationContext.showNames = isChecked
                getCanvas()?.invalidate()
            }
        }

        // ViewPager2 config
        val viewPager = binding.viewPager
        with( viewPager )
        {
            adapter = SectionsPagerAdapter(this@MainActivity )
            registerOnPageChangeCallback( object: ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected( position: Int ) {
                    super.onPageSelected(position)

                    // avoid canvas scroll to next pages
                    isUserInputEnabled = position != CANVAS_FRAGMENT_INDEX

                    if ( position == CANVAS_FRAGMENT_INDEX )
                        updateShapeList()
                }
            })
        }  // with viewPager

        // subscriber for property 'currentActionForCanvas'
        applicationContext.currentActionForCanvas.add( object: ObserverProperty.ObserverPropertyListener<ActionListener> {
            @SuppressLint("ClickableViewAccessibility")
            override fun onChange( newValue: ActionListener, oldValue: ActionListener )
            {
                // set ToggleButtons state
                getCanvasFragment()?.binding?.run {
                    btnHand.isChecked = newValue is HandAction
                    btnSelection.isChecked = newValue is SelectionAction
                }
            }
        })

        // subscriber for property 'statusBarMsg'
        applicationContext.statusBarMsg.add( object: ObserverProperty.ObserverPropertyListener<CharSequence> {
            override fun onChange( newValue: CharSequence, oldValue: CharSequence )
            {
                getCanvasFragment()?.binding?.statusBar?.text = applicationContext.statusBarMsg.value
            }
        })

        // TABS
        val tabs: TabLayout = binding.tabs
        tabs.background = null
        tabs.isInlineLabel = true
        TabLayoutMediator( tabs, viewPager ) {
            tab, position -> with(tab) {
                                text = resources.getString( TAB_TITLES[position] )
                                setIcon( tabIconArray[position] )
                                tabLabelVisibility = TabLayout.TAB_LABEL_VISIBILITY_UNLABELED  // hide text (tooltip)
                            }
        }.attach()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean)
    {
        super.onWindowFocusChanged(hasFocus)

        if ( Ctx.ctx.fullUI /*&& hasFocus*/ )
            hideSystemUI()
        else
            showSystemUI()
    }

    fun hideSystemUI()
    {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                // Set the content to appear under the system bars so that the
                // content doesn't resize when the system bars hide and show.
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                // Hide the nav bar and status bar
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN)
    }

    fun showSystemUI()
    {
        window.decorView.systemUiVisibility = 0
    }

    override fun onBackPressed()
    {
        // cancel current tool except 'defaultAction' and NoAction
        getCanvasFragment()?.run {
            if ( applicationContext.currentActionForCanvas.value::class !in setOf(defaultAction::class,NoAction::class) )
            {
                applicationContext.currentActionForCanvas.value = defaultAction.beforeAction()
                getCanvas()?.invalidate()
                return
            }
        }

        // exit dialog if there are changes
        if (Ctx.ctx.undoRedoManager.canUndo() || Ctx.ctx.undoRedoManager.canRedo() )
            AlertDialog.Builder(this)
                .setIcon( R.mipmap.ic_launcher )
                .setTitle( R.string.title_exit )
                .setPositiveButton( R.string.btn_pause ) { _, _ -> moveTaskToBack(true) }
                .setNeutralButton( R.string.btn_exit_app ) { _, _ ->
                    finishAndRemoveTask()
                    exitProcess(0)
                }
                .setNegativeButton( R.string.btn_cancel, null )
                .show()
        else
            moveTaskToBack(true)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent? )
    {
        super.onActivityResult(requestCode, resultCode, resultData)

        if ( resultCode == RESULT_OK )
            when ( requestCode )
            {
                CREATE_FILE -> {
                    // write exercise
                    try
                    {
                        val uri = resultData?.data ?: throw IOException( "uri==null" )

                        SaveAction.save( uri )

                        Toast.makeText( MAct.act,
                                        str(R.string.toast_saved, uri.path ?: "").html(),
                                        Toast.LENGTH_SHORT).show()
                    }
                    catch ( ex: IOException)
                    {
                        Toast.makeText( MAct.act, ex.message, Toast.LENGTH_LONG ).show()
                    }
                }
                LOAD_FILE -> {
                    // load exercise
                    try
                    {
                        val uri = resultData?.data ?: throw IOException("uri==null")

                        OpenAction.load( uri )

                        // zoom all
                        ZoomAllAction().action()

                        // clear undo/redo manager
                        Ctx.ctx.undoRedoManager.clearAll()

                        Toast.makeText( MAct.act,
                                str(R.string.toast_loaded,uri.path ?: "").html(),
                                Toast.LENGTH_SHORT ).show()
                    }
                    catch( ex: IOException )
                    {
                        Toast.makeText( MAct.act, ex.message, Toast.LENGTH_LONG ).show()
                    }
                    catch( ex: ClassCastException )
                    {
                        Toast.makeText( MAct.act, "Not a ${str(R.string.app_name)} exercise",
                                        Toast.LENGTH_LONG ).show()
                    }
                }
                CREATE_SCREENSHOT -> {
                    try
                    {
                        SaveImageDialogFragment.uri =
                                                resultData?.data ?: throw IOException( "uri==null" )
                        SaveImageDialogFragment()
                                            .show( supportFragmentManager, "tag SaveImageDialog" )
                    }
                    catch ( ex: IOException )
                    {
                        Toast.makeText( MAct.act, ex.message, Toast.LENGTH_LONG ).show()
                    }
                }
                CREATE_SVG -> {
                    try
                    {
                        SaveSvgDialogFragment.uri =
                                                resultData?.data ?: throw IOException( "uri==null" )
                        SaveSvgDialogFragment()
                                            .show( supportFragmentManager, "tag SaveSvgDialog" )
                    }
                    catch ( ex: IOException )
                    {
                        Toast.makeText( MAct.act, ex.message, Toast.LENGTH_LONG ).show()
                    }
                }
            }  // when
    }  // onActivityResult


    ////////////////////// HELPERS ////////////////////

    private fun convertPixelToDp(pixel: Int): Int
    {
        val displayMetrics: DisplayMetrics = resources.displayMetrics
        return (pixel / displayMetrics.density).toInt()
    }

    override fun getApplicationContext() = super.getApplicationContext() as AppContext

    fun getCanvasFragment() =
        supportFragmentManager.findFragmentByTag("f$CANVAS_FRAGMENT_INDEX") as? CanvasFragment

    fun getShapeList() = getCanvasFragment()?.binding?.lstShapes

    private fun getShapeListAdapter() = getShapeList()?.adapter as? ShapeList.ShapeListAdapter

    fun updateShapeList() = getShapeListAdapter()?.notifyDataSetChanged()

    fun getCanvas() = getCanvasFragment()?.binding?.canvas

    companion object
    {
        /**
         * Self reference in static way
         */
        lateinit var act: MainActivity
    }

} // class MainActivity

val defaultAction: ActionListener
    get() = HandAction()
