package masca.andrafting.ui.main

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.util.AttributeSet
import android.view.*
import android.widget.*
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import kotlin.math.max
import kotlin.math.round

@SuppressLint("ClickableViewAccessibility")
class ShapeList( context: Context, attr: AttributeSet ) : ListView( context, attr )
{
    companion object
    {
        lateinit var self: ShapeList
        var position = -1
    }

    init
    {
        self = this

        if ( isInEditMode )
            adapter = ShapeListAdapter( context, R.layout.listitem_shape, Exercise() ).apply {
                exercise.add( ExerciseShape( "A", "Shape" ).apply { path.storeCircle() } )
                exercise.add( ExerciseShape( "Radius", "Other Shape" ).apply { path.storePoint( PointF() ) } )
            }

        setOnTouchListener { _, event -> gestureDetector.onTouchEvent(event) }
    }

    private val gestureDetector = GestureDetector( context,
        object: GestureDetector.SimpleOnGestureListener() {

            override fun onDoubleTap(e: MotionEvent?): Boolean
            {
                onLongPress(e)
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent?): Boolean
            {
                e ?: return false

                val position = pointToPosition( round(e.x).toInt(), round(e.y).toInt() )
                if ( position == INVALID_POSITION )
                    return false

                val shape = getItemAtPosition( position ) as ExerciseShape

                if ( Ctx.ctx.selectedShapes.contains( shape ) )
                    Ctx.ctx.selectedShapes.remove( shape )
                else
                    Ctx.ctx.selectedShapes.add( shape )

                ( adapter as ShapeListAdapter ).notifyDataSetInvalidated()
                MAct.act.getCanvas()?.invalidate()

                return true
            }

            override fun onLongPress(e: MotionEvent?)
            {
                e ?: return

                position = pointToPosition( round(e.x).toInt(), round(e.y).toInt() )

                if ( position != INVALID_POSITION )
                    ShapeDialogFragment().show( MAct.act.supportFragmentManager, "tag ShapeDialog" )
            }
    })

    internal fun createShapeDialog( position: Int ): AlertDialog
    {
        val shape = Ctx.ctx.exercise[position]

        val rootView =
            LayoutInflater.from(context).inflate(R.layout.shape_properties, null) as ViewGroup

        val editName = rootView.findViewById<EditText>( R.id.edit_name ).apply {
            setText( shape.name )
        }
        val editDesc = rootView.findViewById<EditText>( R.id.edit_description ).apply {
            setText( shape.description )
        }

        val dialog = AlertDialog.Builder( context )
            .setView( rootView )
            .setTitle( R.string.title_shape_properties )
            .setPositiveButton( R.string.btn_ok ) { _, _ ->
                shape.name = editName.text.toString()
                shape.description = editDesc.text.toString()
                (adapter as ShapeListAdapter).notifyDataSetChanged()
                MAct.act.getCanvas()?.invalidate()
            }
            .setNeutralButton( R.string.btn_details, null )
            .setNegativeButton( R.string.btn_cancel, null )
            .create().apply {
                    window?.setBackgroundDrawable(
                        AppCompatResources.getDrawable( MAct.act, R.drawable.dialog_background ) )
            }

        dialog.setOnShowListener {
            dialog.getButton( AlertDialog.BUTTON_NEUTRAL ).setOnClickListener {
                AlertDialog.Builder( context )
                    .setMessage( shape.toString() )
                    .setPositiveButton( R.string.btn_ok ) { dialog, _ -> dialog.dismiss() }
                    .show()
            }
        }

        return dialog
    }

    class ShapeListAdapter( context: Context,
                            private var resource: Int,
                            var exercise: Exercise )
        : ArrayAdapter<ExerciseShape>( context, resource, exercise )
    {
        override fun getView( position: Int, convertView: View?, parent: ViewGroup ): View
        {
            val holder: ViewHolder
            var rowView = convertView

            if ( rowView == null )
            {
                rowView = LayoutInflater.from( context ).inflate( resource, parent, false )
                holder = ViewHolder().apply {
                    index = rowView.findViewById( R.id.item_index )
                    thumbnail = rowView.findViewById( R.id.item_canvas )
                    txtViewName = rowView.findViewById( R.id.name )
                    txtViewDescription = rowView.findViewById( R.id.description )
                    rowView.tag = this
                }
            }
            else  // cached
                holder = rowView.tag as ViewHolder

            // set fields
            "${position+1}:".also { holder.index.text = it }
            holder.txtViewName.text = exercise[position].name
            holder.txtViewDescription.text = exercise[position].description.html()

            // set thumbnail
            val thumbnailSize = context.resources.getDimensionPixelSize( R.dimen.thumbnail_size )
            val img = Bitmap.createBitmap( thumbnailSize, thumbnailSize, Bitmap.Config.ARGB_8888 )
            val canvas = Canvas( img )
            val bounds = exercise.bounds
            val maxSize = max( bounds.width(), bounds.height() )
            val logicalViewport = createRectFFromCenter( bounds.center(), maxSize, maxSize )
            // TODO improve drawing
            canvas.setMatrix( logicalViewport.getTransformMatrix(
                                RectF( 0f, 0f, img.width.toFloat(), img.height.toFloat() ) ) )

            drawExercise( exercise, canvas, logicalViewport,
                          arrayListOf( exercise[position] ),
                      (context as? MainActivity)?.applicationContext?.scaleStrokeWidth ?: true,
                          showNames = false, showArrows = false )

            val imgInverted =
                        Bitmap.createBitmap( thumbnailSize, thumbnailSize, Bitmap.Config.ARGB_8888 )
            val canvasFinal = Canvas( imgInverted )

            canvasFinal.drawBitmap( img, Matrix().apply {
                    postScale( 1f, -1f )
                    postTranslate( 0f, img.height.toFloat() )
                }, null )

            holder.thumbnail.setImageBitmap( imgInverted )

            // background for edit mode, selected, unselected, and out of exercise preview
            if ( parent.isInEditMode )
                rowView!!.background = if ( (position and 1) == 0 )
                                        AppCompatResources.getDrawable( context, R.drawable.item_background_selected )
                                       else
                                        AppCompatResources.getDrawable( context, R.drawable.item_background )
            else
                rowView!!.background = when {
                    // selected and semi-hidden
                    exercise[position] in (context as MainActivity).applicationContext.selectedShapes && position > exercise.frameIndex ->
                        AppCompatResources.getDrawable( context, R.drawable.item_background_selected_hidden )
                    // selected
                    exercise[position] in (context as MainActivity).applicationContext.selectedShapes ->
                      AppCompatResources.getDrawable( context, R.drawable.item_background_selected )
                    // unselected
                    position <= exercise.frameIndex ->
                      AppCompatResources.getDrawable( context, R.drawable.item_background )
                    // not visible in exercise
                    else -> null
                }

            return rowView
        }

        class ViewHolder
        {
            lateinit var index: TextView
            lateinit var thumbnail: ImageView
            lateinit var txtViewName: TextView
            lateinit var txtViewDescription: TextView
        }

    }  // class ShapeListAdapter

}  // class ShapeList


class ShapeDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return ShapeList.self.createShapeDialog( ShapeList.position )
    }
}  // class ShapeDialogFragment
