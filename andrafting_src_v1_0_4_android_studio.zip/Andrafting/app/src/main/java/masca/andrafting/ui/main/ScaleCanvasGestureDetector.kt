package masca.andrafting.ui.main

import android.content.Context
import android.graphics.PointF
import android.view.ScaleGestureDetector
import masca.andrafting.zoom
import kotlin.math.pow

private const val EXPONENTIAL_ZOOM_FACTOR = 0.707106f  // 1/sqrt(2)

class ScaleCanvasGestureDetector constructor( val context: Context,
                                              val canvas: ExerciseCanvas
)
    : ScaleGestureDetector( context, object: ScaleGestureDetector.SimpleOnScaleGestureListener() {

        override fun onScale( detector: ScaleGestureDetector ): Boolean
        {
            with ( detector as ScaleCanvasGestureDetector)
            {
                /*isQuickScaleEnabled = false
                isStylusScaleEnabled = false*/
                /*Log.i( "MYAPP", scaleFactor.toString() )
                Log.i( "MYAPP", previousSpan.toString() )
                Log.i( "MYAPP", currentSpan.toString() )
                Log.i( "MYAPP stylus", isStylusScaleEnabled.toString() )
                Log.i( "MYAPP quick", isQuickScaleEnabled.toString() )*/
                if ( isInProgress )
                {
                    // get location in touch
                    val location = PointF(focusX, focusY)
                    val logicalTouchLocation = canvas.adjustToPoint(location)
                                               ?: canvas.toLogicalViewport(location)

                    canvas.logicalViewport.zoom(
                            logicalTouchLocation,
                            1f / scaleFactor.pow(EXPONENTIAL_ZOOM_FACTOR),
                            MIN_WIDTH, MAX_WIDTH
                    )

                    canvas.invalidate()
                }
            }

            return true
        }
    })
