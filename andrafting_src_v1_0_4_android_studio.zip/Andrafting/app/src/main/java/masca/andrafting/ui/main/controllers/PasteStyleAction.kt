package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.*

class PasteStyleAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var shape: ExerciseShape? = null  // touched shape

    override fun beforeAction(): PasteStyleAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            in setOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE) ->
            {
                // get shape
                shape = exCanvas.getShapeAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation)  )
            }
            MotionEvent.ACTION_UP ->
            {
                if ( shape != null )
                {
                    val isPoint = shape!!.path.isPoint()

                    with( Ctx.ctx )
                    {
                        val newPaint = if ( isPoint )
                                           defaultPaint( width = pointWidth,
                                                         color = pointColor )
                                       else
                                           defaultPaint( width = strokeWidth,
                                                         color = strokeColor,
                                                         cap = cap,
                                                         join = join,
                                                         dash = dashPathEffect )
                        val oldSerialPaint = shape!!.paint
                        shape!!.paint = newPaint.asSerialPaint( Ctx.ctx.fillColor ).apply {
                                textFamily = oldSerialPaint.textFamily
                                textStyle = oldSerialPaint.textStyle
                            }
                        undoRedoManager.addItem( UndoRedoableEditStyle(
                                                        shape!!,
                                                        str(R.string.desc_paste_style,
                                                            Ctx.ctx.getHexColor(R.color.name_item),
                                                            elvis(shape!!.name,"?")),
                                                        oldSerialPaint,
                                                        shape!!.paint ) )
                    }

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if (Ctx.ctx.keepTool) PasteStyleAction() else defaultAction).beforeAction()
                }
            }  // case ACTION_UP
        }  // when

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation,
                         adjusted && shape != null )

        shape ?: return

        // draw shape
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( shape!!.path ).asPath(), toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            else -> str(R.string.status_paste_style2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_paste_style1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class PasteStyleAction


class UndoRedoableEditStyle( private val shape: ExerciseShape,
                             private val description: String,
                             private val oldSerialPaint: SerialPaint,
                             private val newSerialPaint: SerialPaint )
    : UndoRedoable()
{
    override fun undo()
    {
        shape.paint = oldSerialPaint
    }

    override fun redo()
    {
        shape.paint = newSerialPaint
    }

    override fun getDescription() = description
}
