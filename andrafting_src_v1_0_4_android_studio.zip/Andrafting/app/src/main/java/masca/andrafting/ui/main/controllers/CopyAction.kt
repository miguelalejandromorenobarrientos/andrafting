package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.R
import masca.andrafting.elvis
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.str

class CopyAction: ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        if ( Ctx.ctx.selectedShapes.isEmpty() )
        {
            Toast.makeText( Ctx.ctx, R.string.warmsg_no_selected, Toast.LENGTH_SHORT ).show()
            return
        }

        // copied to clipboard
        Ctx.ctx.clipBoardShapes = Ctx.ctx.selectedShapes.map {
            it.copy().apply {
                name = "${str( R.string.copy_name )} ${elvis(it.name,"?")}"
            }
        }.toList()

        Toast.makeText( Ctx.ctx,
                        "${Ctx.ctx.clipBoardShapes!!.size} ${str(R.string.toast_shapes_copied)}",
                        Toast.LENGTH_SHORT ).show()
    }

}  // class CopyAction
