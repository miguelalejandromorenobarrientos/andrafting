package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import androidx.core.graphics.minus
import masca.andrafting.*
import masca.andrafting.ui.main.*
import kotlin.math.max

class MediatrixAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var sideInfo: Pair<ExerciseShape,PathSegment>? = null  // shape and side
    private var start: PointF? = null

    override fun beforeAction(): MediatrixAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if (sideInfo == null)  // set segment or side
                {
                    sideInfo = exCanvas.getSideAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation) )
                }
                else if ( start == null )  // set start of the bisectrix
                {
                    start = getMediatrix().start
                }
                else  // add mediatrix
                {
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val descHtml = str(R.string.new_mediatrix,
                                       Ctx.ctx.getHexColor(R.color.name_item),
                                       elvis(sideInfo!!.first.name,"?"))

                    val mediatrixSegment = getMediatrix()
                    val mediatrix = ExerciseShape( "",
                                                   descHtml,
                                                   SerialPath().storeSegment( mediatrixSegment ),
                                                   paint.asSerialPaint() )

                    Ctx.ctx.exercise.add( mediatrix )
                    val undoRedoNew = UndoRedoableNewShape( mediatrix,
                                                            Ctx.ctx.exercise.indexOf(mediatrix),
                                                            descHtml )

                    if ( Ctx.ctx.addExtremes )
                    {
                        val transaction = object: UndoRedoTransaction() {
                            override fun getDescription() =
                                    "$descHtml ${str(R.string.undoredo_and_extremes).format(2)}"
                        }

                        transaction.add( undoRedoNew )

                        paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                        for ( extreme in arrayOf(mediatrixSegment.start, mediatrixSegment.end) )
                            ExerciseShape( "",
                                           str(R.string.desc_extremes2,
                                           Ctx.ctx.getHexColor(R.color.name_item),
                                           elvis(mediatrix.name,"?") ),
                                    SerialPath().storePoint( extreme ),
                                    paint.asSerialPaint() ).run {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                                        this,
                                                        Ctx.ctx.exercise.indexOf(this),
                                                        "${str(R.string.new_point)} [extreme]" ) )
                            }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }
                    else
                        Ctx.ctx.undoRedoManager.addItem( undoRedoNew )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if ( Ctx.ctx.keepTool ) MediatrixAction() else defaultAction)
                                    .beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getMediatrix(): PathSegment
    {
        val side = sideInfo!!.second
        val vSide = side.end - side.start
        val nSide = vSide.normal()
        val midpoint = side.midpoint()
        val p1 = start ?: linesIntersection( logicalTouchLocation, logicalTouchLocation + vSide,
                                             midpoint, midpoint + nSide )!!
        val p2 = if( start == null )  // foot
                     midpoint
                 else  // intersection between perpendicular line to p1 and parallel line to touch
                     linesIntersection( logicalTouchLocation, logicalTouchLocation + vSide,
                                        midpoint, midpoint + nSide )

        return PathSegment( p1, 0f, p2 ?: p1, 1f )
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        val localSideInfo = sideInfo ?: exCanvas.getSideAtCanvasPoint(
                                    exCanvas.toPhysicalViewport(logicalTouchLocation) ) ?: return

        // draw side/segment
        toolPaint.strokeWidth = with( exCanvas ) {
            if (Ctx.ctx.scaleStrokeWidth)
                scaleStrokeWidth( max( 3f, localSideInfo.first.paint.strokeWidth ),
                        logicalViewport.width(),
                        logicalViewport.height(),
                        canvas.width,
                        canvas.height )
            else
                fixedStrokeWidth( max( 3f, localSideInfo.first.paint.strokeWidth ),
                        logicalViewport.width(),
                        logicalViewport.height(),
                        canvas.width,
                        canvas.height )
        }

        with( localSideInfo.second ) {
            exCanvas.canvas.drawLine( start.x, start.y, end.x, end.y, toolPaint )
        }

        sideInfo ?: return

        toolPaint.strokeWidth = 3f

        // draw side/segment
        exCanvas.usePhysicalViewport {
            val segment = sideInfo!!.second
            val a = it.toPhysicalViewport( segment.start )
            val b = it.toPhysicalViewport( segment.end )
            it.canvas.drawLine( a.x, a.y, b.x, b.y, toolPaint )
        }

        // draw circle centered in start
        if ( start != null )
            drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw mediatrix
        val perpendicular = getMediatrix()
        exCanvas.usePhysicalViewport {
            val a = it.toPhysicalViewport( perpendicular.start )
            val b = it.toPhysicalViewport( perpendicular.end )
            it.canvas.drawLine( a.x, a.y, b.x, b.y, toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            sideInfo == null ->
                str(R.string.status_mediatrix2,Ctx.ctx.getHexColor(R.color.tool_item))

            start == null ->
                str(R.string.status_mediatrix3,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_mediatrix4,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_mediatrix1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
            // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class MediatrixAction
