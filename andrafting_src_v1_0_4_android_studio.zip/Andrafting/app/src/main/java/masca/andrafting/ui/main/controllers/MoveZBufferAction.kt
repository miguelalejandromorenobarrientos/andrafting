package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import masca.andrafting.ExerciseShape
import masca.andrafting.MAct
import masca.andrafting.R
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.UndoRedoable
import masca.andrafting.ui.main.str

class MoveZBufferAction( private val up: Boolean ) : ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        if ( Ctx.ctx.selectedShapes.isEmpty() ) return

        val selected = Ctx.ctx.selectedShapes

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // order selected shapes by index
        val ordered = Ctx.ctx.selectedShapes.sortedBy { Ctx.ctx.exercise.indexOf(it) }

        // move selected shapes up or down
        if ( if (up) moveUp(ordered) else moveDown(ordered) )
            Ctx.ctx.undoRedoManager.addItem( UndoRedoableMoveZBuffer(ordered) )

        Ctx.ctx.selectedShapes = selected

        exCanvas.invalidate()
    }

    private fun moveUp( orderedShapes: List<ExerciseShape> ) = with( Ctx.ctx.exercise )
    {
        val maxIndex = indexOf( orderedShapes.last() )

        if ( maxIndex >= size - 1 )
            return false

        for ( shape in orderedShapes.reversed() )
        {
            val index = indexOf( shape )
            add( index + 2, shape )
            removeAt( index )
        }

        MAct.act.updateShapeList()
        MAct.act.getCanvasFragment()?.binding?.lstShapes?.smoothScrollToPosition(
                                                                indexOf( orderedShapes.last() ) )
        true
    }

    private fun moveDown( orderedShapes: List<ExerciseShape> ) = with( Ctx.ctx.exercise )
    {
        val minIndex = indexOf( orderedShapes.first() )

        if ( minIndex <= 0 )
            return false

        for ( shape in orderedShapes )
        {
            val index = indexOf( shape )
            add( index - 1, shape )
            removeAt( index + 1 )
        }

        MAct.act.updateShapeList()
        MAct.act.getCanvasFragment()?.binding?.lstShapes?.smoothScrollToPosition(
                                                                indexOf( orderedShapes.first() ) )
        true
    }

    private inner class UndoRedoableMoveZBuffer( val ordered: List<ExerciseShape> )
        : UndoRedoable()
    {
        override fun undo()
        {
            if (up) moveDown(ordered) else moveUp(ordered)
        }

        override fun redo()
        {
            if (up) moveUp(ordered) else moveDown(ordered)
        }

        override fun getDescription() =
                str(if(up) R.string.btn_move_up else R.string.btn_move_down) + " (${ordered.size} shapes)"
    }

}  // class MoveZBufferAction
