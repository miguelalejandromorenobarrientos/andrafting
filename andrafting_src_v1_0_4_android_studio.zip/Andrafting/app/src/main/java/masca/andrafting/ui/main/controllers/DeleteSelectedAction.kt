package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.MAct
import masca.andrafting.R
import masca.andrafting.UndoRedoableRemoveShape
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.UndoRedoTransaction
import masca.andrafting.ui.main.str

class DeleteSelectedAction() : ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        if ( Ctx.ctx.selectedShapes.isEmpty() )
        {
            Toast.makeText( Ctx.ctx, R.string.warmsg_no_selected, Toast.LENGTH_SHORT ).show()
            return
        }

        // create transaction
        val transaction = object: UndoRedoTransaction() {
            override fun getDescription() = str( R.string.undoredo_remove_shapes )
        }

        Ctx.ctx.selectedShapes.forEach {
            val index = Ctx.ctx.exercise.indexOf(it)
            Ctx.ctx.exercise.removeAt(index)
            transaction.add( UndoRedoableRemoveShape(
                    it, index, "${Ctx.ctx.getString(R.string.undoredo_remove_shape)} ${it.name}" ) )
        }

        Ctx.ctx.undoRedoManager.addItem( transaction )

        // clear selection
        Ctx.ctx.selectedShapes.clear()

        // update views
        MAct.act.getCanvas()?.invalidate()
        MAct.act.updateShapeList()
    }
}
