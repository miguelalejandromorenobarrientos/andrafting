package masca.andrafting.ui.main.controllers

import android.net.Uri
import android.view.InputEvent
import android.view.View
import masca.andrafting.Exercise
import masca.andrafting.MAct
import masca.andrafting.R
import masca.andrafting.openFile
import masca.andrafting.ui.main.BIN_TYPE
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ShapeList
import java.io.IOException
import java.io.ObjectInputStream

class OpenAction: ActionListener
{
    override fun action(view: View?, evt: InputEvent?)
    {
        MAct.act.openFile( Uri.EMPTY, BIN_TYPE )
    }

    companion object
    {
        @Throws(IOException::class,ClassCastException::class)
        fun load( uri: Uri )
        {
            // load exercise
            ObjectInputStream(Ctx.ctx.contentResolver.openInputStream(uri)).use {
                Ctx.ctx.exercise = it.readObject() as Exercise
            }

            Ctx.ctx.currentFile = uri
            Ctx.ctx.currentActionForCanvas.value = NoAction().beforeAction()
            MAct.act.getCanvas()?.invalidate()
            MAct.act.getShapeList()?.adapter = ShapeList.ShapeListAdapter( MAct.act,
                                                                           R.layout.listitem_shape,
                                                                           Ctx.ctx.exercise)
        }
    }

}  // class OpenAction
