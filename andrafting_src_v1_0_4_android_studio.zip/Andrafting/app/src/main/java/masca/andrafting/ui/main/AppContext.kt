package masca.andrafting.ui.main

import android.app.Application
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.net.Uri
import masca.andrafting.*
import masca.andrafting.ui.main.controllers.ActionListener
import masca.andrafting.ui.main.controllers.NoAction

typealias Ctx = AppContext

const val APPNAME = "Andrafting"
const val AUTHOR = "Miguel Alejandro Moreno Barrientos"

/**
 * Application context
 * @author Miguel Alejandro Moreno Barrientos, (C)2022
 */
class AppContext : Application()
{
    ////////////////////// FILES //////////////////////
    var currentFile: Uri? = null

    ///////////////// EXERCISE FIELDS /////////////////
    lateinit var exercise: Exercise
    lateinit var selectedShapes: ArrayList<ExerciseShape>
    var strokeColor = Color.BLACK
    var pointColor = Color.DKGRAY
    var fillColor: Int? = null
    var strokeWidth = 1f
    var pointWidth = 10f
    var cap = Paint.Cap.ROUND
    var join = Paint.Join.ROUND
    var dashPathEffect: FloatArray? = null
    var showNames = true

    ///////////////////// TOOLS ///////////////////////
    /** current user action in canvas */
    lateinit var currentActionForCanvas: ObserverProperty<ActionListener>
    // MODIFIERS
    /** Keep current tool when used */
    var keepTool = false
    /**
     * Use fixed angles for some tools
     */
    var fixedAngles = false
    /**
     * Add extremes to open shapes
     */
    var addExtremes = false
    /**
     * Add extra shapes to some shapes
     */
    var addAuxiliaryShapes = false
    /** remove status and notification bars */
    var fullUI = true
    // RULER
    /**
     * Current length measured by ruler
     */
    var rulerLength = 100f
    /**
     * Length multiplier
     */
    var rulerMultiplier = 1f
    /**
     * Ruler distance scaled by multiplier
     */
    val rulerDistanceMul
        get() = rulerLength * rulerMultiplier
    /**
     * Apply ruler length to some tools
     */
    var useRuler = false
    /**
     * Ruler mode (normal,additive,subtractive)
     */
    var rulerMode = RULER_MODE_NORMAL
    // PROTRACTOR
    var protractorStoredAngle = PIf / 2f
    /** adapted angle of the protractor (radians) */
    val protractorAngle: Float
        get() = ( PI2f + when( protractorMode ) {
            PROTRACTOR_MODE_NORMAL -> protractorStoredAngle
            PROTRACTOR_MODE_COMPLEMENTARY -> HPIf - protractorStoredAngle
            PROTRACTOR_MODE_SUPPLEMENTARY -> PIf - protractorStoredAngle
            PROTRACTOR_MODE_CONJUGATE -> PI2f - protractorStoredAngle
            else -> throw IllegalStateException()
        }) % PI2f
    var useProtractor = false
    var protractorMode = PROTRACTOR_MODE_NORMAL
    // COLOR HISTORY
    var colorHistory = mutableListOf(
        Color.BLACK,
        Color.WHITE,
        Color.RED,
        Color.GREEN,
        Color.BLUE,
        Color.YELLOW,
        Color.LTGRAY,
        Color.GRAY,
        Color.DKGRAY,
        Color.CYAN,
        Color.MAGENTA,
    )

    //////////////////// CANVAS ///////////////////////
    /** adjust shape stroke to canvas (in other case, width will be modified by zoom) */
    var scaleStrokeWidth = true
    /** adjust touch to near vertex or point in canvas */
    var adjustTo = true
    /** Message shown in the status bar */
    var statusBarMsg: ObserverProperty<CharSequence> = ObserverProperty( "" )
    /** logical viewport */
    var logicalViewport = RectF( -1000f, -1000f, 1000f, 1000f )

    ////////////////// COPY/PASTE ///////////////////
    var clipBoardShapes: List<ExerciseShape>? = null

    /////////////// UNDO/REDO MANAGER /////////////////
    /**
     * Undo/Redo manager
     */
    lateinit var undoRedoManager: UndoRedoManager


    /**
     * @return this application context casted
     */
    override fun getApplicationContext() = this

    override fun onCreate()
    {
        super.onCreate()

        // set static access to this context
        ctx = this

        // init exercise
        exercise = /*testExercise*/ Exercise()

        // Init Undo/Redo
        undoRedoManager = UndoRedoManager( 1000 ).apply {
            subscribers.add {
                // update undo/redo buttons
                MAct.act.getCanvasFragment()?.binding?.apply {
                    // update undo/redo buttons
                    btnUndo.isEnabled = canUndo()
                    btnUndo.contentDescription = undoRedoManager.undoDescription().html()
                    btnUndo.tooltipText = btnUndo.contentDescription
                    btnRedo.isEnabled = canRedo()
                    btnRedo.contentDescription = undoRedoManager.redoDescription().html()
                    btnRedo.tooltipText = btnRedo.contentDescription
                    selectedShapes = arrayListOf()
                }
                // update canvas and shape list
                MAct.act.getCanvas()?.invalidate()
                MAct.act.updateShapeList()
            }
        }

        // Init selected shapes list
        selectedShapes = arrayListOf()

        // Init canvas action
        currentActionForCanvas = ObserverProperty( NoAction().beforeAction() )

    }  // onCreate

    companion object
    {
        /**
         * Self reference in static way
         */
        lateinit var ctx: AppContext
    }

}  // class AppContext

val DEFAULT_COLOR_LIST_SIZE = Ctx.ctx.colorHistory.size

fun addColor( color: Int ) = with( Ctx.ctx.colorHistory ) {
    remove( color )
    if ( size >= 100 )
        removeAt(DEFAULT_COLOR_LIST_SIZE)
    add( color )
}

/**
 * Suitable method for getString
 */
fun str( id: Int, vararg args: Any ) = Ctx.ctx.getString( id, *args )

/**
 * Suitable method for getString
 */
fun str( id: Int ) = Ctx.ctx.getString(id)

/**
 * Angle step for fixed angles
 */
const val FIXED_ANGLES_INTERVAL = PIf / 12f  // 15º

val testExercise = Exercise("Test Exercise", "Testing object").apply {
    val shape1 = ExerciseShape("1", "rect")
    shape1.path.storeRectangle(createRectF(100f, 100f, 500f, 50f))
    shape1.paint.fill = Color.GREEN
    val shape2 = ExerciseShape("2", "rect", paint = defaultPaint(20f).asSerialPaint())
    shape2.path.storeRectangle(createRectF(200f, 400f, 100f, 200f))
    val shape3 = ExerciseShape("3", "rect")
    shape3.path.storeRectangle(createRectF(250f, 300f, 100f, 100f))
    val shape4 = ExerciseShape("point 4", "New Point")
    shape4.path.storePoint(PointF(10f, 10f))
    val shape5 = ExerciseShape("circumference 5", "New Circumference")
    shape5.path.storeCircle(PointF(), 500f)

    add(shape1)
    add(shape2)
    add(shape3)
    add(shape4)
    add(shape5)

    background = Color.rgb(1f, 1f, 1f)
}

// RULER CONST
const val RULER_MODE_NORMAL = 0
const val RULER_MODE_ADDITIVE = 1
const val RULER_MODE_SUBTRACTIVE = 2

// PROTRACTOR CONST
const val PROTRACTOR_MODE_NORMAL = 0
const val PROTRACTOR_MODE_COMPLEMENTARY = 1
const val PROTRACTOR_MODE_SUPPLEMENTARY = 2
const val PROTRACTOR_MODE_CONJUGATE = 3

// STROKE TYPES
val ARRAY_STROKES = arrayOf(
    "Solid" to null,
    "Dotted" to floatArrayOf(1f,2f),
    "Densely Dotted" to floatArrayOf(1f,1f),
    "Loosely Dotted" to floatArrayOf(1f,4f),
    "Dashed" to floatArrayOf(4f,6f),
    "Densely Dashed" to floatArrayOf(4f,4f),
    "Loosely Dashed" to floatArrayOf(4f,8f),
    "Dashdotted" to floatArrayOf(8f,6f,1f,6f),
    "Densely Dashdotted" to floatArrayOf(8f,4f,1f,4f),
    "Loosely Dashdotted" to floatArrayOf(8f,8f,1f,8f),
)

/** Binary type string */
const val BIN_TYPE = "application/octet-stream"
