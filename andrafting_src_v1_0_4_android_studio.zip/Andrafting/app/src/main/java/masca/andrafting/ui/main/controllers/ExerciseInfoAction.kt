package masca.andrafting.ui.main.controllers

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.InputEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.DialogFragment
import masca.andrafting.MAct
import masca.andrafting.R
import masca.andrafting.clip
import masca.andrafting.ui.main.Ctx

class ExerciseInfoAction: ActionListener
{
    override fun action(view: View?, evt: InputEvent?)
    {
        ExerciseInfoDialogFragment()
                .show( MAct.act.supportFragmentManager, "tag ExerciseInfoDialog" )
    }
}  // class ExerciseInfoAction


class ExerciseInfoDialogFragment: DialogFragment()
{
    @SuppressLint("SetTextI18n")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        // create dialog
        val root = LayoutInflater.from(Ctx.ctx).inflate( R.layout.exercise_info_dialog, null )

        val editTitle = root.findViewById<EditText>(R.id.edit_exercise_title).apply {
            setText( Ctx.ctx.exercise.title )
        }
        val editDesc = root.findViewById<EditText>(R.id.edit_exercise_description).apply {
            setText( Ctx.ctx.exercise.description )
        }
        val editStartFrame = root.findViewById<EditText>(R.id.edit_start_frame).apply {
            setText( (Ctx.ctx.exercise.startFrameIndex + 1).toString() )
        }
        root.findViewById<Button>(R.id.btn_inc_start_frame).apply {
            setOnClickListener {
                val value = editStartFrame.text.toString().toInt() - 1
                if (value < Ctx.ctx.exercise.size - 1)
                    editStartFrame.setText((value + 2).toString())
            }
        }
        root.findViewById<Button>(R.id.btn_dec_start_frame).apply {
            setOnClickListener {
                val value = editStartFrame.text.toString().toInt() - 1
                if (value > 0)
                    editStartFrame.setText((value).toString())
            }
        }

        return AlertDialog.Builder( MAct.act )
                .setTitle( R.string.title_exercise_info )
                .setView( root )
                .setIcon( R.mipmap.file_info )
                .setPositiveButton( R.string.btn_ok ) { _, _ ->
                    Ctx.ctx.exercise.title = editTitle.text.toString()
                    Ctx.ctx.exercise.description = editDesc.text.toString()
                    Ctx.ctx.exercise.startFrameIndex = (editStartFrame.text.toString().toInt() - 1) clip (0 until Ctx.ctx.exercise.size)
                    if ( Ctx.ctx.currentActionForCanvas.value is NoAction )
                        Ctx.ctx.currentActionForCanvas.value = NoAction().beforeAction()
                }
                .setNegativeButton( R.string.btn_cancel, null )
                .create().apply {
                    window?.setBackgroundDrawable(
                            AppCompatResources.getDrawable(MAct.act, R.drawable.dialog_background))
                }
    }
}  // class ExerciseInfoDialogFragment
