package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.graphics.RectF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.pointerLocation
import masca.andrafting.ui.main.str
import kotlin.math.max
import kotlin.math.min

class SquareAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var start: PointF? = null

    override fun beforeAction(): SquareAction
    {
        setStatusBar()

        return this
    }

    override fun action(view: View?, evt: InputEvent?): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( start == null )  // set start
                    start = logicalTouchLocation
                else  // add rectangle
                {
                    val paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val rectangle = ExerciseShape( "",
                                                    str(R.string.new_square),
                                                    SerialPath().storeRectangle( getSquare() ),
                                                    paint.asSerialPaint( Ctx.ctx.fillColor ) )

                    Ctx.ctx.exercise.add( rectangle )

                    Ctx.ctx.undoRedoManager.addItem( UndoRedoableNewShape( rectangle,
                                Ctx.ctx.exercise.indexOf(rectangle), str(R.string.new_square) ) )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if ( Ctx.ctx.keepTool ) SquareAction() else defaultAction)
                                    .beforeAction()
                }
            }
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getSquare(): RectF
    {
        var left = min( logicalTouchLocation.x, start!!.x )
        var right = max( logicalTouchLocation.x, start!!.x )
        if ( Ctx.ctx.useRuler )
        {
            if ( logicalTouchLocation.x < start!!.x )
                left = start!!.x - Ctx.ctx.rulerDistanceMul
            else
                right = start!!.x + Ctx.ctx.rulerDistanceMul
        }
        var top = start!!.y
        var bottom = start!!.y
        if ( logicalTouchLocation.y < start!!.y )
            top = start!!.y - ( right - left )
        else
            bottom = start!!.y + ( right - left )

        return RectF( left, top, right, bottom )
    }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        start ?: return

        // draw start point
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw rectangle
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical(
                            SerialPath().storeRectangle( getSquare() ) ).asPath(), toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            start == null ->
                str(R.string.status_square2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_square3,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_square1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class SquareAction
