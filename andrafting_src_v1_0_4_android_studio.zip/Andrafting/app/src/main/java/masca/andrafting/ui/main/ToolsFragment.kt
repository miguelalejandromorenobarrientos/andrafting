package masca.andrafting.ui.main

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context.INPUT_METHOD_SERVICE
import android.graphics.Color
import android.graphics.Paint.Cap.*
import android.graphics.Paint.Join
import android.graphics.Paint.Join.BEVEL
import android.graphics.Paint.Join.MITER
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import masca.andrafting.*
import masca.andrafting.databinding.FragmentToolsBinding
import masca.andrafting.ui.main.controllers.*
import java.text.DecimalFormat
import kotlin.math.max
import kotlin.math.min

class ToolsFragment : Fragment()
{
    lateinit var binding : FragmentToolsBinding
    private val activity by lazy { context as MainActivity }

    init
    {
        self = this
    }

    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?,
                               savedInstanceState: Bundle? ): View
    {
        binding = FragmentToolsBinding.inflate( inflater )

        // MODIFIERS BAR
        with( binding.modifiersbar )
        {
            // Checkbox Keep Tool
            with( checkKeepTool )
            {
                isChecked = Ctx.ctx.keepTool
                setOnCheckedChangeListener { _, isChecked -> Ctx.ctx.keepTool = isChecked }
            }

            // Checkbox Fixed Angles
            with( checkFixedAngles )
            {
                isChecked = Ctx.ctx.fixedAngles
                setOnCheckedChangeListener { _, isChecked -> Ctx.ctx.fixedAngles = isChecked }
            }

            // Checkbox Add Extremes
            with( checkAddExtremes )
            {
                isChecked = Ctx.ctx.addExtremes
                setOnCheckedChangeListener { _, isChecked -> Ctx.ctx.addExtremes = isChecked }
            }

            // Checkbox Adjust to Vertex
            with( checkAdjustVertex )
            {
                isChecked = Ctx.ctx.adjustTo
                setOnCheckedChangeListener { _, isChecked -> Ctx.ctx.adjustTo = isChecked }
            }

            // Checkbox Auxiliary Shapes
            with( checkAuxShapes )
            {
                isChecked = Ctx.ctx.addAuxiliaryShapes
                setOnCheckedChangeListener{ _, isChecked -> Ctx.ctx.addAuxiliaryShapes = isChecked }
            }

            with( switchFullUi )
            {
                isChecked = Ctx.ctx.fullUI
                setOnCheckedChangeListener { _, isChecked ->
                    Ctx.ctx.fullUI = isChecked
                    if ( isChecked )
                        MAct.act.hideSystemUI()
                    else
                        MAct.act.showSystemUI()
                }
            }
        }  // with binding.modifiersbar

        // Button Point
        binding.btnPoint.onClick = {
            Ctx.ctx.currentActionForCanvas.value = PointAction().beforeAction()
        }

        // Button Segment
        binding.btnSegment.onClick = {
            Ctx.ctx.currentActionForCanvas.value = SegmentAction().beforeAction()
        }

        // Button Arc
        binding.btnArc.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ArcAction().beforeAction()
        }

        // Button Circumference
        binding.btnCircumference.onClick = {
            Ctx.ctx.currentActionForCanvas.value = CircumferenceAction().beforeAction()
        }

        // Button Angle
        binding.btnAngle.onClick = {
            Ctx.ctx.currentActionForCanvas.value = AngleAction().beforeAction()
        }

        // Button Rectangle
        binding.btnRectangle.onClick = {
            Ctx.ctx.currentActionForCanvas.value = RectangleAction().beforeAction()
        }

        // Button Square
        binding.btnSquare.onClick = {
            Ctx.ctx.currentActionForCanvas.value = SquareAction().beforeAction()
        }

        // Button Polygon
        binding.btnPolygon.onClick = {
            Ctx.ctx.currentActionForCanvas.value = PolygonAction().beforeAction()
        }

        // Button Triangle
        binding.btnTriangle.onClick = {
            Ctx.ctx.currentActionForCanvas.value = TriangleAction().beforeAction()
        }

        // Button Ellipse
        binding.btnEllipse.onClick = {
            Ctx.ctx.currentActionForCanvas.value = EllipseAction().beforeAction()
        }

        // Button Parabola
        binding.btnParabola.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ParabolaAction().beforeAction()
        }

        // Button Hyperbola
        binding.btnHyperbola.onClick = {
            Ctx.ctx.currentActionForCanvas.value = HyperbolaAction().beforeAction()
        }

        // Button Spline
        binding.btnSpline.onClick = {
            Ctx.ctx.currentActionForCanvas.value = SplineAction().beforeAction()
        }

        // Button Arrow
        binding.btnArrow.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ArrowAction().beforeAction()
        }

        // Button FreeHand
        binding.btnFreehand.onClick = {
            Ctx.ctx.currentActionForCanvas.value = FreeHandAction().beforeAction()
        }

        // Button Comment
        binding.btnComment.onClick = {
            Ctx.ctx.currentActionForCanvas.value = CommentAction().beforeAction()
        }

        // Button Function
        binding.btnFunction.onClick = {
            Ctx.ctx.currentActionForCanvas.value = FunctionAction().beforeAction()
        }

        // STYLE BAR
        with( binding.stylebar )
        {
            // Button Eyedropper
            btnEyedropper.onClick = {
                Ctx.ctx.currentActionForCanvas.value = EyeDropperAction().beforeAction()
            }

            // Button PasteStyle
            btnPasteStyle.onClick = {
                Ctx.ctx.currentActionForCanvas.value = PasteStyleAction().beforeAction()
            }

            // Button Paint
            btnPaint.onClick = {
                Ctx.ctx.currentActionForCanvas.value = PaintAction().beforeAction()
            }

            // Button Color
            btnColor.setOnClickListener {
                ColorDialogFragment()
                    .show( MAct.act.supportFragmentManager, "tag ColorPickerDialog" )
            }  // btnColor

            // Button Background
            btnColorBackground.setOnClickListener {
                BackgroundDialogFragment()
                    .show( MAct.act.supportFragmentManager, "tag BackgroundPickerDialog" )
            }  // btnColorBackground

            // Button Dec Stroke
            with( btnDecStroke )
            {
                setOnClickListener {
                    val value = max( 1f, activity.applicationContext.strokeWidth - 1 )
                    format2(value).also { editStroke.setText( it ) }
                    activity.applicationContext.strokeWidth = value
                    updateStrokeSpinner()
                }
                setOnLongClickListener {
                    val value = max( 0.1f, activity.applicationContext.strokeWidth - 0.1f )
                    format2(value).also { editStroke.setText( it ) }
                    activity.applicationContext.strokeWidth = value
                    updateStrokeSpinner()
                    true
                }
            }

            // Button Inc Stroke
            with( btnIncStroke )
            {
                setOnClickListener {
                    val value = min( 1000f, activity.applicationContext.strokeWidth + 1 )
                    format2(value).also { editStroke.setText( it ) }
                    activity.applicationContext.strokeWidth = value
                    updateStrokeSpinner()
                }
                setOnLongClickListener {
                    val value = min( 1000f, activity.applicationContext.strokeWidth + 0.1f )
                    format2(value).also { editStroke.setText( it ) }
                    activity.applicationContext.strokeWidth = value
                    updateStrokeSpinner()
                    true
                }
            }

            // EditText Stroke Width
            with( editStroke )
            {
                setOnEditorActionListener { _, _, _ ->
                    try
                    {
                        val value = text.toString().toFloat()
                        if ( value !in 0.1f..1000f )
                            throw NumberFormatException( getString( R.string.errmsg_stroke_width ) )
                        activity.applicationContext.strokeWidth = value
                        updateStrokeSpinner()
                        val imm: InputMethodManager? =
                                activity.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager?
                        imm?.hideSoftInputFromWindow( activity.currentFocus?.windowToken, 0)
                    }
                    catch ( e: NumberFormatException )
                    {
                        AlertDialog.Builder(activity)
                                .setTitle( R.string.lbl_stroke_width )
                                .setIcon( R.mipmap.error_icon )
                                .setMessage( e.message!!.html() )
                                .show()
                    }
                    true
                }
            }

            // Spinner Stroke Cap-Join
            with( spinStrokeCapJoin )
            {
                adapter = ArrayAdapter.createFromResource(
                        activity, R.array.cap_join, R.layout.textview_join_cap )
                onItemSelectedListener =
                        object : AdapterView.OnItemSelectedListener
                        {
                            override fun onItemSelected(parent: AdapterView<*>?,
                                                        view: View?,
                                                        position: Int,
                                                        id: Long
                            ) {
                                Ctx.ctx.cap = when(position)
                                {
                                    0, 3, 6 -> ROUND
                                    1, 4, 7 -> SQUARE
                                    2, 5, 8 -> BUTT
                                    else -> throw IllegalStateException()
                                }
                                Ctx.ctx.join = when(position)
                                {
                                    0, 1, 2 -> Join.ROUND
                                    3, 4, 5 -> BEVEL
                                    6, 7, 8 -> MITER
                                    else -> throw IllegalStateException()
                                }
                                updateStrokeSpinner()
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }
            }  // Spinner Stroke Cap-Join

            // Button Fill Color
            btnColorFill.setOnClickListener {
                FillDialogFragment().show( MAct.act.supportFragmentManager, "tag FillDialog" )
            }

            // Button Point Color
            btnPointColor.setOnClickListener {
                PointColorDialogFragment()
                    .show( MAct.act.supportFragmentManager, "tag PointColorDialog" )
            }

            // Button Dec Point Stroke
            with( btnDecPointStroke )
            {
                setOnClickListener {
                    val value = max( 1f, activity.applicationContext.pointWidth - 1 )
                    format2(value).also { editPointWidth.setText( it ) }
                    activity.applicationContext.pointWidth = value
                }
                setOnLongClickListener {
                    val value = max( 0.1f, activity.applicationContext.pointWidth - 0.1f )
                    format2(value).also { editPointWidth.setText( it ) }
                    activity.applicationContext.pointWidth = value
                    true
                }
            }

            // Button Inc Point Stroke
            with( btnIncPointStroke )
            {
                setOnClickListener {
                    val value = min( 1000f, activity.applicationContext.pointWidth + 1 )
                    format2(value).also { editPointWidth.setText( it ) }
                    activity.applicationContext.pointWidth = value
                }
                setOnLongClickListener {
                    val value = min( 1000f, activity.applicationContext.pointWidth + 0.1f )
                    format2(value).also { editPointWidth.setText( it ) }
                    activity.applicationContext.pointWidth = value
                    true
                }
            }

            // EditText Point Width
            with( editPointWidth )
            {
                setOnEditorActionListener { _, _, _ ->
                    try
                    {
                        val value = text.toString().toFloat()
                        if ( value !in 0.1f..1000f )
                            throw NumberFormatException( getString( R.string.errmsg_stroke_width ) )
                        activity.applicationContext.pointWidth = value
                        val imm: InputMethodManager? =
                                activity.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager?
                        imm?.hideSoftInputFromWindow( activity.currentFocus?.windowToken, 0)
                    }
                    catch ( e: NumberFormatException )
                    {
                        AlertDialog.Builder(activity)
                                .setTitle( R.string.lbl_point_width )
                                .setIcon( R.mipmap.error_icon )
                                .setMessage( e.message!!.html() )
                                .show()
                    }
                    true
                }
            }
        }  // with binding.stylebar

        // Button Ruler
        binding.btnRuler.onClick = {
            Ctx.ctx.currentActionForCanvas.value = RulerAction().beforeAction()
        }

        // Button Dec Multiplier
        with( binding.btnDecMultiplier )
        {
            setOnClickListener {
                val value = max( 1f, activity.applicationContext.rulerMultiplier - 1 )
                format2(value).also { binding.editMultiplier.setText( it ) }
                activity.applicationContext.rulerMultiplier = value
            }
            setOnLongClickListener {
                val value = max( 0.1f, activity.applicationContext.rulerMultiplier - 0.1f )
                format2(value).also { binding.editMultiplier.setText( it ) }
                activity.applicationContext.rulerMultiplier = value
                true
            }
        }

        // Button Inc Multiplier
        with( binding.btnIncMultiplier )
        {
            setOnClickListener {
                val value = min( 1000f, activity.applicationContext.rulerMultiplier + 1 )
                format2(value).also { binding.editMultiplier.setText( it ) }
                activity.applicationContext.rulerMultiplier = value
            }
            setOnLongClickListener {
                val value = min( 1000f, activity.applicationContext.rulerMultiplier + 0.1f )
                format2(value).also { binding.editMultiplier.setText( it ) }
                activity.applicationContext.rulerMultiplier = value
                true
            }
        }

        // EditText Multiplier
        with( binding.editMultiplier )
        {
            setText( activity.applicationContext.rulerMultiplier.toString() )
            setOnEditorActionListener { _, _, _ ->
                try
                {
                    val value = text.toString().toFloat()
                    if ( value !in 0f..1000f )
                        throw NumberFormatException( getString( R.string.errmsg_multiplier ) )
                    activity.applicationContext.rulerMultiplier = value
                    val imm: InputMethodManager? =
                        activity.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager?
                    imm?.hideSoftInputFromWindow( activity.currentFocus?.windowToken, 0)
                }
                catch ( e: NumberFormatException )
                {
                    AlertDialog.Builder(activity)
                        .setTitle( R.string.lbl_multiplier )
                        .setIcon( R.mipmap.error_icon )
                        .setMessage( e.message!!.html() )
                        .show()
                }
                true
            }
        }

        // Spinner Ruler Mode
        with( binding.spinRulerMode )
        {
            adapter = ArrayAdapter.createFromResource(
                    activity, R.array.ruler_modes, android.R.layout.simple_spinner_dropdown_item )
            onItemSelectedListener =
                    object : AdapterView.OnItemSelectedListener
                    {
                        override fun onItemSelected(parent: AdapterView<*>?,
                                                    view: View?,
                                                    position: Int,
                                                    id: Long
                        ) {
                            Ctx.ctx.rulerMode = when(position)
                            {
                                0 -> RULER_MODE_NORMAL
                                1 -> RULER_MODE_ADDITIVE
                                2 -> RULER_MODE_SUBTRACTIVE
                                else -> throw IllegalStateException()
                            }
                        }

                        override fun onNothingSelected(parent: AdapterView<*>?) {
                            Ctx.ctx.rulerMode = RULER_MODE_NORMAL
                            parent?.setSelection( 0 )
                        }
                    }
        }

        // Button Protractor
        binding.btnProtractor.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ProtractorAction().beforeAction()
        }

        // EditText Protractor angle
        with( binding.editProtractor )
        {
            setOnEditorActionListener { _, _, _ ->
                try
                {
                    val value = text.toString().toDouble()
                    if ( value !in 0.0..359.999999999 )
                        throw NumberFormatException( str(R.string.errmsg_angle) )
                    Ctx.ctx.protractorStoredAngle = Math.toRadians( value ).toFloat()
                    val imm: InputMethodManager? =
                            activity.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager?
                    imm?.hideSoftInputFromWindow( activity.currentFocus?.windowToken, 0)
                }
                catch ( e: NumberFormatException )
                {
                    AlertDialog.Builder(activity)
                            .setTitle( str(R.string.title_protractor_error) )
                            .setIcon( R.mipmap.error_icon )
                            .setMessage( e.message!!.html() )
                            .show()
                }
                true
            }
        }

        // Spinner Protractor Mode
        with( binding.spinProtractorMode )
        {
            adapter = ArrayAdapter.createFromResource( activity,
                        R.array.protractor_modes, android.R.layout.simple_spinner_dropdown_item )
            onItemSelectedListener =
                    object : AdapterView.OnItemSelectedListener
                    {
                        override fun onItemSelected(parent: AdapterView<*>?,
                                                    view: View?,
                                                    position: Int,
                                                    id: Long
                        ) {
                            Ctx.ctx.protractorMode = when(position)
                            {
                                0 -> PROTRACTOR_MODE_NORMAL
                                1 -> PROTRACTOR_MODE_COMPLEMENTARY
                                2 -> PROTRACTOR_MODE_SUPPLEMENTARY
                                3 -> PROTRACTOR_MODE_CONJUGATE
                                else -> throw IllegalStateException()
                            }
                            /*Toast.makeText( activity,
                                       "${Math.toDegrees(Ctx.ctx.protractorAngle.toDouble())}º",
                                        Toast.LENGTH_SHORT )
                            .show()*/
                        }

                        override fun onNothingSelected(parent: AdapterView<*>?) {
                            Ctx.ctx.protractorMode = PROTRACTOR_MODE_NORMAL
                            parent?.setSelection( 0 )
                        }
                    }
        }

        // Button Modify Segment
        binding.btnModifySegment.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ModifySegmentAction().beforeAction()
        }

        // Button Perpendicular
        binding.btnPerpendicular.onClick = {
            Ctx.ctx.currentActionForCanvas.value = PerpendicularAction().beforeAction()
        }

        // Button Parallel
        binding.btnParallel.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ParallelAction().beforeAction()
        }

        // Button Bisectrix
        binding.btnBisectrix.onClick = {
            Ctx.ctx.currentActionForCanvas.value = BisectrixAction().beforeAction()
        }

        // Button Mediatrix
        binding.btnMediatrix.onClick = {
            Ctx.ctx.currentActionForCanvas.value = MediatrixAction().beforeAction()
        }

        // Button Capable Arc
        binding.btnCapableArc.onClick = {
            Ctx.ctx.currentActionForCanvas.value = CapableArcAction().beforeAction()
        }

        // Button Divisions
        binding.btnDivisions.onClick = {
            Ctx.ctx.currentActionForCanvas.value = DivisionAction().beforeAction()
        }

        // Button Intersections
        binding.btnIntersections.onClick = { IntersectionAction().action() }

        // Button Midpoint
        binding.btnMidpoint.onClick = {
            Ctx.ctx.currentActionForCanvas.value = MidpointAction().beforeAction()
        }

        // Button Vertices
        binding.btnVertices.onClick = {
            Ctx.ctx.currentActionForCanvas.value = VerticesAction().beforeAction()
        }

        // Button Extremes
        binding.btnExtremes.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ExtremeAction().beforeAction()
        }

        // Button Fragment
        binding.btnFragment.onClick = {
            Ctx.ctx.currentActionForCanvas.value = FragmentAction().beforeAction()
        }

        // Button Fusion
        binding.btnFusion.onClick = { FusionAction().action() }

        // Button Translation
        binding.btnTranslation.onClick = {
            Ctx.ctx.currentActionForCanvas.value = TranslateAction().beforeAction()
        }

        // Button Rotation
        binding.btnRotation.onClick = {
            Ctx.ctx.currentActionForCanvas.value = RotationAction().beforeAction()
        }

        // Button Homothety
        binding.btnHomothety.onClick = {
            Ctx.ctx.currentActionForCanvas.value = HomothetyAction().beforeAction()
        }

        // Button Axial Symmetry
        binding.btnAxialSymmetry.onClick = {
            Ctx.ctx.currentActionForCanvas.value = AxialSymmetryAction().beforeAction()
        }

        // Button CentralSymmetry
        binding.btnCentralSymmetry.onClick = {
            Ctx.ctx.currentActionForCanvas.value = CentralSymmetry().beforeAction()
        }

        // Button Union
        binding.btnUnion.onClick = { SealedRegionOpAction.UnionAction().action() }

        // Button Intersection
        binding.btnIntersection.onClick = { SealedRegionOpAction.IntersectionAction().action() }

        // Button Subtract
        binding.btnSubtract.onClick = { SealedRegionOpAction.SubtractAction().action() }

        // Button Subtract Reverse
        binding.btnSubtractReverse.onClick = {
            SealedRegionOpAction.SubtractReverseAction().action()
        }

        // Button Symmetric Subtract
        binding.btnSymmetricSubtract.onClick = {
            SealedRegionOpAction.SymmetricSubtractAction().action()
        }

        // Button Bounds
        binding.btnBounds.onClick = {
            Ctx.ctx.currentActionForCanvas.value = BoundsAction().beforeAction()
        }

        // FILE AND EDIT BAR
        with( binding.fileAndEditBar )
        {
            // Button New Exercise
            btnNewExercise.onClick = { NewExerciseAction().action() }

            // Button Open
            btnOpen.onClick = { OpenAction().action() }

            // Button Save
            btnSave.onClick = { SaveAction().action() }

            // Button Save As
            btnSaveAs.onClick = { SaveAction(true).action() }

            // Button Save Image
            btnSaveImage.onClick = { SaveImageAction().action() }

            // Button Save SVG
            btnSaveSvg.onClick = { SaveSvgAction().action() }

            // Button File Properties
            btnPropExercise.setOnClickListener { ExerciseInfoAction().action() }

            // Button Select All
            btnSelectAll.onClick = { SelectAllAction().action() }

            // Button Invert Selection
            btnInvertSelection.onClick = { InvertSelection().action() }

            // Button Copy
            btnCopy.setOnClickListener { CopyAction().action() }

            // Button Paste
            btnPaste.onClick = { PasteAction().action() }
        }

        return binding.root
    }

    override fun onResume()
    {
        super.onResume()

        with( binding )
        {
            editProtractor.setText( DecimalFormat("#.###")
                          .format( Math.toDegrees(Ctx.ctx.protractorStoredAngle.toDouble()) ) )

            // load style
            // point
            stylebar.editPointWidth.setText(Ctx.ctx.pointWidth.toString())
            // shape
            updateStrokeSpinner()
            stylebar.spinnerStrokeStyle.updateSelection()
            updateCapJoinSelection()
            stylebar.editStroke.setText( Ctx.ctx.strokeWidth.toString() )
        }
    }

    /** update spinner when color changes *(not when selection changes)* */
    fun updateStrokeSpinner() =
                                binding.stylebar.spinnerStrokeStyle.adapter?.notifyDataSetChanged()

    private fun updateCapJoinSelection()
        = binding.stylebar.spinStrokeCapJoin.setSelection( when ( Ctx.ctx.cap to Ctx.ctx.join ) {
            ROUND to Join.ROUND -> 0
            SQUARE to Join.ROUND -> 1
            BUTT to Join.ROUND -> 2
            ROUND to BEVEL -> 3
            SQUARE to BEVEL -> 4
            BUTT to BEVEL -> 5
            ROUND to MITER -> 6
            SQUARE to MITER -> 7
            BUTT to MITER -> 8
            else -> -1
        })

    companion object
    {
        lateinit var self: ToolsFragment

        fun newInstance() = ToolsFragment()
    }

}  // class ToolsFragment


class ColorDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return ColorPickerDialog( MAct.act, Ctx.ctx.strokeColor,
                                  resources.getString( R.string.title_foreground_color ) ).apply {
                    setPositiveButton( resources.getString(R.string.btn_ok )) { _, _ ->
                    Ctx.ctx.strokeColor = currentColor
                    ToolsFragment.self.binding.stylebar.btnColor.invalidate()
                    addColor(currentColor)
                    ToolsFragment.self.updateStrokeSpinner()
                }
                setNegativeButton( resources.getString(R.string.btn_cancel), null )
            }.create()
    }
}  // class ColorDialogFragment


class PointColorDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return ColorPickerDialog( MAct.act, Ctx.ctx.pointColor,
                                  resources.getString(R.string.title_point_color) ).apply {
                    setPositiveButton(resources.getString(R.string.btn_ok)) { _, _ ->
                    Ctx.ctx.pointColor = currentColor
                    ToolsFragment.self.binding.stylebar.btnPointColor.invalidate()
                    addColor(currentColor)
                }
                setNegativeButton(resources.getString(R.string.btn_cancel), null )
            }.create()
    }
}  // class PointColorDialogFragment


class BackgroundDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return ColorPickerDialog( MAct.act, Ctx.ctx.exercise.background,
                                  resources.getString( R.string.title_background_color ) ).apply {
                    setPositiveButton( resources.getString(R.string.btn_ok )) { _, _ ->
                    Ctx.ctx.exercise.background = currentColor
                    ToolsFragment.self.binding.stylebar.btnColorBackground.invalidate()
                    addColor(currentColor)
                    ToolsFragment.self.updateStrokeSpinner()
                }
                setNegativeButton( resources.getString(R.string.btn_cancel), null )
            }.create()
    }
}  // class BackgroundDialogFragment


class FillDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return ColorPickerDialog( MAct.act, Ctx.ctx.fillColor ?: Color.WHITE,
                                  resources.getString(R.string.title_fill_color) ).apply {
                setPositiveButton(resources.getString(R.string.btn_ok)) { _, _ ->
                    Ctx.ctx.fillColor = currentColor
                    ToolsFragment.self.binding.stylebar.btnColorFill.invalidate()
                    addColor(currentColor)
                }
                setNegativeButton(resources.getString(R.string.btn_cancel), null )
                setNeutralButton( R.string.btn_no_fill ) { _, _ ->
                    Ctx.ctx.fillColor = null
                    ToolsFragment.self.binding.stylebar.btnColorFill.invalidate()
                }
            }.create()
    }
}  // class FillDialogFragment
