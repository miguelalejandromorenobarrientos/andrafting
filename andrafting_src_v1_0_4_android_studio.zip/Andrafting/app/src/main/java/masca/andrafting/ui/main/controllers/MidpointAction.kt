package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.PointF
import android.os.Bundle
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.pointerLocation
import masca.andrafting.ui.main.str

class MidpointAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var shape: ExerciseShape? = null  // touched shape
    private var midpoint: PointF? = null  // midpoint or centroid
    var centroid = false  // true for centroid instead of midpoint

    init
    {
        self = this
    }

    override fun beforeAction(): MidpointAction
    {
        MidpointDialogFragment().show( MAct.act.supportFragmentManager, "tag MidpointDialog" )

        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            in setOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE) ->
            {
                // get shape
                shape = exCanvas.getShapeAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation)  )
                // don't take account points bounds
                if ( shape?.path?.isPoint() == true )
                    shape = null

                // set midpoint/centroid
                if ( shape != null )
                    midpoint = if (centroid) centroid( shape!!.path )
                               else shape!!.getBounds().center()
            }
            MotionEvent.ACTION_UP ->
            {
                if ( shape != null )
                {
                    // add midpoint/centroid to exercise
                    val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                    val descHtml =
                            str( if (centroid) R.string.desc_centroid else R.string.desc_midpoint,
                                Ctx.ctx.getHexColor(R.color.name_item),
                                elvis(shape!!.name,"?"))

                    ExerciseShape( "",
                                   descHtml,
                                   SerialPath().storePoint( midpoint!! ),
                                   paint.asSerialPaint() ).run {
                        Ctx.ctx.exercise.add(this)
                        Ctx.ctx.undoRedoManager.addItem( UndoRedoableNewShape(
                                                            this,
                                                            Ctx.ctx.exercise.indexOf(this),
                                                            descHtml ) )
                    }

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if (Ctx.ctx.keepTool) MidpointAction() else defaultAction).beforeAction()
                }
            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation,
                         adjusted && shape != null )

        shape ?: return

        // draw shape and midpoint/centroid
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( shape!!.path ).asPath(), toolPaint )
            toolPaint.strokeWidth = Ctx.ctx.pointWidth
                val pMidpoint = it.toPhysicalViewport(midpoint!!)
                it.canvas.drawPoint( pMidpoint.x, pMidpoint.y, toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            else -> str(R.string.status_midpoint2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_midpoint1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

    companion object
    {
        lateinit var self: MidpointAction

        fun centroid( path: SerialPath ): PointF
        {
            val vertices = path.getPolyVertices()

            return vertices.reduce { a,b -> a + b } * ( 1f/vertices.size )
        }
    }

}  // class MidpointAction


class MidpointDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        // ask for centroid or midpoint
        return AlertDialog.Builder(MAct.act)
                //.setMessage( str(R.string.msg_midpoint).html() )  // doesn't work with choice items!!??
                .setTitle(str(R.string.msg_midpoint).html())
                .setIcon(R.mipmap.midpoint)
                .setSingleChoiceItems(R.array.centroid, 0) { _, which ->
                    MidpointAction.self.centroid = which == 1
                }
                .setPositiveButton(R.string.btn_ok, null)
                .setNegativeButton(R.string.btn_cancel) { dialog, _ ->
                    dialog.cancel()
                }
                .setOnCancelListener {
                    Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
                }
                .create().apply {
                    window?.setBackgroundDrawable(
                        AppCompatResources.getDrawable( MAct.act, R.drawable.dialog_background ) )
                }
    }
}  // class MidpointDialogFragment
