////////////////////////////////////////////////////////////
// Undo/Redo system for this app.
// @author Miguel Alejandro Moreno Barrientos, (C)2022
////////////////////////////////////////////////////////////

package masca.andrafting.ui.main

import masca.andrafting.R


typealias SubscriberAction = (UndoRedoable?) -> Unit

/**
 * Base class for any undo-redoable action
 */
abstract class UndoRedoable
{
    val subscribers by lazy { mutableListOf<SubscriberAction>() }

    abstract fun undo()

    abstract fun redo()

    open fun canUndo() = true

    open fun canRedo() = true

    open fun undoDescription() = "${str(R.string.undo)} ${getDescription()}"

    open fun redoDescription() = "${str(R.string.redo)} ${getDescription()}"

    abstract fun getDescription(): String

    fun notifySubscribers() = subscribers.forEach { it( this ) }

    override fun toString() = "UndoRedoable(undoDescription=${undoDescription()}," +
                               "redoDescription=${redoDescription()}," +
                               "canUndo=${canUndo()}," +
                               "canRedo=${canRedo()})"
}


open class UndoRedoTransaction private constructor( private val list: MutableList<UndoRedoable> )
    : MutableList<UndoRedoable> by list, UndoRedoable()
{
    constructor(): this( mutableListOf() )

    private var undone = false

    final override fun undo()
    {
        if ( canUndo() )
        {
            for ( undoRedoable in reversed() )
                undoRedoable.undo()
            undone = true
        }
        else
            throw IllegalStateException( "Can't undo" )
    }

    final override fun redo()
    {
        if ( canRedo() )
        {
            for ( undoRedoable in this )
                undoRedoable.redo()
            undone = false
        }
        else
            throw IllegalStateException( "Can't redo" )
    }

    final override fun canUndo() = isNotEmpty() && !undone

    final override fun canRedo() = isNotEmpty() && undone

    override fun undoDescription() = "${str(R.string.undo)} ${getDescription()}"

    override fun redoDescription() = "${str(R.string.redo)} ${getDescription()}"

    override fun getDescription() = if ( isNotEmpty() ) last().getDescription() else ""

    override fun toString()
        = "UndoRedoTransaction(undoDescription=${undoDescription()}, " +
          "redoDescription=${redoDescription()}, " +
          "list=$list, " +
          "canUndo=${canUndo()}, " +
          "canRedo=${canRedo()}, " +
          "subscribers=$subscribers)"

}  // Class UndoRedoTransaction


open class UndoRedoManager private constructor(private val list: MutableList<UndoRedoable>,
                                               private var limit: Int )
    : MutableList<UndoRedoable> by list, UndoRedoable()
{
    constructor( limit: Int = Int.MAX_VALUE ): this( mutableListOf(), limit )

    private var index = list.size - 1

    final override fun undo()
    {
        if ( canUndo() )
            this[index--].undo()
        else
            throw IllegalStateException( "Can't undo" )

        notifySubscribers()
    }

    final override fun redo()
    {
        if ( canRedo() )
            this[++index].redo()
        else
            throw IllegalStateException( "Can't redo" )

        notifySubscribers()
    }

    final override fun canUndo() = isNotEmpty() && index >= 0 && this[index].canUndo()

    final override fun canRedo() = isNotEmpty() && index < size-1 && this[index+1].canRedo()

    override fun undoDescription()
        = if ( canUndo() ) "${str(R.string.undo)} ${this[index].getDescription()}" else "Can´t undo"

    override fun redoDescription()
        = if ( canRedo() ) "${str(R.string.redo)} ${this[index+1].getDescription()}" else "Can't redo"

    override fun getDescription() = "No description"

    fun addItem( undoRedo: UndoRedoable)
    {
        subList( index + 1, size ).clear()

        if ( size >= limit )
            subList( 0, size - limit + 1 ).clear()

        add( undoRedo )
        index = size - 1

        notifySubscribers()
    }

    fun clearAll()
    {
        clear()
        index = size - 1

        notifySubscribers()
    }

    override fun toString()
        = "UndoRedoManager(list=$list, limit=$limit, canUndo=${canUndo()}, canRedo=${canRedo()})"

}  // class UndoRedoManager
