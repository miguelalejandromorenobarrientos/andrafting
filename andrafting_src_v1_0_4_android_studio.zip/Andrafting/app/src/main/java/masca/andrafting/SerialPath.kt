package masca.andrafting

import android.graphics.Matrix
import android.graphics.Path
import android.graphics.PointF
import androidx.core.graphics.PathSegment
import java.io.Serializable

data class SerialPath( private val segmentList: MutableList<SegmentHolder> = mutableListOf() )
    : Serializable, MutableList<SerialPath.SegmentHolder> by segmentList
{
    @Transient private var path: Path? = null
    @Transient private var polyPath: SerialPath? = null
    @Transient private var polySegments: MutableList<PathSegment>? = null
    @Transient private var polyVertices: List<PointF>? = null
    @Transient private var allPolyVertices: List<PointF>? = null

    fun copy(): SerialPath
    {
        val copySegmentList = mutableListOf<SegmentHolder>()
        for ( segmentHolder in segmentList )
            copySegmentList.add( segmentHolder.copy() )

        return SerialPath( copySegmentList )
    }

    fun forceUpdate()
    {
        path = null
        polyPath = null
        polySegments = null
        polyVertices = null
        allPolyVertices = null
    }

    override fun add( element: SegmentHolder ): Boolean
    {
        forceUpdate()

        return segmentList.add( element )
    }

    fun reset()
    {
        segmentList.clear()

        forceUpdate()
    }

    fun moveTo( x: Float, y: Float ) = add( SegmentHolder( SegmentType.MOVE, x, y ) )
    fun moveTo( p: PointF ) = moveTo( p.x, p.y )

    fun lineTo( x: Float, y: Float ) = add( SegmentHolder( x = x, y = y ) )
    fun lineTo( p: PointF ) = lineTo( p.x, p.y )

    fun quadTo( x0: Float, y0: Float, x1: Float, y1: Float )
        = add( SegmentHolder( x0, y0, x1, y1 ) )
    fun quadTo( p0: PointF, p1: PointF ) = quadTo( p0.x, p0.y, p1.x, p1.y )

    fun cubicTo( x0: Float, y0: Float, x1: Float, y1: Float, x2: Float, y2: Float )
        = add( SegmentHolder( x0, y0, x1, y1, x2, y2 ) )
    fun cubicTo( p0: PointF, p1: PointF, p2: PointF ) = cubicTo( p0.x, p0.y, p1.x, p1.y, p2.x, p2.y )

    fun close() = add( SegmentHolder.SEGMENT_CLOSE )

    fun asPath(): Path
    {
        if ( path != null )
            return path!!

        val newPath = Path()

        for ( segment in segmentList )
            when ( segment.type )
            {
                SegmentType.MOVE -> newPath.moveTo( segment.coords[0], segment.coords[1] )
                SegmentType.LINE -> newPath.lineTo( segment.coords[0], segment.coords[1] )
                SegmentType.CLOSE -> newPath.close()
                SegmentType.QUAD -> newPath.quadTo( segment.coords[0], segment.coords[1],
                                                    segment.coords[2], segment.coords[3] )
                SegmentType.CUBIC -> newPath.cubicTo( segment.coords[0], segment.coords[1],
                                                      segment.coords[2], segment.coords[3],
                                                      segment.coords[4], segment.coords[5] )
            }

        return newPath.apply { path = newPath }
    }

    fun asPolyPath(): SerialPath
    {
        if ( polyPath != null )
            return polyPath!!

        polyPath = asPath().approximateAsSerialPath()

        return polyPath!!
    }

    /**
     * Transform all vertices in the serial path by the given matrix
     */
    fun transform( matrix: Matrix )
    {
        for ( segment in segmentList )
            matrix.mapPoints( segment.coords )

        forceUpdate()
    }

    /**
     * Get **unique** vertices in the poly path
     * @return ordered vertices **without duplicates**
     */
    fun getPolyVertices(): List<PointF>
    {
        if ( polyVertices != null )
            return polyVertices!!

        val vertex = linkedSetOf<PointF>()

        for ( segment in asPolyPath() )
            vertex.add( segment.coords.toPoints2D()[0] )

        polyVertices = vertex.toList()

        return polyVertices!!
    }

    /**
     * Get **all** vertices in the poly path. **Warning:** this method is not precise so depends of
     * approximate method in asPolyPath
     * @return all ordered vertices
     */
    fun getAllPolyVertices(): List<PointF>
    {
        if ( allPolyVertices != null )
            return allPolyVertices!!

        var lastMove: PointF? = null

        val vertices = mutableListOf<PointF>()

        for ( segment in asPolyPath() )
        {
            if ( segment.type == SegmentType.MOVE )
                lastMove = segment.coords.toPoints2D()[0]
            else if ( segment.type == SegmentType.CLOSE && lastMove != null )
            {
                vertices.add ( lastMove )
                continue
            }

            vertices.add(segment.coords.toPoints2D()[0])
        }

        allPolyVertices = vertices

        return vertices
    }

    /**
     * Get segments in the poly path
     * @return ordered segments
     */
    fun getPolySegments(): MutableList<PathSegment>
    {
        if ( polySegments != null )
            return polySegments!!

        val pathSegments = mutableListOf<PathSegment>()
        val pp = asPolyPath()

        for ( (idx,segment) in pp.withIndex() )
            if ( segment.type != SegmentType.MOVE )
                pathSegments.add( PathSegment( pp[idx-1].coords.toPoints2D()[0], 0f,
                                               segment.coords.toPoints2D()[0], 1f ) )

        polySegments = pathSegments

        return pathSegments
    }

    fun isPoint() = size == 2
                    && this[0].type == SegmentType.MOVE
                    && (this[1].type == SegmentType.CLOSE || this[1].type == SegmentType.LINE && this[0].coords.contentEquals(this[1].coords))

    fun isSegment() = size == 2
                      && this[0].type == SegmentType.MOVE
                      && this[1].type == SegmentType.LINE
                      && !this[0].coords.contentEquals(this[1].coords)

    fun isOpen()
        = !isPoint() && getPolySegments().first().start != getPolySegments().last().end

    fun isClosed() = !isOpen()

    override fun toString() ="SerialPath(segmentList=$segmentList, length=$length)"

    val length: Float
        get()
        {
            var sum = 0f
            getPolySegments().forEach { sum += it.start.distance(it.end) }
            return sum
        }

    data class SegmentHolder private constructor(
            val type: SegmentType,
            val coords: FloatArray
        ) : Serializable
    {
        fun copy() = SegmentHolder( type, coords.clone() )

        /** QUAD */
        constructor( x0: Float, y0: Float, x1: Float, y1: Float )
            : this( SegmentType.QUAD, floatArrayOf( x0, y0, x1, y1 ) )
        /** CUBIC */
        constructor( x0: Float, y0: Float, x1: Float, y1: Float, x2: Float, y2: Float )
            : this( SegmentType.CUBIC, floatArrayOf( x0, y0, x1, y1, x2, y2 ) )
        /** CLOSE */
        private constructor() : this( SegmentType.CLOSE, floatArrayOf() )
        /** MOVE/LINE (default LINE) */
        constructor( type: SegmentType = SegmentType.LINE, x: Float, y: Float )
            : this( type, floatArrayOf( x, y ) )
        {
            if ( type !in setOf( SegmentType.LINE, SegmentType.MOVE ) )
                throw IllegalArgumentException( "Only LINE or MOVE" )
        }

        /**
         * @throws IndexOutOfBoundsException bad point index
         */
        fun getPoint( index: Int ) = PointF( coords[index * 2], coords[index * 2 + 1] )

        companion object
        {
            /** Singleton CLOSE */
            val SEGMENT_CLOSE = SegmentHolder()
        }

        override fun equals(other: Any?): Boolean
        {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as SegmentHolder

            if (type != other.type) return false
            if (!coords.contentEquals(other.coords)) return false

            return true
        }

        override fun hashCode(): Int
        {
            var result = type.hashCode()
            result = 31 * result + coords.contentHashCode()
            return result
        }
    }

    enum class SegmentType { MOVE, LINE, QUAD, CUBIC, CLOSE }

}


fun Path.approximateAsSerialPath(): SerialPath
{
    val serialPath = SerialPath()

    val arrayPoints = approximate( FLATNESS )  // [f0,x0,y0,f1,x1,y1,...,fn,xn,yn]

    var oldFraction = Float.NaN
    var oldX = Float.NaN
    var oldY = Float.NaN

    for ( idx in arrayPoints.indices step 3 )
    {
        val fraction = arrayPoints[idx]
        val x = arrayPoints[idx+1]
        val y = arrayPoints[idx+2]
        if ( idx == 0 )  // initial move
            serialPath.add( SerialPath.SegmentHolder( SerialPath.SegmentType.MOVE, x, y ) )
        else
        {
            if ( (x != oldX || y != oldY) && oldFraction == fraction )  // insert MOVE
                serialPath.add( SerialPath.SegmentHolder( SerialPath.SegmentType.MOVE, x, y ) )
            else  // insert LINE
                serialPath.add( SerialPath.SegmentHolder( x = x, y = y ) )
        }
        oldFraction = fraction
        oldX = x
        oldY = y
    }

    return serialPath
}

const val FLATNESS = 0.1f
