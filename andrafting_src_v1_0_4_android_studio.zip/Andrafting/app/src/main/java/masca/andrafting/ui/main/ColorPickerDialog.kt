package masca.andrafting.ui.main

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.appcompat.app.AlertDialog
import masca.andrafting.R
import masca.andrafting.colorIntToColorHex6Or8

class ColorPickerDialog( context: Context,
                         var currentColor: Int = Color.WHITE,
                         title: String = "Color Picker" )
    : AlertDialog.Builder(context), OnSeekBarChangeListener
{
    private var redBar: SeekBar
    private var greenBar: SeekBar
    private var blueBar: SeekBar
    private var alphaBar: SeekBar
    private var txtHex: TextView
    private var txtARGB: TextView
    private var viewSample: View
    private var listColor: ListViewColorHistory

    override fun onProgressChanged( seekBar: SeekBar, progress: Int, fromUser: Boolean )
    {
        if (fromUser)
            currentColor = Color.argb( alphaBar.progress, redBar.progress,
                                       greenBar.progress, blueBar.progress )

        txtHex.text = colorIntToColorHex6Or8(currentColor)
        "R${redBar.progress},G${greenBar.progress},B${blueBar.progress},A${alphaBar.progress}"
            .also { txtARGB.text = it }
        viewSample.setBackgroundColor(currentColor)
    }

    override fun onStartTrackingTouch(seekBar: SeekBar) {}
    override fun onStopTrackingTouch(seekBar: SeekBar) {}

    init
    {
        val rootView =
            LayoutInflater.from(getContext()).inflate(R.layout.color_dialog, null) as ViewGroup
        setView(rootView)
        setTitle( title )
        redBar = rootView.findViewById(R.id.seekbarRed)
        redBar.max = 255
        greenBar = rootView.findViewById(R.id.seekbarGreen)
        greenBar.max = 255
        blueBar = rootView.findViewById(R.id.seekbarBlue)
        blueBar.max = 255
        alphaBar = rootView.findViewById(R.id.seekbarAlpha)
        alphaBar.max = 255
        redBar.setOnSeekBarChangeListener(this)
        greenBar.setOnSeekBarChangeListener(this)
        blueBar.setOnSeekBarChangeListener(this)
        alphaBar.setOnSeekBarChangeListener(this)
        Handler().post {
            if (currentColor == Color.BLACK) // (force change)
                redBar.progress = 1
            redBar.progress = Color.red(currentColor)
            greenBar.progress = Color.green(currentColor)
            blueBar.progress = Color.blue(currentColor)
            alphaBar.progress = Color.alpha(currentColor)
        }
        txtHex = rootView.findViewById(R.id.txtHex)
        txtARGB = rootView.findViewById(R.id.txtARGB)
        viewSample = rootView.findViewById(R.id.viewSample)
        listColor = rootView.findViewById( R.id.lst_recent_colors )
        listColor.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            currentColor = (listColor.adapter as ListViewColorHistory.ListAdapter).getItem(position)!!
            redBar.progress = Color.red(currentColor)
            greenBar.progress = Color.green(currentColor)
            blueBar.progress = Color.blue(currentColor)
            alphaBar.progress = Color.alpha(currentColor)
        }
    }  // init

}  // class ColorPickerDialog

class ListViewColorHistory( context: Context, attr: AttributeSet ) : ListView( context, attr )
{
    init
    {
        adapter = ListAdapter( context )
        setSelection(count-1)  // go to end
    }

    inner class ListAdapter( context: Context )
       : ArrayAdapter<Int>( context, R.layout.color_item, Ctx.ctx.colorHistory )
    {
        override fun getView( position: Int, convertView: View?, parent: ViewGroup ): View
        {
            var rowView = convertView

            if (rowView == null)
                rowView = LayoutInflater.from( context )
                                        .inflate( R.layout.color_item, parent, false )!!

            // set color
            rowView.findViewById<TextView>( R.id.txt_color ).run {
                text = colorIntToColorHex6Or8( getItemAtPosition(position) as Int )
                setBackgroundColor( Ctx.ctx.colorHistory[position] )
            }

            return rowView
        }
    }
}
