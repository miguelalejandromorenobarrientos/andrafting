package masca.andrafting.ui.main.controllers

import android.graphics.Matrix
import masca.andrafting.R
import masca.andrafting.arg
import masca.andrafting.endPoint
import masca.andrafting.minus
import masca.andrafting.ui.main.Ctx

class AxialSymmetryAction: TranslateAction()
{
    override val descOp = R.string.desc_axial_symmetry
    override val status1 = R.string.status_axial_symmetry1
    override val status2 = R.string.status_axial_symmetry2
    override val status3 = R.string.status_axial_symmetry3

    override val getMatrix: Matrix
        get() {
            start ?: throw IllegalStateException( "START NOT SET!" )
            val endPoint = endPoint( start!!,
                                     logicalTouchLocation,
                                     Ctx.ctx.fixedAngles,
                                     if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                     else -1f,
                                     if ( Ctx.ctx.useProtractor ) Ctx.ctx.protractorAngle
                                     else -1f )

            val degrees = Math.toDegrees( (endPoint - start!!).arg().toDouble() ).toFloat()

            return Matrix().apply {
                preTranslate( start!!.x, start!!.y )
                preRotate( degrees )
                preScale( 1f, -1f )
                preRotate( -degrees )
                preTranslate( -start!!.x, -start!!.y )
            }
        }

}  // Class AxialSymmetryAction
