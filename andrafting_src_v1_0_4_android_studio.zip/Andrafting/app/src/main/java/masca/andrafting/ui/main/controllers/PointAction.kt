package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.pointerLocation
import masca.andrafting.ui.main.str

class PointAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point

    override fun beforeAction(): PointAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view ?: return true
        view.performClick()
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!!
                               else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                setStatusBar()
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                // add point to exercise and undo/redo system
                val paint = defaultPaint( width = Ctx.ctx.pointWidth, color = Ctx.ctx.pointColor )
                val shape = ExerciseShape( "",
                                           Ctx.ctx.getString( R.string.new_point ),
                                           SerialPath().storePoint( logicalTouchLocation ),
                                           paint.asSerialPaint() )
                Ctx.ctx.exercise.add( shape )
                Ctx.ctx.undoRedoManager.addItem( UndoRedoableNewShape(
                                                        shape, Ctx.ctx.exercise.indexOf(shape),
                                                        Ctx.ctx.getString(R.string.new_point) ) )

                // update or keep tool
                Ctx.ctx.currentActionForCanvas.value =
                        (if ( Ctx.ctx.keepTool ) PointAction() else defaultAction).beforeAction()
            }
        }  // when

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 2f )

        // draw circle centered in touch
        drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )
    }

    private fun setStatusBar()
    {
        val txt = when {

            else -> str(R.string.status_point2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_point1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

} // class PointAction
