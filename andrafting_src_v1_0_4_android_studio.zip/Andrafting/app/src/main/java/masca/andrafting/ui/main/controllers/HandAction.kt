package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.graphics.Rect
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.contains
import androidx.core.graphics.plus
import androidx.core.graphics.toPoint
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.getShapeNamePosition
import masca.andrafting.ui.main.scaleStrokeWidth

class HandAction : ActionListener
{
    private var oldLocation = PointF()
    private var shapeWithName: ExerciseShape? = null

    override fun beforeAction(): HandAction
    {
        """${Ctx.ctx.getString(
                R.string.status_hand1,
                Ctx.ctx.getHexColor(R.color.tool_name)
            )
        }: ${Ctx.ctx.getString(
            R.string.status_hand2,
                Ctx.ctx.getHexColor(R.color.tool_item))}""".html()
                .also { Ctx.ctx.statusBarMsg.value = it }

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                oldLocation = evt.location()

                // maybe catch shape name
                if ( Ctx.ctx.showNames )
                {
                    val candidateShapes =
                            Ctx.ctx.exercise.shapesUntilFrameIndex.filter { it.name.isNotBlank() }

                    for ( shape in candidateShapes )
                    {
                        val txtBounds = Rect()
                        defaultShapeNamePaint(shape).getTextBounds(
                                                shape.name, 0, shape.name.length, txtBounds )
                        txtBounds.inset( -24, -24 )
                        val physicalNamePos =
                                        exCanvas.toPhysicalViewport( getShapeNamePosition( shape ) )
                        txtBounds.offset( physicalNamePos.x.toInt(), physicalNamePos.y.toInt() )
                        if ( txtBounds.contains( evt.location().toPoint() ) )
                        {
                            shapeWithName = shape
                            exCanvas.invalidate()
                            break
                        }
                    }  // for
                }  // if

                """${Ctx.ctx.getString(R.string.status_hand1,Ctx.ctx.getHexColor(R.color.tool_name) )
                }: ${if( shapeWithName == null ) Ctx.ctx.getString(R.string.status_hand3,
                        Ctx.ctx.getHexColor(R.color.tool_item))
                    else Ctx.ctx.getString(R.string.status_hand4,
                        Ctx.ctx.getHexColor(R.color.tool_item), 
                                            shapeWithName!!.name )}""".html()
                    .also { Ctx.ctx.statusBarMsg.value = it }
            }
            MotionEvent.ACTION_MOVE -> {
                // move canvas viewport
                if ( shapeWithName == null )
                {
                    val delta = exCanvas.toLogicalViewport( oldLocation ) -
                                exCanvas.toLogicalViewport( evt.location() )
                    exCanvas.logicalViewport = exCanvas.logicalViewport.plus(delta)
                }
                // move shape name
                else
                {
                    val newLogicalTextPosition = exCanvas.toLogicalViewport( evt.location() )
                    val bounds = shapeWithName!!.getBounds()
                    shapeWithName!!.textPosition = Pair(
                                ( newLogicalTextPosition.x - bounds.centerX() ) / bounds.width(),
                                ( newLogicalTextPosition.y - bounds.centerY() ) / bounds.height() )
                }

                oldLocation = evt.location()
                exCanvas.invalidate()
            }
            MotionEvent.ACTION_UP -> {
                // drop shape name
                if ( shapeWithName != null )
                {
                    shapeWithName = null
                    exCanvas.invalidate()
                }
                beforeAction()
            }
        }

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        shapeWithName ?: return

        val paint = defaultToolPaint( Ctx.ctx.exercise.background )
        val bounds = shapeWithName!!.getBounds()
        val logicalPosition = exCanvas.toLogicalViewport( oldLocation )

        // draw segment center-touch
        paint.strokeWidth = if ( Ctx.ctx.scaleStrokeWidth )
                                scaleStrokeWidth( 1f,
                                                  exCanvas.logicalViewport.width(),
                                                  exCanvas.logicalViewport.height(),
                                                  exCanvas.width, exCanvas.height )
                            else
                                1f

        exCanvas.canvas.drawLine( bounds.centerX(), bounds.centerY(),
                                  logicalPosition.x, logicalPosition.y,
                                  paint )
        // draw named shape
        paint.strokeWidth = (if ( Ctx.ctx.scaleStrokeWidth )
                                scaleStrokeWidth( shapeWithName!!.paint.strokeWidth,
                                                  exCanvas.logicalViewport.width(),
                                                  exCanvas.logicalViewport.height(),
                                                  exCanvas.width, exCanvas.height )
                             else
                                 shapeWithName!!.paint.strokeWidth ) + 4f

        exCanvas.canvas.drawPath( shapeWithName!!.path.asPath(), paint )
    }
}
