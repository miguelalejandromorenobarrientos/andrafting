package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.MIN_WIDTH

class ZoomAllAction : ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        if ( Ctx.ctx.exercise.isEmpty() ) return

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        val canvasBounds = Ctx.ctx.exercise.bounds.run {
            if ( this.width() < MIN_WIDTH )
                createRectFFromCenter( this.center(), MIN_WIDTH, MIN_WIDTH )
            else
                this
        }

        val currentAspectRatio = exCanvas.logicalViewport.width() / exCanvas.logicalViewport.height()
        val boundsAspectRatio = canvasBounds.width() / canvasBounds.height()

        if ( boundsAspectRatio >= currentAspectRatio )
            exCanvas.logicalViewport = createRectF(canvasBounds.left, canvasBounds.bottom,
                    canvasBounds.width(), canvasBounds.width() / currentAspectRatio)
        else
            exCanvas.logicalViewport = createRectF(canvasBounds.left, canvasBounds.bottom,
                    canvasBounds.height() * currentAspectRatio, canvasBounds.height())

        exCanvas.logicalViewport.zoom( PointF( exCanvas.logicalViewport.centerX(),
                                               exCanvas.logicalViewport.centerY() ),
                                    1.05f )

        exCanvas.invalidate()
    }
}  // class ZoomAllAction
