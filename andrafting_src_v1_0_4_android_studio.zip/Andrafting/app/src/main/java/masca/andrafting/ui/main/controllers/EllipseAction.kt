package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*
import kotlin.math.abs
import kotlin.math.sqrt

class EllipseAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var draggingPointer = false
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var center: PointF? = null
    private var semiaxis: Pair<Float,Float>? = null

    override fun beforeAction(): EllipseAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPointer = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                draggingPointer = false

                if ( center == null )  // set center
                    center = logicalTouchLocation
                else  // set semi-axis length and add ellipse to exercise
                {
                    semiaxis = (if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                else abs( center!!.x - logicalTouchLocation.x )) to
                               abs( center!!.y - logicalTouchLocation.y )

                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val ellipse = ExerciseShape( "",
                                                 str( R.string.new_ellipse ),
                                                 getEllipse(),
                                                 paint.asSerialPaint( Ctx.ctx.fillColor ) )
                    Ctx.ctx.exercise.add( ellipse )
                    val undoRedoEllipse = UndoRedoableNewShape(
                                                        ellipse, Ctx.ctx.exercise.indexOf(ellipse),
                                                        Ctx.ctx.getString(R.string.new_ellipse) )

                    if ( Ctx.ctx.addAuxiliaryShapes )
                    {
                        val transaction = object: UndoRedoTransaction() {
                            override fun getDescription() = str(R.string.desc_ellipse_transaction)
                        }

                        transaction.add( undoRedoEllipse )

                        // add axis
                        val xAxis = PathSegment(
                                        PointF( center!!.x - semiaxis!!.first, center!!.y ), 0f,
                                        PointF( center!!.x + semiaxis!!.first, center!!.y ), 1f )
                        ExerciseShape( "",
                                       str( R.string.new_x_axis,
                                            Ctx.ctx.getHexColor(R.color.name_item),
                                            elvis(ellipse.name,"?") ),
                                       SerialPath().storeSegment( xAxis ),
                                       paint.asSerialPaint( Ctx.ctx.fillColor ) ).apply {
                               Ctx.ctx.exercise.add( this )
                               transaction.add( UndoRedoableNewShape(
                                            this, Ctx.ctx.exercise.indexOf(this), "X SEMIAXIS" ) )
                        }
                        val yAxis = PathSegment(
                                        PointF( center!!.x, center!!.y + semiaxis!!.second ), 0f,
                                        PointF( center!!.x, center!!.y - semiaxis!!.second ), 1f )
                        ExerciseShape( "",
                                       str( R.string.new_y_axis,
                                            Ctx.ctx.getHexColor(R.color.name_item),
                                            elvis(ellipse.name,"?") ),
                                       SerialPath().storeSegment( yAxis ),
                                       paint.asSerialPaint( Ctx.ctx.fillColor ) ).apply {
                            Ctx.ctx.exercise.add(this)
                            transaction.add( UndoRedoableNewShape(
                                            this, Ctx.ctx.exercise.indexOf(this), "Y SEMIAXIS" ) )
                        }

                        paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                        // add focuses
                        val (sax,say) = semiaxis!!
                        val f1: PointF
                        val f2: PointF
                        if ( sax >= say )
                        {
                            val dist = sqrt( sax*sax - say*say )
                            f1 = PointF( center!!.x - dist, center!!.y )
                            f2 = PointF( center!!.x + dist, center!!.y )
                        }
                        else
                        {
                            val dist = sqrt( say*say - sax*sax )
                            f1 = PointF( center!!.x, center!!.y + dist )
                            f2 = PointF( center!!.x, center!!.y - dist )
                        }
                        for ( focus in arrayOf( f1, f2 ) )
                            ExerciseShape( "",
                                           str( R.string.new_focus_ellipse,
                                                Ctx.ctx.getHexColor(R.color.name_item),
                                                elvis(ellipse.name,"?") ),
                                           SerialPath().storePoint( focus ),
                                           paint.asSerialPaint() ).apply {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                                this, Ctx.ctx.exercise.indexOf(this), "FOCUS" ) )
                            }
                        // add center
                        ExerciseShape( "",
                                       str( R.string.new_center_ellipse,
                                            Ctx.ctx.getHexColor(R.color.name_item),
                                            elvis(ellipse.name,"?") ),
                                       SerialPath().storePoint( center!! ),
                                       paint.asSerialPaint() ).apply {
                            Ctx.ctx.exercise.add(this)
                            transaction.add( UndoRedoableNewShape(
                                    this, Ctx.ctx.exercise.indexOf(this), "CENTER" ) )
                        }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }
                    else
                        Ctx.ctx.undoRedoManager.addItem( undoRedoEllipse )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if ( Ctx.ctx.keepTool ) EllipseAction() else defaultAction)
                            .beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        center ?: return

        // draw circle centered in center
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( center!! ) )

        // draw ellipse
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( getEllipse() ).asPath(), toolPaint )
        }
    }

    private fun getEllipse(): SerialPath
    {
        val semiaxis = (if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                        else abs( center!!.x - logicalTouchLocation.x )) to
                       abs( center!!.y - logicalTouchLocation.y )

        return SerialPath().storeEllipse( center!!, semiaxis.first, semiaxis.second )
    }

    private fun setStatusBar()
    {
        val txt = when {

            center == null ->
                str(R.string.status_ellipse2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_ellipse3,Ctx.ctx.getHexColor(R.color.tool_item) )

        }.let {
            "${str(R.string.status_ellipse1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class EllipseAction
