package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.LayoutInflater
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.*
import org.w3c.dom.Document
import org.w3c.dom.Node
import java.io.IOException
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dialog for create SVG file from exercise
 */
class SaveSvgDialogFragment: DialogFragment()
{
    companion object
    {
        lateinit var uri: Uri
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        // create root
        val root = LayoutInflater.from( MAct.act ).inflate( R.layout.save_svg_dialog, null )

        val editFilename = root.findViewById<EditText>(R.id.edit_filename)
        editFilename.setText( uri.path )

        val checkDrawNames = root.findViewById<CheckBox>(R.id.check_draw_names)
        val checkDrawBackground = root.findViewById<CheckBox>(R.id.check_draw_background)
        val checkDrawBounds = root.findViewById<CheckBox>(R.id.check_draw_bounds)

        // create dialog
        return AlertDialog.Builder( MAct.act )
                .setView( root )
                .setTitle( R.string.btn_export_svg )
                .setIcon( R.mipmap.svg_export )
                .setPositiveButton( R.string.btn_ok ) { _, _ ->
                    // save SVG
                    val showNames = checkDrawNames.isChecked
                    val drawBackground = checkDrawBackground.isChecked
                    val drawBounds = checkDrawBounds.isChecked
                    saveSvg( uri, drawBackground, showNames, drawBounds )
                }
                .setNegativeButton( R.string.btn_cancel ) { _, _ ->
                    if ( !DocumentsContract.deleteDocument( Ctx.ctx.contentResolver, uri ) )
                        Toast.makeText( MAct.act, "Can't delete ${uri.path}",
                                Toast.LENGTH_SHORT ).show()
                }
                .create().apply {
                    window?.setBackgroundDrawable(
                            AppCompatResources.getDrawable( MAct.act, R.drawable.dialog_background ) )
                }
    }

}  // class SaveSvgDialogFragment


fun saveSvg( uri: Uri,
             drawBackground: Boolean = false,
             drawNames: Boolean = true,
             drawBounds: Boolean = false )
{
    // exercise bounds with margin
    val bounds = Ctx.ctx.exercise.bounds.apply { inset( -width()*0.02f, -height()*0.02f ) }

    // initialize XML document
    val builderFactory: DocumentBuilderFactory = DocumentBuilderFactory.newInstance()
    val docBuilder = builderFactory.newDocumentBuilder()
    val doc = docBuilder.newDocument()

    // create document
    doc.br( doc )
    doc.appendChild( doc.createComment( "Created with $APPNAME v${BuildConfig.VERSION_NAME}" ) )
    doc.br( doc )
    val svgElem = doc.createElement( "svg" ).apply {
        setAttribute( "xmlns", "http://www.w3.org/2000/svg" )
        setAttribute( "viewBox", "${bounds.left} ${bounds.top} ${bounds.width()} ${bounds.height()}" )
    }
    doc.appendChild( svgElem )
    svgElem.br( doc )

    // title
    if ( Ctx.ctx.exercise.title.isNotBlank() )
    {
        svgElem.appendChild(doc.createElement("title").apply {
            textContent = Ctx.ctx.exercise.title
        })
        svgElem.br(doc)
    }

    // description as comment
    if ( Ctx.ctx.exercise.description.isNotBlank() )
    {
        svgElem.appendChild( doc.createComment( "Description: " + Ctx.ctx.exercise.description ) )
        svgElem.br(doc)
    }

    // background
    if ( drawBackground )
    {
        svgElem.appendChild(doc.createElement("rect").apply {
            setAttribute("id", "__canvas background__")
            setAttribute("x", "${bounds.left}")
            setAttribute("y", "${bounds.top}")
            setAttribute("width", "${bounds.width()}")
            setAttribute("height", "${bounds.height()}")
            setAttribute("style", "fill:#${Integer.toHexString(Ctx.ctx.exercise.background).substring(2)}; stroke:none;")
        })
        svgElem.br( doc )
    }

    // main group, draw shapes
    val gElem = doc.createElement( "g" ).apply {
        setAttribute( "id", "__shapes group__" )
        for ( shape in Ctx.ctx.exercise )
        {
            br( doc )
            // append shape
            appendChild( nodeFromShape( doc, shape, bounds ) )
            // append arrowheads
            if ( shape.isArrow )
            {
                br(doc)
                appendChild( arrowhead( shape, doc,
                                        "matrix(1,0,0,-1,0,${(bounds.height() + 2*bounds.top)})") )
            }
            // append shape name
            if (drawNames && shape.name.isNotBlank() )
            {
                br(doc)
                appendChild( shapeNameNode( doc, shape, bounds ) )
            }
        }
        br( doc )
    }
    svgElem.appendChild( gElem )
    svgElem.br( doc )

    // bounds
    if ( drawBounds )
    {
        svgElem.appendChild( doc.createElement("rect").apply {
            setAttribute("id", "__bounds__")
            setAttribute("x", "${bounds.left+2}")
            setAttribute("y", "${bounds.top+2}")
            setAttribute("width", "${bounds.width()-4}")
            setAttribute("height", "${bounds.height()-4}")
            setAttribute("style", "stroke-width:3; " +
                                  "fill:none; " +
                                  "stroke:black; " +
                                  "stroke-opacity:0.05;")
        })
        svgElem.br( doc )
    }

    // SAVE to file
    val tranFactory: TransformerFactory = TransformerFactory.newInstance()
    val aTransformer = tranFactory.newTransformer()
    val src = DOMSource( doc )
    try
    {
        val dest = StreamResult( Ctx.ctx.contentResolver.openOutputStream(uri) )
        aTransformer.transform( src, dest )
        Toast.makeText( MAct.act, str(R.string.toast_file_saved_in,uri.path ?: "?").html(),
                        Toast.LENGTH_LONG ).show()
    }
    catch ( ex: IOException )
    {
        Toast.makeText( MAct.act, ex.message, Toast.LENGTH_LONG ).show()
    }
}

private fun Node.br( doc: Document ) = appendChild( doc.createTextNode( "\n" ) )!!

private fun nodeFromShape( doc: Document, shape: ExerciseShape, bounds: RectF ): Node
{
    val transform = "matrix(1,0,0,-1,0,${(bounds.height() + 2*bounds.top)})"

    if ( shape.path.isPoint() )
        return doc.createElement( "circle" ).apply {
            if ( shape.name.isNotBlank() )
                setAttribute( "id", shape.name )
            setAttribute( "transform", transform )
            setAttribute( "cx", shape.path.first().coords[0].toString() )
            setAttribute( "cy", shape.path.first().coords[1].toString() )
            setAttribute( "r", (shape.paint.strokeWidth / 2f).toString() )
            setAttribute( "style", "fill:#${Integer.toHexString(shape.paint.color).substring(2)}; " +
                                   "fill-opacity:${Color.alpha(shape.paint.color)/255f}; " +
                                   "stroke:none;" )
        }

    if ( shape.isComment )
        return doc.createElement( "g" ).apply {
            br(doc)

            if ( shape.name.isNotBlank() )
                setAttribute( "id", shape.name )

            // text background
            shape.paint.fill?.let {
                appendChild(doc.createElement("rect").apply {
                    if ( shape.name.isNotBlank() )
                        setAttribute("id", "${shape.name}: background")
                    setAttribute( "transform", transform )
                    setAttribute("x", shape.getBounds().left.toString())
                    setAttribute("y", shape.getBounds().top.toString())
                    setAttribute("width", shape.getBounds().width().toString())
                    setAttribute("height", shape.getBounds().height().toString())
                    setAttribute("style", "stroke:none; " +
                                          "fill:#${Integer.toHexString(it).substring(2)};")
                })
                br(doc)
            }

            val lines = shape.description.split( "\n" )

            for ( (idx,line) in lines.withIndex() )
                if ( line.isNotBlank() )
                {
                    appendChild(doc.createElement("text").apply {
                        textContent = line.html().toString()
                        if (shape.name.isNotBlank())
                            setAttribute("id", "${shape.name}: line ${idx + 1}")
                        setAttribute("x", shape.getBounds().left.toString())
                        val textBounds = multiLineTextBounds( lines, shape.paint.asPaint() )
                        val textSize = getFontAdjustedToBounds( shape.getBounds(), textBounds, shape.paint.textSize )
                        setAttribute("y", (-shape.getBounds().bottom + bounds.height() + 2 * bounds.top + (idx + 1) * textSize).toString())
                        setAttribute( "font-size", "${textSize}px" )
                        setAttribute( "font-family", shape.paint.textFamily )
                        setAttribute( "font-style", if ( shape.paint.textStyle and 2 == Typeface.ITALIC ) "italic" else "normal" )
                        setAttribute( "font-weight", if ( shape.paint.textStyle and 1 == Typeface.BOLD ) "bold" else "normal" )
                        setAttribute( "style", "fill:#${Integer.toHexString(shape.paint.color).substring(2)}; " +
                                               "fill-opacity:${Color.alpha(shape.paint.color) / 255f}; " +
                                               "stroke:none; " )
                    })
                    br(doc)
                }
        }  // g tag

    val d = StringBuilder()

    for ( segment in shape.path )
        when( segment.type )
        {
            SerialPath.SegmentType.MOVE -> d.append( "M ${segment.coords[0]},${segment.coords[1]} " )
            SerialPath.SegmentType.LINE -> d.append( "L ${segment.coords[0]},${segment.coords[1]} " )
            SerialPath.SegmentType.CLOSE -> d.append( "Z " )
            SerialPath.SegmentType.QUAD -> d.append( "Q ${segment.coords[0]},${segment.coords[1]} ${segment.coords[2]},${segment.coords[3]} " )
            SerialPath.SegmentType.CUBIC -> d.append( "C ${segment.coords[0]},${segment.coords[1]} ${segment.coords[2]},${segment.coords[3]} ${segment.coords[4]},${segment.coords[5]} " )
        }

    return doc.createElement( "path" ).apply {
        if ( shape.name.isNotBlank() )
            setAttribute( "id", shape.name )
        setAttribute( "transform", transform )
        setAttribute( "d", d.toString() )
        setAttribute( "style", "stroke-width:${shape.paint.strokeWidth}; " +
                               "stroke:#${Integer.toHexString(shape.paint.color).substring(2)}; " +
                               "stroke-opacity:${Color.alpha(shape.paint.color)/255f}; " +
                               "fill:${shape.paint.fill?.let { "#" + Integer.toHexString(it).substring(2) } ?: "none"}; " +
                               "fill-opacity:${shape.paint.fill?.let { Color.alpha(it)/255f } ?: "1"}; " +
                               "stroke-linejoin:${shape.paint.strokeJoin.toString().lowercase()}; " +
                               "stroke-linecap:${shape.paint.strokeCap.toString().lowercase()}; " +
                               "stroke-dasharray:${shape.paint.dashPathEffect?.joinToString(separator=",") ?: "none"}; " )
    }  // apply path element
}


fun shapeNameNode( doc: Document, shape: ExerciseShape, bounds: RectF ) =
    doc.createElement( "text" ).apply {
        textContent = shape.name
        if ( shape.name.isNotBlank() )
            setAttribute( "id", "shape name: ${shape.name}" )
        val pos = getShapeNamePosition( shape )
        setAttribute( "x", pos.x.toString() )
        setAttribute( "y", (-pos.y + bounds.height() + 2 * bounds.top).toString() )
        setAttribute( "style", "stroke:none; " +
                               "fill:#${Integer.toHexString(shape.paint.color).substring(2)}; " +
                               "fill-opacity:0.75; " )
        setAttribute( "font-size", "${SHAPE_NAME_SIZE}px" )
        setAttribute( "font-weight", "bold" )
        setAttribute( "font-family", "Arial" )
    }!!


fun arrowhead( shape: ExerciseShape, doc: Document, transform: String ) =
    doc.createElement( "path" ).apply {
        val p = shape.path.first().getPoint(0)
        val q = shape.path.last().getPoint(0)
        val ang = (q - p).arg()
        val d = StringBuilder()
        val radius = 30f
        val arrowheadAngle = Math.toRadians( 20.0 ).toFloat()
        var alpha = ang + PIf - arrowheadAngle / 2f
        var bx = q.x + cos(alpha)*radius
        var by = q.y + sin(alpha)*radius
        alpha = ang + PIf + arrowheadAngle / 2f
        var cx = q.x + cos(alpha)*radius
        var cy = q.y + sin(alpha)*radius
        d.append( "M ${q.x},${q.y} L ${bx},${by} L ${cx},${cy} Z " )
        if ( shape.arrowType == ExerciseShape.Arrow.DOUBLE )
        {
            alpha = ang + arrowheadAngle / 2f
            bx = p.x + cos(alpha)*radius
            by = p.y + sin(alpha)*radius
            alpha = ang - arrowheadAngle / 2f
            cx = p.x + cos(alpha)*radius
            cy = p.y + sin(alpha)*radius
            d.append( "M ${p.x},${p.y} L ${bx},${by} L ${cx},${cy} Z " )
        }
        setAttribute( "transform", transform )
        setAttribute( "d", d.toString() )
        if ( shape.name.isNotBlank() )
            setAttribute( "id", "arrowhead/s: ${shape.name}" )
        setAttribute( "style", "fill:#${Integer.toHexString(shape.paint.color).substring(2)}; " +
                               "fill-opacity:${Color.alpha(shape.paint.color)/255f}; " +
                               "stroke-width:${shape.paint.strokeWidth}; " +
                               "stroke:#${Integer.toHexString(shape.paint.color).substring(2)}; " +
                               "stroke-opacity:${Color.alpha(shape.paint.color)/255f}; " )
    }!!
