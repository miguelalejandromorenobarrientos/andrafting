package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Matrix
import android.os.Bundle
import android.view.LayoutInflater
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ToggleButton
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.str
import kotlin.math.max
import kotlin.math.min

class HomothetyAction: CentralSymmetry()
{
    override val descOp = R.string.desc_homothety
    override val status1 = R.string.status_homothety1
    override val status2 = R.string.status_homothety2

    companion object
    {
        var xFactor = 2f
        var yFactor = 2f
    }

    override val getMatrix: Matrix
        get() {
            val center = start ?: logicalTouchLocation

            return Matrix().apply {
                preTranslate( center.x, center.y )
                preScale( xFactor, yFactor )
                preTranslate( -center.x, -center.y )
            }
        }


    override fun beforeAction(): HomothetyAction
    {
        super.beforeAction()

        if ( Ctx.ctx.selectedShapes.isEmpty() )
            return this

        xFactor = 2f
        yFactor = 2f

        HomothetyDialogFragment().show( MAct.act.supportFragmentManager, "tag HomothetyDialog" )

        return this
    }

}  // class HomothetyAction


class HomothetyDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        // create factor dialog
        val root = LayoutInflater.from( Ctx.ctx ).inflate( R.layout.homothety_dialog, null )
        val xEdit = root.findViewById<EditText>( R.id.edit_x_factor ).apply {
            setText( HomothetyAction.xFactor.toString() )
        }
        val yEdit = root.findViewById<EditText>( R.id.edit_y_factor ).apply {
            setText( HomothetyAction.yFactor.toString() )
        }
        val btnLock = root.findViewById<ToggleButton>( R.id.btn_lock )

        fun setXFromY()
        {
            if ( btnLock.isChecked )
            {
                xEdit.text = yEdit.text
                HomothetyAction.xFactor = HomothetyAction.yFactor
            }
        }
        fun setYFromX()
        {
            if ( btnLock.isChecked )
            {
                yEdit.text = xEdit.text
                HomothetyAction.yFactor = HomothetyAction.xFactor
            }
        }

        root.findViewById<Button>( R.id.btn_dec_x_factor ).apply {
            setOnClickListener {
                HomothetyAction.xFactor = max(1f, HomothetyAction.xFactor - 1)
                format2(HomothetyAction.xFactor).also { xEdit.setText(it) }
                setYFromX()
            }
            setOnLongClickListener {
                HomothetyAction.xFactor = max(0.1f, HomothetyAction.xFactor - 0.1f)
                format2(HomothetyAction.xFactor).also { xEdit.setText(it) }
                setYFromX()
                true
            }
        }
        root.findViewById<Button>( R.id.btn_inc_x_factor ).apply {
            setOnClickListener {
                HomothetyAction.xFactor = min( 100f, HomothetyAction.xFactor + 1 )
                format2(HomothetyAction.xFactor).also { xEdit.setText( it ) }
                setYFromX()
            }
            setOnLongClickListener {
                HomothetyAction.xFactor = min( 100f, HomothetyAction.xFactor + 0.1f )
                format2(HomothetyAction.xFactor).also { xEdit.setText( it ) }
                setYFromX()
                true
            }
        }
        root.findViewById<Button>( R.id.btn_dec_y_factor ).apply {
            setOnClickListener {
                HomothetyAction.yFactor = max( 1f, HomothetyAction.yFactor - 1 )
                format2(HomothetyAction.yFactor).also { yEdit.setText(it) }
                setXFromY()
            }
            setOnLongClickListener {
                HomothetyAction.yFactor = max(0.1f, HomothetyAction.yFactor - 0.1f)
                format2(HomothetyAction.yFactor).also { yEdit.setText(it) }
                setXFromY()
                true
            }
        }
        root.findViewById<Button>( R.id.btn_inc_y_factor ).apply {
            setOnClickListener {
                HomothetyAction.yFactor = min( 100f, HomothetyAction.yFactor + 1 )
                format2(HomothetyAction.yFactor).also { yEdit.setText( it ) }
                setXFromY()
            }
            setOnLongClickListener {
                HomothetyAction.yFactor = min( 100f, HomothetyAction.yFactor + 0.1f )
                format2(HomothetyAction.yFactor).also { yEdit.setText( it ) }
                setXFromY()
                true
            }
        }
        with( xEdit )
        {
            setOnEditorActionListener { _, _, _ ->
                try
                {
                    val value = text.toString().toFloat()
                    if ( value !in 0.01f..100f )
                        throw NumberFormatException( str( R.string.errmsg_homo_factor ) )
                    HomothetyAction.xFactor = value
                    val imm: InputMethodManager? =
                            MAct.act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
                    imm?.hideSoftInputFromWindow( MAct.act.currentFocus?.windowToken, 0)
                    setYFromX()
                }
                catch ( e: NumberFormatException )
                {
                    AlertDialog.Builder(MAct.act)
                            .setTitle( R.string.hint_x_factor )
                            .setIcon( R.mipmap.error_icon )
                            .setMessage( e.message!!.html() )
                            .show()
                }
                true
            }
        }
        with( yEdit )
        {
            setOnEditorActionListener { _, _, _ ->
                try
                {
                    val value = text.toString().toFloat()
                    if ( value !in 0.01f..100f )
                        throw NumberFormatException( str( R.string.errmsg_homo_factor ) )
                    HomothetyAction.yFactor = value
                    val imm: InputMethodManager? =
                            MAct.act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
                    imm?.hideSoftInputFromWindow( MAct.act.currentFocus?.windowToken, 0)
                    setXFromY()
                }
                catch ( e: NumberFormatException )
                {
                    AlertDialog.Builder(MAct.act)
                            .setTitle( R.string.hint_x_factor )
                            .setIcon( R.mipmap.error_icon )
                            .setMessage( e.message!!.html() )
                            .show()
                }
                true
            }
        }

        return AlertDialog.Builder( MAct.act )
                .setView( root )
                .setMessage( str(R.string.msg_homothety).html() )
                .setTitle( R.string.btn_homothety )
                .setIcon( R.mipmap.homothety )
                .setPositiveButton( R.string.btn_ok, null )
                .setNegativeButton( R.string.btn_cancel ) { dialog, _ ->
                    dialog.cancel()
                    Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
                }
                .create().apply {
                    window?.setBackgroundDrawable(
                            AppCompatResources.getDrawable(MAct.act, R.drawable.dialog_background))
                }
    }
}  // class HomothetyDialogFragment
