package masca.andrafting.ui.main.controllers

import android.graphics.Matrix
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*
import kotlin.math.max
import kotlin.math.min

class ParabolaAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var draggingPointer = false
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var start: PointF? = null

    override fun beforeAction(): ParabolaAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPointer = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                draggingPointer = false

                if ( start == null )  // set bounds start
                    start = logicalTouchLocation
                else  // add parabola to exercise
                {
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val parabolaParams = getParabola()

                    val parabola = ExerciseShape( "",
                                                  str( R.string.new_parabola ),
                                                  parabolaParams["parabola"] as SerialPath,
                                                  paint.asSerialPaint( Ctx.ctx.fillColor ) )
                    Ctx.ctx.exercise.add( parabola )
                    val undoRedoParabola = UndoRedoableNewShape(
                                                    parabola, Ctx.ctx.exercise.indexOf(parabola),
                                                    Ctx.ctx.getString(R.string.new_parabola) )

                    if ( Ctx.ctx.addAuxiliaryShapes || Ctx.ctx.addExtremes )
                    {
                        val transaction = object: UndoRedoTransaction() {
                            override fun getDescription() = "${str(R.string.new_parabola)} ${if(Ctx.ctx.addExtremes) str(R.string.undoredo_and_extremes).format(2) else ""} ${if(Ctx.ctx.addAuxiliaryShapes) str(R.string.desc_auxiliary_shapes) else ""}"
                        }

                        transaction.add( undoRedoParabola )

                        if ( Ctx.ctx.addAuxiliaryShapes )
                        {
                            // add directrix
                            ExerciseShape( "",
                                           str(R.string.new_directrix,
                                           Ctx.ctx.getHexColor(R.color.name_item),
                                           elvis(parabola.name, "?") ),
                                           SerialPath().storeSegment(
                                                       parabolaParams["directrix"] as PathSegment ),
                                           paint.asSerialPaint() ).apply {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                            this, Ctx.ctx.exercise.indexOf(this), "DIRECTRIX" ) )
                            }

                            paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor )

                            // add focus
                            ExerciseShape( "",
                                           str(R.string.new_focus_parabola,
                                           Ctx.ctx.getHexColor(R.color.name_item),
                                           elvis(parabola.name, "?") ),
                                    SerialPath().storePoint(parabolaParams["focus"] as PointF),
                                    paint.asSerialPaint() ).apply {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                                   this, Ctx.ctx.exercise.indexOf(this), "FOCUS" ) )
                            }
                            // add vertex
                            ExerciseShape( "",
                                           str(R.string.new_vertex_parabola,
                                           Ctx.ctx.getHexColor(R.color.name_item),
                                           elvis(parabola.name, "?") ),
                                        SerialPath().storePoint(parabolaParams["vertex"] as PointF),
                                        paint.asSerialPaint() ).apply {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                                  this, Ctx.ctx.exercise.indexOf(this), "VERTEX" ) )
                            }
                        }
                        if ( Ctx.ctx.addExtremes )
                        {
                            paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor )

                            for ( extreme in arrayOf( parabola.path.getPolySegments().first().start,
                                                      parabola.path.getPolySegments().last().end ) )
                                ExerciseShape( "",
                                               str(R.string.desc_extremes2,
                                                   Ctx.ctx.getHexColor(R.color.name_item),
                                                   elvis(parabola.name,"?")),
                                               SerialPath().storePoint(extreme),
                                               paint.asSerialPaint() ).run {
                                    Ctx.ctx.exercise.add(this)
                                    transaction.add( UndoRedoableNewShape(
                                                        this,
                                                        Ctx.ctx.exercise.indexOf(this),
                                                        "${str(R.string.new_point)} [extreme]" ) )
                                }
                        }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }
                    else
                        Ctx.ctx.undoRedoManager.addItem( undoRedoParabola )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if ( Ctx.ctx.keepTool ) ParabolaAction() else defaultAction)
                            .beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        start ?: return

        // draw circle centered in start point
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw parabola
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical(
                                    getParabola()["parabola"] as SerialPath ).asPath(), toolPaint )
        }
    }

    private fun getParabola(): Map<String,Any>
    {
        val x = if ( Ctx.ctx.useRuler )
                    (if ( start!!.x > logicalTouchLocation.x ) start!!.x - Ctx.ctx.rulerDistanceMul
                     else start!!.x + Ctx.ctx.rulerDistanceMul )
                else
                    logicalTouchLocation.x
        val minX = min( start!!.x, x )
        val maxX = max( start!!.x, x )
        val minY = min( start!!.y, logicalTouchLocation.y )
        val maxY = max( start!!.y, logicalTouchLocation.y )
        val w = maxX - minX
        val h = maxY - minY
        val a = 4*h / (w*w)  // y=ax^2

        val mapResult = mutableMapOf<String,Any>()

        // set parabola
        val improper = start!! == logicalTouchLocation
        mapResult["parabola"] = SerialPath().apply {
            if ( !improper )
            {
                val nodeList = mutableListOf<PointF>()
                for ( i in 0 until N )
                {
                    val xp = -w / 2f + w / (N - 1) * i
                    val yp = a * xp * xp
                    nodeList.add( PointF( xp, yp ) )
                }
                storeSpline( *nodeList.toTypedArray() )
            }
            else  // improper case, a point
                storePoint( PointF() )
        }
        // set vertex
        val vertex = PointF( (minX + maxX) / 2f, minY )
        mapResult["vertex"] = vertex
        // set focus
        mapResult["focus"] = if ( !improper ) PointF( vertex.x, minY + 1f / (4f*a) ) else start!!
        // set directrix
        val yd = minY - 1f / (4f*a)
        mapResult["directrix"] = if ( !improper )
                                     PathSegment( PointF( minX, yd ), 0f, PointF( maxX, yd ), 1f )
                                 else
                                     PathSegment( start!!, 0f, start!!, 1f )

        // translate parabola to vertex
        (mapResult["parabola"] as SerialPath)
            .transform( Matrix().apply { preTranslate( vertex.x, vertex.y ) } )

        return mapResult
    }

    private fun setStatusBar()
    {
        val txt = when {

            start == null ->
                str(R.string.status_parabola2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_parabola3,Ctx.ctx.getHexColor(R.color.tool_item) )

        }.let {
            "${str(R.string.status_parabola1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class ParabolaAction

private const val N = 60  // DIVISIONS