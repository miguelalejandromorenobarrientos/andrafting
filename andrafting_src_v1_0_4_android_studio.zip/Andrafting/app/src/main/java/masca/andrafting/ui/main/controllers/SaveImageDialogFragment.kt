package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.LayoutInflater
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.drawExercise
import masca.andrafting.ui.main.str
import java.io.IOException
import kotlin.math.ceil
import kotlin.math.max


/**
 * Dialog for create PNG image from exercise
 */
class SaveImageDialogFragment: DialogFragment()
{
    companion object
    {
        lateinit var uri: Uri
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        val exBounds = Ctx.ctx.exercise.bounds
        val aspectRatio = exBounds.width() / exBounds.height()
        var imgWidth = 1000/*ceil( Ctx.ctx.exercise.bounds.width() ).toInt()*/
        var imgHeight = ceil( imgWidth / aspectRatio ).toInt()

        // create root
        val root = LayoutInflater.from( MAct.act ).inflate( R.layout.save_img_dialog, null )

        val editFilename = root.findViewById<EditText>(R.id.edit_filename)
        editFilename.setText( uri.path )
        val editHeight = root.findViewById<EditText>(R.id.edit_height)
        editHeight.setText( imgHeight.toString() )
        val editWidth = root.findViewById<EditText>(R.id.edit_width).apply {
            setOnEditorActionListener { _, _, _ ->
                imgWidth = text.toString().toInt()
                imgHeight = ceil( imgWidth / aspectRatio ).toInt()
                editHeight.setText( imgHeight.toString() )
                true
            }
            setOnFocusChangeListener { _, _ ->
                imgWidth = text.toString().toInt()
                imgHeight = ceil( imgWidth / aspectRatio ).toInt()
                editHeight.setText( imgHeight.toString() )
            }
            setText( imgWidth.toString() )
        }
        val checkDrawNames = root.findViewById<CheckBox>(R.id.check_draw_names)
        val checkDrawBackground = root.findViewById<CheckBox>(R.id.check_draw_background)
        val checkDrawBounds = root.findViewById<CheckBox>(R.id.check_draw_bounds)
        val checkScale = root.findViewById<CheckBox>(R.id.check_scale_stroke)

        // create dialog
        return AlertDialog.Builder( MAct.act )
                .setView( root )
                .setTitle( R.string.btn_save_img )
                .setIcon( R.mipmap.save_image )
                .setPositiveButton( R.string.btn_ok ) { _, _ ->
                    // save image
                    val showNames = checkDrawNames.isChecked
                    val drawBackground = checkDrawBackground.isChecked
                    val drawBounds = checkDrawBounds.isChecked
                    val scale = checkScale.isChecked
                    imgWidth = editWidth.text.toString().toInt()
                    imgHeight = editHeight.text.toString().toInt()
                    savePng( uri, imgWidth, imgHeight, drawBackground, showNames, drawBounds,
                             scale )
                }
                .setNegativeButton( R.string.btn_cancel ) { _, _ ->
                    if ( !DocumentsContract.deleteDocument( Ctx.ctx.contentResolver, uri ) )
                        Toast.makeText( MAct.act, "Can't delete ${uri.path}",
                                Toast.LENGTH_SHORT ).show()
                }
                .create().apply {
                    window?.setBackgroundDrawable(
                            AppCompatResources.getDrawable( MAct.act, R.drawable.dialog_background ) )
                }
    }

}  // class SaveImageDialogFragment


@Suppress("NAME_SHADOWING")
fun savePng( uri: Uri,
             imgWidth: Int,
             imgHeight: Int,
             drawBackground: Boolean = false,
             showNames: Boolean = true,
             drawBounds: Boolean = false,
             scale: Boolean = true )
{
    val imgWidth = max( 1, imgWidth )
    val imgHeight = max( 1, imgHeight )

    val img = Bitmap.createBitmap( imgWidth, imgHeight, Bitmap.Config.ARGB_8888 )
    val canvas = Canvas( img )
    var logicalViewport = Ctx.ctx.exercise.bounds
    logicalViewport = createRectFFromCenter( logicalViewport.center(),
            logicalViewport.width() * 1.05f,
            logicalViewport.height() * 1.05f )  // add margin

    canvas.setMatrix( logicalViewport.getTransformMatrix(
            RectF( 0f, 0f, img.width.toFloat(), img.height.toFloat() ) ) )

    drawExercise( Ctx.ctx.exercise,
                  canvas,
                  logicalViewport,
                  arrayListOf(),
                  scaleStroke=scale,
                  showNames=showNames,
                  drawBackground=drawBackground,
                  drawBounds=drawBounds )

    val imgInverted = Bitmap.createBitmap( imgWidth, imgHeight, Bitmap.Config.ARGB_8888 )
    val canvasFinal = Canvas( imgInverted )

    canvasFinal.drawBitmap( img, Matrix().apply {
        postScale( 1f, -1f )
        postTranslate( 0f, img.height.toFloat() )
    }, null )

    // write image
    try
    {
        Ctx.ctx.contentResolver.openOutputStream(uri).use { out ->
            imgInverted.compress( Bitmap.CompressFormat.PNG, 100, out )  // PNG is a lossless format, the compression factor (100) is ignored
        }
        Toast.makeText( MAct.act, str(R.string.toast_file_saved_in,uri.path ?: "?").html(),
                        Toast.LENGTH_LONG ).show()
    }
    catch ( ex: IOException )
    {
        Toast.makeText( MAct.act, ex.message, Toast.LENGTH_LONG ).show()
    }
}
