package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import masca.andrafting.MAct
import masca.andrafting.ui.main.Ctx

class SelectAllAction: ActionListener
{
    override fun action(view: View?, evt: InputEvent?)
    {
        Ctx.ctx.selectedShapes = ArrayList( Ctx.ctx.exercise )

        MAct.act.getCanvas()?.invalidate()
        MAct.act.updateShapeList()
    }
}