package masca.andrafting.ui.main

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import masca.andrafting.R
import masca.andrafting.clip
import masca.andrafting.drawLineDashedFromPath
import kotlin.math.min

class SpinnerStrokeStyle( context: Context, attributeSet: AttributeSet )
    : androidx.appcompat.widget.AppCompatSpinner( context, attributeSet )
{
    init
    {
        adapter = SpinnerStrokeStyleAdapter( context )

        onItemSelectedListener = object: OnItemSelectedListener {
            override fun onItemSelected( parent: AdapterView<*>?,
                                         view: View?,
                                         position: Int,
                                         id: Long )
            {
                Ctx.ctx.dashPathEffect = ARRAY_STROKES[position].second
            }

            override fun onNothingSelected(parent: AdapterView<*>?) { updateSelection() }
        }
    }

    fun updateSelection() = setSelection( ARRAY_STROKES.indexOfFirst {
        Ctx.ctx.dashPathEffect.contentEquals(it.second)
    })

    override fun getAdapter() = super.getAdapter() as? SpinnerStrokeStyleAdapter

    class SpinnerStrokeStyleAdapter(context: Context) :
        ArrayAdapter<Pair<String, FloatArray?>>(context, R.layout.spinner_stroke, ARRAY_STROKES)
    {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View
        {
            var rootView = convertView

            if ( rootView == null )
                rootView = LayoutInflater.from( context ).inflate(
                                                R.layout.spinner_stroke, parent, false )

            rootView = rootView!!

            val txtName = rootView.findViewById<TextView>(R.id.txt_name)
            val canvas = rootView.findViewById<StrokeCanvas>(R.id.stroke_canvas)

            txtName.text = ARRAY_STROKES[position].first
            canvas.pattern = ARRAY_STROKES[position].second

            return rootView
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup)
                = getView( position, convertView, parent )

    }  // class SpinnerStrokeStyleAdapter

    class StrokeCanvas( context : Context, attr : AttributeSet ) : View( context, attr )
    {
        var pattern: FloatArray? = null

        @SuppressLint("DrawAllocation")
        override fun onDraw( canvas: Canvas)
        {
            canvas.drawColor( Ctx.ctx.exercise.background )
            val paint = Paint().apply {
                strokeWidth = Ctx.ctx.strokeWidth clip  1f..5f
                color = Ctx.ctx.strokeColor
                style = Paint.Style.STROKE
                isAntiAlias = true
                isDither = true
                strokeCap = Ctx.ctx.cap
                strokeJoin = Ctx.ctx.join
            }

            if ( pattern == null )
                canvas.drawLine( 2f, height / 2f, width - 2f, height/ 2f, paint )
            else
                canvas.drawLineDashedFromPath(
                        Path(),
                        PointF( min( paint.strokeWidth, 8f ) + 1f, height / 2f ),
                        PointF( width - 1f - min( paint.strokeWidth, 8f ), height / 2f ),
                        paint,
                        pattern!!.clone().apply { forEachIndexed { i, v ->
                            this[i] = v * paint.strokeWidth }
                        },
                        0f )
        }
    }  // class StrokeCanvas

}  // class SpinnerStrokeStyle
