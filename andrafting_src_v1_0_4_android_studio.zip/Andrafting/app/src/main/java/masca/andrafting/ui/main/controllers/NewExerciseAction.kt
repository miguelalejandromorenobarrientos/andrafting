package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.graphics.RectF
import android.view.InputEvent
import android.view.View
import masca.andrafting.Exercise
import masca.andrafting.MAct
import masca.andrafting.R
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ShapeList

class NewExerciseAction: ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        with( Ctx.ctx )
        {
            if ( undoRedoManager.canUndo() || undoRedoManager.canRedo())
                AlertDialog.Builder(MAct.act)
                    .setIcon( R.mipmap.new_exercise )
                    .setTitle( R.string.title_exit )
                    .setPositiveButton( R.string.btn_ok ) { _, _ -> new() }
                    .setNegativeButton( R.string.btn_cancel, null )
                    .show()
            else
                new()
        }
    }

    private fun new()
    {
        Ctx.ctx.exercise = Exercise()
        Ctx.ctx.undoRedoManager.clearAll()
        Ctx.ctx.currentFile = null
        Ctx.ctx.currentActionForCanvas.value = NoAction().beforeAction()
        MAct.act.getCanvas()?.logicalViewport = RectF( -1000f, -1000f, 1000f, 1000f )
        MAct.act.getShapeList()?.adapter =
                ShapeList.ShapeListAdapter( MAct.act, R.layout.listitem_shape, Ctx.ctx.exercise )
    }

}  // class NewExerciseAction