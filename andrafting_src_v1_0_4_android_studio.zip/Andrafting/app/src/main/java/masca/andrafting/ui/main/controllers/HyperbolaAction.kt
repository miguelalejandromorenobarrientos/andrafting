package masca.andrafting.ui.main.controllers

import android.graphics.Matrix
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class HyperbolaAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var draggingPointer = false
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var start: PointF? = null

    override fun beforeAction(): HyperbolaAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPointer = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( start == null )  // set bounds start
                    start = logicalTouchLocation
                else  // add hyperbola to exercise
                {
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect)

                    val transaction = object: UndoRedoTransaction() {
                        override fun getDescription() = "${str(R.string.new_hyperbola)} ${
                            if (Ctx.ctx.addExtremes) str(R.string.undoredo_and_extremes).format(4) else ""
                        } ${if (Ctx.ctx.addAuxiliaryShapes) str(R.string.desc_auxiliary_shapes) else ""}"
                    }

                    val hyperbolaParams = getHyperbola()

                    // add branches
                    for (param in arrayOf("branch1", "branch2"))
                        ExerciseShape("",
                                str(R.string.new_hyperbola_branch),
                                hyperbolaParams[param] as SerialPath,
                                paint.asSerialPaint(Ctx.ctx.fillColor)).apply {
                            Ctx.ctx.exercise.add(this)
                            transaction.add( UndoRedoableNewShape(
                                    this, Ctx.ctx.exercise.indexOf(this), "HYPERBOLA BRANCH"))
                        }

                    if (Ctx.ctx.addAuxiliaryShapes)
                    {
                        // add main axis
                        ExerciseShape("",
                                str(R.string.new_main_axis,
                                        Ctx.ctx.getHexColor(R.color.name_item),
                                        "?"),
                                SerialPath().storeSegment(
                                        hyperbolaParams["main_axis"] as PathSegment),
                                paint.asSerialPaint()).apply {
                            Ctx.ctx.exercise.add(this)
                            transaction.add(UndoRedoableNewShape(
                                    this, Ctx.ctx.exercise.indexOf(this), "MAIN AXIS"))
                        }
                        // add imaginary axis
                        ExerciseShape("",
                                str(R.string.new_img_axis,
                                        Ctx.ctx.getHexColor(R.color.name_item),
                                        "?"),
                                SerialPath().storeSegment(
                                        hyperbolaParams["imaginary_axis"] as PathSegment),
                                paint.asSerialPaint()).apply {
                            Ctx.ctx.exercise.add(this)
                            transaction.add(UndoRedoableNewShape(
                                    this, Ctx.ctx.exercise.indexOf(this), "IMAGINARY AXIS"))
                        }

                        paint = defaultPaint(width = Ctx.ctx.pointWidth,
                                color = Ctx.ctx.pointColor)

                        // add focuses
                        for (param in arrayOf("focus1", "focus2"))
                            ExerciseShape("",
                                    str(R.string.new_focus_hyperbola,
                                            Ctx.ctx.getHexColor(R.color.name_item),
                                            "?"),
                                    SerialPath().storePoint(
                                            hyperbolaParams[param] as PointF),
                                    paint.asSerialPaint()).apply {
                                Ctx.ctx.exercise.add(this)
                                transaction.add(UndoRedoableNewShape(
                                        this, Ctx.ctx.exercise.indexOf(this), "HYPERBOLA FOCUS"))
                            }
                        // add vertexes
                        for (param in arrayOf("vertex1", "vertex2"))
                            ExerciseShape("",
                                    str(R.string.new_vertex_hyperbola,
                                            Ctx.ctx.getHexColor(R.color.name_item),
                                            "?"),
                                    SerialPath().storePoint(
                                            hyperbolaParams[param] as PointF),
                                    paint.asSerialPaint()).apply {
                                Ctx.ctx.exercise.add(this)
                                transaction.add(UndoRedoableNewShape(
                                        this, Ctx.ctx.exercise.indexOf(this), "HYPERBOLA VERTEX"))
                            }
                        // add center
                        ExerciseShape("",
                                str(R.string.new_center_hyperbola,
                                        Ctx.ctx.getHexColor(R.color.name_item),
                                        "?"),
                                SerialPath().storePoint(
                                        hyperbolaParams["center"] as PointF),
                                paint.asSerialPaint()).apply {
                            Ctx.ctx.exercise.add(this)
                            transaction.add(UndoRedoableNewShape(
                                    this, Ctx.ctx.exercise.indexOf(this), "HYPERBOLA CENTER"))
                        }
                    }
                    if (Ctx.ctx.addExtremes)
                    {
                        paint = defaultPaint(width = Ctx.ctx.pointWidth,
                                color = Ctx.ctx.pointColor)

                        listOf((hyperbolaParams["branch1"] as SerialPath).getPolySegments()
                                .first().start,
                                (hyperbolaParams["branch1"] as SerialPath).getPolySegments()
                                        .last().end,
                                (hyperbolaParams["branch2"] as SerialPath).getPolySegments()
                                        .first().start,
                                (hyperbolaParams["branch2"] as SerialPath).getPolySegments()
                                        .last().end).forEach {
                            ExerciseShape("",
                                            str(R.string.desc_extremes2,
                                            Ctx.ctx.getHexColor(R.color.name_item),
                                            "?" ),
                                    SerialPath().storePoint(it),
                                    paint.asSerialPaint()).run {
                                Ctx.ctx.exercise.add(this)
                                transaction.add(UndoRedoableNewShape(
                                                        this,
                                                        Ctx.ctx.exercise.indexOf(this),
                                                        "${str(R.string.new_point)} [extremes]"))
                            }
                        }  // forEach
                    }  // if extremes

                    Ctx.ctx.undoRedoManager.addItem(transaction)

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if (Ctx.ctx.keepTool) HyperbolaAction() else defaultAction)
                                    .beforeAction()
                }  // else
            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        start ?: return

        // draw circle centered in start point
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw parabola
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical(
                                    getHyperbola()["branch1"] as SerialPath ).asPath(), toolPaint )
            it.canvas.drawPath( it.transformedShapeToPhysical(
                                    getHyperbola()["branch2"] as SerialPath ).asPath(), toolPaint )
        }
    }

    private fun getHyperbola(): Map<String,Any>
    {
        val x = if ( Ctx.ctx.useRuler )
                    (if ( start!!.x > logicalTouchLocation.x ) start!!.x - Ctx.ctx.rulerDistanceMul
                     else start!!.x + Ctx.ctx.rulerDistanceMul )
                else
                    logicalTouchLocation.x
        val minX = min( start!!.x, x )
        val maxX = max( start!!.x, x )
        val minY = min( start!!.y, logicalTouchLocation.y )
        val maxY = max( start!!.y, logicalTouchLocation.y )
        val cx = (minX + maxX) / 2f
        val cy = (minY + maxY) / 2f
        val w = maxX - minX
        val h = maxY - minY
        val a = h / 4f  // main semi-axis
        val b = w * a / sqrt( h*h - 4*a*a )  // imaginary semi-axis
        val c = hypot(a,b)  // focal semi-distance

        val mapResult = mutableMapOf<String,Any>()

        // set hyperbola
        val nodeList1 = mutableListOf<PointF>()
        val nodeList2 = mutableListOf<PointF>()
        for ( i in 0 until N )
        {
            val xh = -w / 2f + i * w / ( N - 1 )
            val yh = a * sqrt( xh*xh / (b*b) + 1 )  // y=a*sqrt(x^2/b^2+1)  (vertical branches)
            nodeList1.add( PointF( xh, yh ) )
            nodeList2.add( PointF( xh, -yh ) )
        }
        mapResult["branch1"] = SerialPath().storeSpline( *nodeList1.toTypedArray() )
        mapResult["branch2"] = SerialPath().storeSpline( *nodeList2.toTypedArray() )
        // set center
        mapResult["center"] = PointF( cx, cy )
        // set vertexes
        val vertex1 = PointF( cx, cy + a ).apply { mapResult["vertex1"] = this }
        val vertex2 = PointF( cx, cy - a ).apply { mapResult["vertex2"] = this }
        // set focuses
        mapResult["focus1"] = PointF( cx, cy + c )
        mapResult["focus2"] = PointF( cx, cy - c )
        // set axis
        mapResult["main_axis"] = PathSegment( vertex1, 0f, vertex2, 1f )
        mapResult["imaginary_axis"] =
                                PathSegment( PointF( cx - b, cy ), 0f, PointF( cx + b, cy ), 1f )

        // translate hyperbola to center
        Matrix().run {
            postTranslate( cx, cy )
            (mapResult["branch1"] as SerialPath).transform( this )
            (mapResult["branch2"] as SerialPath).transform( this )
        }

        return mapResult
    }

    private fun setStatusBar()
    {
        val txt = when {

            start == null ->
                str(R.string.status_hyperbola2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_hyperbola3,Ctx.ctx.getHexColor(R.color.tool_item) )

        }.let {
            "${str(R.string.status_hyperbola1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class HyperbolaAction

private const val N = 60  // DIVISIONS
