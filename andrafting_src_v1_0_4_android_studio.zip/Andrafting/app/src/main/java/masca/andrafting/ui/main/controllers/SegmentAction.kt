package masca.andrafting.ui.main.controllers

import android.graphics.DashPathEffect
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*

class SegmentAction : ActionListener
{
    private var start: PointF? = null  // segment start extreme
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF  // physical touch
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var initSecondPoint = false  // flag for second extreme

    override fun beforeAction(): SegmentAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!!
                               else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                if ( start != null )
                    initSecondPoint = true
            }
            /*MotionEvent.ACTION_MOVE -> {}*/
            MotionEvent.ACTION_UP -> {
                if ( start == null )  // first point
                    start = logicalTouchLocation
                else  // second point
                {
                    // add segment to exercise
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val end = endPoint( start!!, logicalTouchLocation, Ctx.ctx.fixedAngles,
                                        if( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul else -1f )

                    val shape = ExerciseShape(
                            "",
                                str( R.string.new_segment ),
                                SerialPath().storeSegment( PathSegment( start!!, 0f, end, 1f ) ),
                                paint.asSerialPaint() )

                    Ctx.ctx.exercise.add(shape)

                    // create transaction to add extremes
                    if ( Ctx.ctx.addExtremes )
                    {
                        val transaction = object: UndoRedoTransaction() {
                            override fun getDescription() = """${str(R.string.new_segment)} 
                                                ${str(R.string.undoredo_and_extremes).format(2)}"""
                        }

                        transaction.add( UndoRedoableNewShape(
                            shape, Ctx.ctx.exercise.indexOf(shape), str(R.string.new_segment) ) )

                        paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                        for ( extreme in arrayOf(start!!,end) )
                            ExerciseShape(
                                    "",
                                    str(R.string.desc_extremes2,
                                        Ctx.ctx.getHexColor(R.color.name_item),
                                        elvis(shape.name,"?")),
                                    SerialPath().storePoint( extreme ),
                                    paint.asSerialPaint() ).run {
                                        Ctx.ctx.exercise.add(this)
                                        transaction.add( UndoRedoableNewShape(
                                                this,
                                                    Ctx.ctx.exercise.indexOf(this),
                                                "${str(R.string.new_point)} [extreme]" ) )
                                    }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }
                    // no extremes, simple UndoRedoable
                    else
                        Ctx.ctx.undoRedoManager.addItem(
                                UndoRedoableNewShape( shape, Ctx.ctx.exercise.indexOf(shape),
                                                      str(R.string.new_segment) ) )
                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if ( Ctx.ctx.keepTool ) SegmentAction() else defaultAction).beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch start
        if ( start != null )
            drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )
        else
        {
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )
            return
        }

        if ( initSecondPoint )
        {
            // draw circle centered in touch end
            drawCircleTouch(exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted)

            exCanvas.usePhysicalViewport {
                // draw segment
                val end = endPoint(
                        start!!, logicalTouchLocation, Ctx.ctx.fixedAngles,
                        if (Ctx.ctx.useRuler)
                            Ctx.ctx.rulerLength * Ctx.ctx.rulerMultiplier
                        else
                            -1f )
                val pstart = exCanvas.toPhysicalViewport(start!!)
                val pend = exCanvas.toPhysicalViewport(end)

                toolPaint.pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)

                it.canvas.drawLine( pstart.x, pstart.y, pend.x, pend.y, toolPaint )
            }
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            start == null ->
                str(R.string.status_segment2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_segment3,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_segment1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class SegmentAction
