package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import androidx.core.graphics.minus
import masca.andrafting.*
import masca.andrafting.ui.main.*

class ModifySegmentAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var shape: ExerciseShape? = null
    private var segment: PathSegment? = null  // selected original segment
    private var start: PointF? = null

    override fun beforeAction(): ModifySegmentAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( segment == null )  // set segment
                {
                    shape = exCanvas.getShapeAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation) )
                    if ( shape?.path?.isSegment() == true )
                        segment = shape!!.path.getPolySegments().first()
                    else
                        shape = null
                }
                else if ( start == null )  // set start of the segment
                {
                    start = getSegment().start
                }
                else  // add segment
                {
                    val newSegment = getSegment()
                    val newShape = ExerciseShape( shape!!.name,
                                                  shape!!.description,
                                                  SerialPath().storeSegment( newSegment ),
                                                  shape!!.paint.copy() ).apply {
                                                      arrowType = shape!!.arrowType
                                                  }

                    val index = Ctx.ctx.exercise.indexOf( shape )

                    Ctx.ctx.exercise.add( index + 1, newShape )
                    Ctx.ctx.exercise.removeAt( index )

                    val transaction = object: UndoRedoTransaction() {
                        override fun getDescription()
                            = "${str(R.string.desc_modifyseg)} ${if (Ctx.ctx.addExtremes) str(R.string.undoredo_and_extremes).format(2) else ""}"
                    }

                    transaction.add( UndoRedoableNewShape(
                                        newShape, index + 1, "Add modified segment" ) )
                    transaction.add( UndoRedoableRemoveShape(
                                        shape!!, index, "Replaced segment" ) )

                    if ( Ctx.ctx.addExtremes )
                    {
                        val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor )

                        for ( extreme in arrayOf( newSegment.end, newSegment.start ) )
                            ExerciseShape(
                                    "",
                                    str(R.string.desc_extremes),
                                    SerialPath().storePoint( extreme ),
                                    paint.asSerialPaint() ).run {
                                Ctx.ctx.exercise.add( index + 1, this )
                                transaction.add( UndoRedoableNewShape(
                                        this,
                                        Ctx.ctx.exercise.indexOf(this),
                                        str(R.string.desc_extremes) ) )
                            }
                    }

                    Ctx.ctx.undoRedoManager.addItem( transaction )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if ( Ctx.ctx.keepTool ) ModifySegmentAction() else defaultAction)
                                    .beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getSegment(): PathSegment
    {
        val segment = segment!!
        val n = (segment.end - segment.start).normal()  // normal vector
        val p1 = start ?: linesIntersection( logicalTouchLocation, logicalTouchLocation + n,
                                             segment.start, segment.end )!!
        val p2 = if( start == null )
                     segment.start
                 else
                     linesIntersection( logicalTouchLocation, logicalTouchLocation + n,
                                        segment.start, segment.end )

        return PathSegment( p1, 0f, p2 ?: p1, 1f )
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        // draw original segment
        if ( segment == null || (start == null && !draggingPointer) )
        {
            val localShape = shape ?: exCanvas.getShapeAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation) )
            localShape ?: return

            if ( !localShape.path.isSegment() ) return

            val localSegment = localShape.path.getPolySegments().first()

            toolPaint.strokeWidth = with( exCanvas ) {
                if (Ctx.ctx.scaleStrokeWidth)
                    scaleStrokeWidth( localShape.paint.strokeWidth + 2f,
                                      logicalViewport.width(),
                                      logicalViewport.height(),
                                      canvas.width,
                                      canvas.height )
                else
                    fixedStrokeWidth( localShape.paint.strokeWidth + 2f,
                                      logicalViewport.width(),
                                      logicalViewport.height(),
                                      canvas.width,
                                      canvas.height )
            }

            exCanvas.canvas.drawLine( localSegment.start.x, localSegment.start.y,
                                      localSegment.end.x, localSegment.end.y, toolPaint  )
        }

        segment ?: return

        // draw circle centered in start
        if ( start != null )
            drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw new segment
        val newSegment = getSegment()
        toolPaint.strokeWidth = 3f
        exCanvas.usePhysicalViewport {
            val a = it.toPhysicalViewport(newSegment.start)
            val b = it.toPhysicalViewport(newSegment.end)
            it.canvas.drawLine( a.x, a.y, b.x, b.y, toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            shape == null ->
                str(R.string.status_modifyseg2,Ctx.ctx.getHexColor(R.color.tool_item))

            start == null && !draggingPointer ->
                str(R.string.status_modifyseg3,Ctx.ctx.getHexColor(R.color.tool_item))

            start == null ->
                str(R.string.status_modifyseg4,Ctx.ctx.getHexColor(R.color.tool_item))

            start != null && !draggingPointer ->
                str(R.string.status_modifyseg5,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_modifyseg6,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_modifyseg1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
            // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class ModifySegmentAction
