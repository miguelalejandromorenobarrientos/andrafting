package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.UndoRedoTransaction
import masca.andrafting.ui.main.str
import kotlin.math.abs

class IntersectionAction: ActionListener
{
    override fun action( view: View?, evt: InputEvent? )
    {
        if (Ctx.ctx.selectedShapes.size < 2 )
        {
            Toast.makeText( Ctx.ctx, R.string.warmsg_two_or_more_shapes, Toast.LENGTH_SHORT ).show()
            return
        }

        val shapes = Ctx.ctx.selectedShapes

        // create intersections set
        val setIntersections = mutableSetOf<POJOJoin>()

        // TODO improve these loops. Why equals fails in set?
        for ( i in 0 until shapes.size - 1 )
            for ( j in i+1 until shapes.size )
                loop@ for( point in shapes[i].intersections(shapes[j]) )
                {
                    val pojoJoin = POJOJoin(point,shapes[i],shapes[j])

                    for ( inSetPJJ in setIntersections )
                        if ( inSetPJJ == pojoJoin )
                            continue@loop

                    setIntersections.add( pojoJoin )
                }

        if ( setIntersections.isEmpty() )
        {
            Toast.makeText( Ctx.ctx, R.string.warmsg_no_intersections, Toast.LENGTH_SHORT ).show()
            return
        }

        Toast.makeText( Ctx.ctx, "${setIntersections.size} ${str(R.string.msg_intersections)}",
                         Toast.LENGTH_SHORT ).show()

        // create transaction
        val transaction = object: UndoRedoTransaction() {
            override fun getDescription()
                = str( R.string.desc_intersections, setIntersections.size )
        }

        val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                  color = Ctx.ctx.pointColor )

        // add intersections
        for ( pjpoint in setIntersections )
            ExerciseShape( "",
                           str(R.string.desc_point_intersection,
                               Ctx.ctx.getHexColor(R.color.name_item),
                               elvis( pjpoint.shape1.name, "?" ),
                               elvis( pjpoint.shape2.name, "?" )),
                           SerialPath().storePoint( pjpoint.point ),
                           paint.asSerialPaint() ).run {
                Ctx.ctx.exercise.add(this)
                transaction.add( UndoRedoableNewShape(
                        this,
                        Ctx.ctx.exercise.indexOf(this),
                        "INTERSECTION POINT" ) )
            }

        Ctx.ctx.undoRedoManager.addItem( transaction )

        if ( !Ctx.ctx.keepTool )
            Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()

        // deselect shapes
        //Ctx.ctx.selectedShapes = arrayListOf()
    }

    class POJOJoin( val point: PointF, val shape1: ExerciseShape, val shape2: ExerciseShape )
    {
        private val EPS = 1E-3f

        /**
         * Closest points will be considered equals
         */
        override fun equals(other: Any?)
            = if ( other !is POJOJoin )
                  false
              else
                  abs(point.x-other.point.x) < EPS && abs(point.y-other.point.y) < EPS

        override fun hashCode(): Int
        {
            var result = point.hashCode()
            result = 31 * result + EPS.hashCode()
            return result
        }
    }  // class POJOJoin

}  // class IntersectionAction
