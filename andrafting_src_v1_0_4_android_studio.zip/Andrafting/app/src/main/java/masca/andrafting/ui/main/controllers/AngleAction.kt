package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*
import kotlin.math.abs

class AngleAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPoint = false
    private var vertex: PointF? = null  // angle vertex
    private var extreme1: PointF? = null  // extreme of the base side (not vertex)

    override fun beforeAction(): AngleAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPoint = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                draggingPoint = false

                if ( vertex == null )  // set vertex
                    vertex = logicalTouchLocation
                else if ( extreme1 == null )  // set extreme 1
                    extreme1 = logicalTouchLocation
                else  // end oriented segment
                {
                    // add oriented segment to exercise
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val orientedSegment = getOrientedSegment()
                    val segment = ExerciseShape( "",
                                         str(R.string.desc_angle,
                                             Math.toDegrees(Ctx.ctx.protractorAngle.toDouble())),
                                         SerialPath().storeSegment( orientedSegment ),
                                         paint.asSerialPaint( Ctx.ctx.fillColor ) ).apply {
                         Ctx.ctx.exercise.add( this )
                    }
                    val undoRedoSegment = UndoRedoableNewShape(
                        segment, Ctx.ctx.exercise.indexOf(segment),
                        str(R.string.desc_angle,Math.toDegrees(Ctx.ctx.protractorAngle.toDouble())))

                    if ( Ctx.ctx.addAuxiliaryShapes || Ctx.ctx.addExtremes )
                    {
                        val transaction = object: UndoRedoTransaction() {
                            override fun getDescription()
                                = "${str(R.string.desc_angle,Math.toDegrees(Ctx.ctx.protractorAngle.toDouble()))} ${if(Ctx.ctx.addExtremes) str(R.string.undoredo_and_extremes).format(if (Ctx.ctx.addAuxiliaryShapes) 3 else 2) else ""}"
                        }

                        transaction.add( undoRedoSegment )

                        if ( Ctx.ctx.addAuxiliaryShapes )
                        {
                            // add original segment
                            ExerciseShape( "",
                                           str(R.string.new_extra_angle),
                                           SerialPath().storeSegment(
                                                    PathSegment( vertex!!, 0f, extreme1!!, 1f ) ),
                                           paint.asSerialPaint( Ctx.ctx.fillColor ) ).apply {
                                Ctx.ctx.exercise.add( this )
                                transaction.add( UndoRedoableNewShape(
                                        this, Ctx.ctx.exercise.indexOf(this), "EXTRA ANGLE SIDE" ) )
                            }
                        }
                        if ( Ctx.ctx.addExtremes )
                        {
                            paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor )

                            val lstPoints = mutableListOf(vertex!!, orientedSegment.end)
                            if (Ctx.ctx.addAuxiliaryShapes)
                                lstPoints.add(extreme1!!)

                            for (extreme in lstPoints)
                                ExerciseShape( "",
                                               str(R.string.desc_extremes2,
                                                   Ctx.ctx.getHexColor(R.color.name_item),
                                                   elvis(segment.name,"?")),
                                               SerialPath().storePoint(extreme),
                                               paint.asSerialPaint() ).apply {
                                    Ctx.ctx.exercise.add(this)
                                    transaction.add( UndoRedoableNewShape( this,
                                                                  Ctx.ctx.exercise.indexOf(this),
                                                                  "ANGLE EXTREME" ) )
                                }
                        }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }
                    else  // no extra shapes
                        Ctx.ctx.undoRedoManager.addItem( undoRedoSegment )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if ( Ctx.ctx.keepTool ) AngleAction() else defaultAction).beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getOrientedSegment(): PathSegment
    {
        // get angle
        var angle = (extreme1!! - vertex!!).arg()
        var extent = Ctx.ctx.protractorAngle
        if ( logicalTouchLocation.relativeTo( PathSegment( vertex!!, 0f, extreme1!!, 1f ) ) > 0f )
            extent = -extent
        angle += extent
        // get extreme 2
        val extreme2 = if ( Ctx.ctx.useRuler )  // ruler
                           vertex!!.pointRelativeToCenter( angle, Ctx.ctx.rulerDistanceMul )
                       else  // touch projection on oriented line
                       {
                           val p2 = vertex!!.pointRelativeToCenter( angle, 1f )
                           val v = p2 - vertex!!
                           val w = logicalTouchLocation - vertex!!
                           vertex!!.pointRelativeToCenter( angle, abs( v*w / v.length() ) )  // projection v->w
                       }

        // oriented segment
        return PathSegment( vertex!!, 0f, extreme2, 1f )
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPoint )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        if ( vertex != null )
        {
            // draw circle centered in vertex angle
            drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(vertex!!))
            // draw segment vertex-{extreme1|logicalTouchLocation}
            exCanvas.usePhysicalViewport {
                val p1 = it.toPhysicalViewport( vertex!! )
                val p2 = it.toPhysicalViewport( if ( extreme1 == null ) logicalTouchLocation else extreme1!! )
                it.canvas.drawLine( p1.x, p1.y, p2.x, p2.y, toolPaint )
            }
        }

        extreme1 ?: return

        // draw circle centered in extreme1
        drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(extreme1!!))

        // draw oriented segment and angle
        val segment = getOrientedSegment()
        exCanvas.usePhysicalViewport {
            val p1 = it.toPhysicalViewport( segment.start )
            val p2 = it.toPhysicalViewport( segment.end )
            it.canvas.drawLine( p1.x, p1.y, p2.x, p2.y, toolPaint )
            toolPaint.pathEffect = null
            toolPaint.textSize = 24f
            it.canvas.drawText( "%.3fº".format(Math.toDegrees(Ctx.ctx.protractorAngle.toDouble())),
                                p2.x + 24, p2.y - 24, toolPaint )
        }
    }

    private fun setStatusBar()
    {
       val txt = when {

           vertex == null ->
                str(R.string.status_angle2,Ctx.ctx.getHexColor(R.color.tool_item))

           extreme1 == null ->
                str(R.string.status_angle3,Ctx.ctx.getHexColor(R.color.tool_item))

           else -> str(R.string.status_angle4,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_angle1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class AngleAction
