package masca.andrafting.ui.main.controllers

import android.graphics.Region
import android.view.InputEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.UndoRedoTransaction
import masca.andrafting.ui.main.str

sealed class SealedRegionOpAction: ActionListener
{
    abstract val selectedConditionError: Boolean
    abstract val selectedConditionErrorMsg: Int
    abstract val op: Region.Op
    abstract val newShapeMsg: Int

    override fun action( view: View?, evt: InputEvent? )
    {
        if ( selectedConditionError )
        {
            Toast.makeText( Ctx.ctx, selectedConditionErrorMsg, Toast.LENGTH_SHORT ).show()
            return
        }

        val shapes = Ctx.ctx.selectedShapes

        //val clip = Region( Int.MIN_VALUE / 2, Int.MIN_VALUE / 2, Int.MAX_VALUE / 2, Int.MAX_VALUE / 2 )
        val clip = Region( -1000000, -1000000, 1000000, 1000000 )
        //val clip = Region( Ctx.ctx.exercise.bounds.toRect() )

        val region = Region().apply { setPath( shapes.first().path.asPath(), clip ) }
        for ( i in 1 until shapes.size )
        {
            val otherRegion = Region().apply { setPath( shapes[i].path.asPath(), clip ) }
            region.op( otherRegion, op )
        }

        if ( region.isEmpty )
        {
            Toast.makeText( view?.context ?: MAct.act,
                            str(R.string.warmsg_empty_area), Toast.LENGTH_LONG ).show()
            return
        }

        // add new shape and remove originals
        val transaction = object: UndoRedoTransaction() {
            override fun getDescription() = str(newShapeMsg,shapes.size)
        }

        for ( shape in shapes )  // remove shapes
        {
            val index = Ctx.ctx.exercise.indexOf( shape )
            Ctx.ctx.exercise.remove( shape )
            transaction.add( UndoRedoableRemoveShape( shape, index,
                                                      "REMOVE ORIGINAL SHAPE ${shape.name}" ) )
        }

        val paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                  color = Ctx.ctx.strokeColor,
                                  cap = Ctx.ctx.cap,
                                  join = Ctx.ctx.join,
                                  dash = Ctx.ctx.dashPathEffect )

        ExerciseShape( "",
                       str(newShapeMsg,shapes.size),
                       region.boundaryPath.approximateAsSerialPath(),
                       paint.asSerialPaint( Ctx.ctx.fillColor ) ).run {
            Ctx.ctx.exercise.add(this)
            transaction.add( UndoRedoableNewShape( this,
                                                   Ctx.ctx.exercise.indexOf(this),
                                                   "SHAPE BY OP" ) )
        }

        Ctx.ctx.undoRedoManager.addItem( transaction )

        MAct.act.getCanvas()?.invalidate()
    }

    class UnionAction: SealedRegionOpAction()
    {
        override val op = Region.Op.UNION
        override val selectedConditionError
            get() = Ctx.ctx.selectedShapes.size < 2
        override val selectedConditionErrorMsg = R.string.warmsg_two_or_more_shapes
        override val newShapeMsg = R.string.desc_union
    }  // class UnionAction

    class IntersectionAction: SealedRegionOpAction()
    {
        override val op = Region.Op.INTERSECT
        override val selectedConditionError
            get() = Ctx.ctx.selectedShapes.size < 2
        override val selectedConditionErrorMsg = R.string.warmsg_two_or_more_shapes
        override val newShapeMsg = R.string.desc_intersection
    }  // class IntersectionAction

    class SymmetricSubtractAction: SealedRegionOpAction()
    {
        override val op = Region.Op.XOR
        override val selectedConditionError
            get() = Ctx.ctx.selectedShapes.size < 2
        override val selectedConditionErrorMsg = R.string.warmsg_two_or_more_shapes
        override val newShapeMsg = R.string.desc_xor
    }  // class SymmetricSubtractAction

    class SubtractAction: SealedRegionOpAction()
    {
        override val op = Region.Op.DIFFERENCE
        override val selectedConditionError
            get() = Ctx.ctx.selectedShapes.size != 2
        override val selectedConditionErrorMsg = R.string.warmsg_two_shapes
        override val newShapeMsg = R.string.desc_subtract
    }  // class SubtractAction

    class SubtractReverseAction: SealedRegionOpAction()
    {
        override val op = Region.Op.REVERSE_DIFFERENCE
        override val selectedConditionError
            get() = Ctx.ctx.selectedShapes.size != 2
        override val selectedConditionErrorMsg = R.string.warmsg_two_shapes
        override val newShapeMsg = R.string.desc_subtract
    }  // class SubtractReverseAction

}  // class SealedRegionOpAction
