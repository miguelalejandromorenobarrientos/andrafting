package masca.andrafting.ui.main.controllers

import android.graphics.Matrix
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.*
import masca.andrafting.ui.main.*

open class TranslateAction: ActionListener
{
    protected lateinit var logicalTouchLocation: PointF
    protected lateinit var location: PointF
    protected var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    protected var draggingPointer = false
    protected var start: PointF? = null  // origin of the translation
    protected open val descOp = R.string.desc_translate
    protected open val status1 = R.string.status_translation1
    protected open val status2 = R.string.status_translation2
    protected open val status3 = R.string.status_translation3

    protected open val getMatrix: Matrix
        get() {
            start ?: throw IllegalStateException( "START NOT SET!" )
            val endPoint = endPoint( start!!,
                                     logicalTouchLocation,
                                     Ctx.ctx.fixedAngles,
                                     if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                     else -1f,
                                     if ( Ctx.ctx.useProtractor ) Ctx.ctx.protractorAngle
                                     else -1f )

            val (tx,ty) = endPoint - start!!

            return Matrix().apply { preTranslate( tx, ty ) }
        }

    override fun beforeAction(): ActionListener
    {
        if ( Ctx.ctx.selectedShapes.isEmpty() )
        {
            Toast.makeText( Ctx.ctx, R.string.warmsg_no_selected, Toast.LENGTH_SHORT ).show()
            return defaultAction.beforeAction()
        }

        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( start == null )  // set translation origin
                {
                    start = logicalTouchLocation
                }
                else  // move selected shapes
                {
                    val n = Ctx.ctx.selectedShapes.size
                    val transaction = object: UndoRedoTransaction() {
                        override fun getDescription()= str(descOp,n)
                    }

                    val translationMatrix = getMatrix

                    for ( shape in Ctx.ctx.selectedShapes )
                    {
                        shape.path.transform( translationMatrix )
                        transaction.add( UndoRedoableTransformShape(
                                            shape, "TRANSFORMED SHAPE", translationMatrix ) )
                    }

                    Ctx.ctx.undoRedoManager.addItem( transaction )

                    // update tool
                    Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        start ?: return

        // draw circle centered in start
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw selected shapes
        if ( draggingPointer )
        {
            val translationMatrix = getMatrix
            exCanvas.usePhysicalViewport {
                for (shape in Ctx.ctx.selectedShapes)
                    it.canvas.drawPath(it.transformedShapeToPhysical(
                            shape.path.copy().apply { transform(translationMatrix) }).asPath(),
                            toolPaint)
            }
        }

        val endPoint = endPoint( start!!,
                                 logicalTouchLocation,
                                 Ctx.ctx.fixedAngles,
                                 if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                 else -1f,
                                 if ( Ctx.ctx.useProtractor ) Ctx.ctx.protractorAngle
                                 else -1f )

        // draw segment start-end
        exCanvas.usePhysicalViewport {
            val a = it.toPhysicalViewport(start!!)
            val b = it.toPhysicalViewport(endPoint)
            it.canvas.drawLine( a.x, a.y, b.x, b.y, toolPaint )
        }
    }

    protected fun setStatusBar()
    {
        val txt = when {

            start == null ->
                str(status2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(status3,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(status1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class TranslateAction
