package masca.andrafting

import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import java.io.Serializable

data class SerialPaint(var strokeWidth: Float = 1f,
                       var color: Int = Color.BLACK,
                       var fill: Int? = null,
                       var isAntiAlias: Boolean = true,
                       var isDither: Boolean = true,
                       var strokeMiter: Float = 1f,
                       var strokeCap: Paint.Cap = Paint.Cap.ROUND,
                       var strokeJoin: Paint.Join = Paint.Join.ROUND,
                       var style: Paint.Style = Paint.Style.STROKE,
                       var textFamily: String? = "Arial",
                       var textStyle: Int = Typeface.NORMAL,
                       var dashPathEffect: FloatArray? = null,
                       var textSize: Float = 12f )
    : Serializable
{
    fun copy() = SerialPaint( strokeWidth, color, fill, isAntiAlias, isDither, strokeMiter,
            strokeCap, strokeJoin, style, textFamily, textStyle, dashPathEffect?.clone(), textSize )

    override fun equals(other: Any?): Boolean
    {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as SerialPaint

        if (strokeWidth != other.strokeWidth) return false
        if (color != other.color) return false
        if (fill != other.fill) return false
        if (isAntiAlias != other.isAntiAlias) return false
        if (isDither != other.isDither) return false
        if (strokeMiter != other.strokeMiter) return false
        if (strokeCap != other.strokeCap) return false
        if (strokeJoin != other.strokeJoin) return false
        if (style != other.style) return false
        if (textFamily != other.textFamily) return false
        if (textStyle != other.textStyle) return false
        if (dashPathEffect != null)
        {
            if (other.dashPathEffect == null) return false
            if (!dashPathEffect.contentEquals(other.dashPathEffect)) return false
        }
        else if (other.dashPathEffect != null) return false
        if (textSize != other.textSize) return false

        return true
    }

    override fun hashCode(): Int
    {
        var result = strokeWidth.hashCode()
        result = 31 * result + color
        result = 31 * result + (fill ?: 0)
        result = 31 * result + isAntiAlias.hashCode()
        result = 31 * result + isDither.hashCode()
        result = 31 * result + strokeMiter.hashCode()
        result = 31 * result + strokeCap.hashCode()
        result = 31 * result + strokeJoin.hashCode()
        result = 31 * result + style.hashCode()
        result = 31 * result + (textFamily?.hashCode() ?: 0)
        result = 31 * result + textStyle
        result = 31 * result + (dashPathEffect?.contentHashCode() ?: 0)
        result = 31 * result + textSize.hashCode()
        return result
    }

}

fun SerialPaint.asPaint() = Paint().also {
    it.strokeWidth = strokeWidth
    it.color = color
    it.isAntiAlias = isAntiAlias
    it.isDither = isDither
    it.strokeMiter = strokeMiter
    it.strokeCap = strokeCap
    it.strokeJoin = strokeJoin
    it.style = style
    it.typeface = Typeface.create( textFamily, textStyle )
    it.pathEffect = if ( dashPathEffect != null )
                        FriendlyDashPathEffect( dashPathEffect!!.clone(), 0f )
                    else
                        null
    it.textSize = textSize
}

fun Paint.asSerialPaint( fill: Int? = null ) = SerialPaint().also {
    it.strokeWidth = strokeWidth
    it.color = color
    it.fill = fill
    it.isAntiAlias = isAntiAlias
    it.isDither = isDither
    it.strokeMiter = strokeMiter
    it.strokeCap = strokeCap
    it.strokeJoin = strokeJoin
    it.style = style
    it.textStyle = typeface?.style ?: Typeface.NORMAL
    it.dashPathEffect = (pathEffect as? FriendlyDashPathEffect)?.intervals?.clone()
    it.textSize = textSize
}

class FriendlyDashPathEffect( val intervals: FloatArray,
                              val phase: Float = 0f )
    : DashPathEffect( intervals, phase )
