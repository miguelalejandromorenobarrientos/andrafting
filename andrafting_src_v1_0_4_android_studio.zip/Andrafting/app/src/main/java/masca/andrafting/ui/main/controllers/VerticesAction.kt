package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.*

class VerticesAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var shape: ExerciseShape? = null  // touched shape

    override fun beforeAction(): VerticesAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            in setOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE) ->
            {
                // get shape
                shape = exCanvas.getShapeAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation)  )
                // don't take account points bounds
                if ( shape?.path?.isPoint() == true )
                    shape = null
            }
            MotionEvent.ACTION_UP ->
            {
                if ( shape != null )
                {
                    // add vertices to exercise
                    val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                    val transaction = object: UndoRedoTransaction() {
                        override fun getDescription() =
                                    str(R.string.desc_vertices, shape!!.path.getPolyVertices().size)
                    }

                    for ( vertex in shape!!.path.getPolyVertices() )
                        ExerciseShape(
                                "",
                                str(R.string.desc_vertices2,
                                    Ctx.ctx.getHexColor(R.color.name_item),
                                    elvis(shape!!.name,"?")),
                                SerialPath().storePoint( vertex ),
                                paint.asSerialPaint() ).run {
                            Ctx.ctx.exercise.add(this)
                            transaction.add( UndoRedoableNewShape(
                                    this,
                                    Ctx.ctx.exercise.indexOf(this),
                                    "${str(R.string.new_point)} [vertex]" ) )
                        }

                    Ctx.ctx.undoRedoManager.addItem( transaction )
                }

                // update or keep tool
                Ctx.ctx.currentActionForCanvas.value =
                        (if (Ctx.ctx.keepTool) VerticesAction() else defaultAction).beforeAction()

            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation,
                         adjusted && shape != null )

        shape ?: return

        // draw shape
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( shape!!.path ).asPath(), toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            else -> str(R.string.status_vertices2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_vertices1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class VerticesAction
