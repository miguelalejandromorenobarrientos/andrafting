package masca.andrafting.ui.main

import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import masca.andrafting.*
import masca.andrafting.databinding.FragmentCanvasBinding
//import masca.andrafting.databinding.FragmentCanvasBinding
import masca.andrafting.ui.main.controllers.*
import java.util.*

class CanvasFragment : Fragment()
{
    lateinit var binding : FragmentCanvasBinding
    private val activity by lazy { context as MainActivity }
    private var timerForGreenBoard: GreenboardTimer? = null

    /**
     * Timer for step info toast
     */
    private inner class GreenboardTimer: Timer( "Greenboard timer" )
    {
        init
        {
            binding.greenboard.visibility = View.VISIBLE

            schedule( object: TimerTask() {
                    override fun run()
                    {
                        binding.greenboard.visibility = View.INVISIBLE
                    }
                }, 10000L )  // 10s
        }
    }

    private fun setGreenboardTex( shape: ExerciseShape )
    {
        ("<font color=#0000FF>${Ctx.ctx.exercise.indexOf(shape)+1}:</font> <font color=#DDDD55>" +
         "<b>${shape.name}</b></font><br>${shape.description}")
            .let { binding.greenboard.text = it.html() }
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle? )
        : View
    {
        binding = FragmentCanvasBinding.inflate(inflater)

        // Shape List
        binding.lstShapes.adapter = ShapeList.ShapeListAdapter(
                activity, R.layout.listitem_shape, activity.applicationContext.exercise )

        // Forward Exercise Button
        binding.btnForwardExercise.setOnClickListener {
            if ( Ctx.ctx.exercise.frameIndexAtEnd )
                return@setOnClickListener

            val shape = Ctx.ctx.exercise[++Ctx.ctx.exercise.frameIndex]
            binding.canvas.invalidate()
            activity.updateShapeList()

            timerForGreenBoard?.cancel()
            setGreenboardTex(shape)
            timerForGreenBoard = GreenboardTimer()  // start
        }

        // Backward Exercise Button
        binding.btnBackwardExercise.setOnClickListener {
            if ( Ctx.ctx.exercise.frameIndex < 1 )
                return@setOnClickListener

            val shape = Ctx.ctx.exercise[--Ctx.ctx.exercise.frameIndex]
            binding.canvas.invalidate()
            activity.updateShapeList()

            timerForGreenBoard?.cancel()
            setGreenboardTex(shape)
            timerForGreenBoard = GreenboardTimer()  // start
        }

        // End Exercise Action
        binding.btnEndExercise.setOnClickListener {
            if ( Ctx.ctx.exercise.isEmpty() )
                return@setOnClickListener

            Ctx.ctx.exercise.frameIndex = Ctx.ctx.exercise.size - 1

            binding.canvas.invalidate()
            activity.updateShapeList()

            timerForGreenBoard?.cancel()
            binding.greenboard.visibility = View.INVISIBLE
        }

        // Rewind Exercise Button
        binding.btnRewindExercise.setOnClickListener {
            if ( Ctx.ctx.exercise.isEmpty() )
                return@setOnClickListener

            Ctx.ctx.exercise.frameIndex = Ctx.ctx.exercise.startFrameIndex
            val shape = Ctx.ctx.exercise[Ctx.ctx.exercise.frameIndex]

            binding.canvas.invalidate()
            activity.updateShapeList()

            timerForGreenBoard?.cancel()
            setGreenboardTex(shape)
            timerForGreenBoard = GreenboardTimer()  // start
        }

        // Button Hand
        binding.btnHand.isChecked = Ctx.ctx.currentActionForCanvas.value is HandAction
        binding.btnHand.setOnClickListener {
            Ctx.ctx.currentActionForCanvas.value =
                    (if (binding.btnHand.isChecked) HandAction() else NoAction()).beforeAction()
        }

        // Button Selection
        binding.btnSelection.isChecked = Ctx.ctx.currentActionForCanvas.value is SelectionAction
        binding.btnSelection.setOnClickListener {
            Ctx.ctx.currentActionForCanvas.value =
                (if (binding.btnSelection.isChecked) SelectionAction() else NoAction())
                        .beforeAction()
        }

        // Button Zoom All
        binding.btnZoomAll.setOnClickListener { ZoomAllAction().action() }

        // Button Zoom Region
        binding.btnZoomRegion.onClick = {
            Ctx.ctx.currentActionForCanvas.value = ZoomRegionAction().beforeAction()
        }

        // Button Undo
        with(binding.btnUndo)
        {
            onClick = { Ctx.ctx.undoRedoManager.undo() }
            isEnabled = Ctx.ctx.undoRedoManager.canUndo()
            contentDescription = Ctx.ctx.undoRedoManager.undoDescription().html()
            tooltipText = contentDescription
        }

        // Button Redo
        with(binding.btnRedo)
        {
            onClick = { Ctx.ctx.undoRedoManager.redo() }
            isEnabled = Ctx.ctx.undoRedoManager.canRedo()
            contentDescription = Ctx.ctx.undoRedoManager.redoDescription().html()
            tooltipText = contentDescription
        }

        // Button Delete Selected
        binding.btnDelete.onClick = { DeleteSelectedAction().action() }

        // Button Up ZBuffer
        binding.btnMoveUp.onClick = { MoveZBufferAction(true).action() }

        // Button Down ZBuffer
        binding.btnMoveDown.onClick = { MoveZBufferAction(false).action() }

        return binding.root
    }

    override fun onPause()
    {
        super.onPause()

        // keep status bar msg
        Ctx.ctx.statusBarMsg.value = binding.statusBar.text
    }

    override fun onResume()
    {
        super.onResume()

        binding.btnHand.isChecked = Ctx.ctx.currentActionForCanvas.value is HandAction

        // recover status bar msg
        binding.statusBar.text = Ctx.ctx.statusBarMsg.value

        MAct.act.updateShapeList()
    }

    companion object
    {
        fun newInstance() = CanvasFragment()
    }
}
