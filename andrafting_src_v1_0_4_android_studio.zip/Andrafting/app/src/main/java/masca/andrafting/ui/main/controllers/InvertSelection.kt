package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import masca.andrafting.ExerciseShape
import masca.andrafting.MAct
import masca.andrafting.ui.main.Ctx

class InvertSelection: ActionListener
{
    override fun action(view: View?, evt: InputEvent?)
    {
        Ctx.ctx.selectedShapes = arrayListOf<ExerciseShape>().apply {
            Ctx.ctx.exercise.forEach {
                if ( !Ctx.ctx.selectedShapes.contains(it) )
                    add( it )
            }
        }

        MAct.act.getCanvas()?.invalidate()
        MAct.act.updateShapeList()
    }
}
