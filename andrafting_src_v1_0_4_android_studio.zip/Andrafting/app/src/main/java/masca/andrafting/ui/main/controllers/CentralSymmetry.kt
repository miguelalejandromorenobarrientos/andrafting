package masca.andrafting.ui.main.controllers

import android.graphics.Matrix
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.*

open class CentralSymmetry: TranslateAction()
{
    override val descOp = R.string.desc_central_symmetry
    override val status1 = R.string.status_central_symmetry1
    override val status2 = R.string.status_central_symmetry2

    override val getMatrix: Matrix
        get() {
            val center = start ?: logicalTouchLocation

            return Matrix().apply {
                preTranslate( center.x, center.y )
                preScale( -1f, -1f )
                preTranslate( -center.x, -center.y )
            }
        }

    override fun action(view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
        else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                start = logicalTouchLocation

                val n = Ctx.ctx.selectedShapes.size
                val transaction = object: UndoRedoTransaction() {
                    override fun getDescription()= str(descOp,n)
                }

                val translationMatrix = getMatrix

                for ( shape in Ctx.ctx.selectedShapes )
                {
                    shape.path.transform( translationMatrix )
                    transaction.add( UndoRedoableTransformShape(
                            shape, "TRANSFORMED SHAPE", translationMatrix ) )
                }

                Ctx.ctx.undoRedoManager.addItem( transaction )

                // update tool
                Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        super.paintTool(exCanvas)

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw selected shapes
        if ( draggingPointer )
        {
            val translationMatrix = getMatrix
            exCanvas.usePhysicalViewport {
                for (shape in Ctx.ctx.selectedShapes)
                    it.canvas.drawPath(it.transformedShapeToPhysical(
                            shape.path.copy().apply { transform(translationMatrix) }).asPath(),
                            toolPaint)
            }
        }
    }

}  // class CentralSymmetry
