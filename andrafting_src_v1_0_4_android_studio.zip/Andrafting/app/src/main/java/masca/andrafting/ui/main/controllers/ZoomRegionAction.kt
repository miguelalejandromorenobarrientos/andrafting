package masca.andrafting.ui.main.controllers

import android.graphics.*
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.alpha
import androidx.core.graphics.blue
import androidx.core.graphics.green
import androidx.core.graphics.red
import masca.andrafting.*
import masca.andrafting.ui.main.*

class ZoomRegionAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var draggingPointer = false
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var start: PointF? = null  // start point of the region
    private lateinit var exCanvas: ExerciseCanvas

    override fun beforeAction(): ZoomRegionAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
        else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( start == null )  // set start
                    start = logicalTouchLocation
                else  // zoom rectangular region
                {
                    exCanvas.logicalViewport = getRegion()

                    Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
                }
            }
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getRegion(): RectF
    {
        val factor = exCanvas.logicalViewport.width() / exCanvas.logicalViewport.height()
        val tempRegion = createRectFFromCorners( start!!, logicalTouchLocation )
        val width = tempRegion.width() clip MIN_WIDTH..MAX_WIDTH
        val height = width / factor

        return createRectF( tempRegion.left,
                          start!!.y + (if ( logicalTouchLocation.y > start!!.y ) height else 0f),
                            width, height )
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPointer)
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        start ?: return

        // draw circle centered in start point
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw region bounds
        val region = getRegion()
        exCanvas.usePhysicalViewport {
            val topLeft = it.toPhysicalViewport( PointF( region.left, region.top ) )
            val bottomRight = it.toPhysicalViewport( PointF( region.right, region.bottom ) )
            it.canvas.drawRect( topLeft.x, topLeft.y, bottomRight.x, bottomRight.y, toolPaint.apply {
                style = Paint.Style.FILL
                color = Color.argb( color.alpha / 10, color.red, color.green, color.blue )
            })
            it.canvas.drawRect( topLeft.x, topLeft.y, bottomRight.x, bottomRight.y,
                                defaultToolPaint( Ctx.ctx.exercise.background, 3f ) )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            start == null -> str(R.string.status_zoom_region2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_zoom_region3,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_zoom_region1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // ZoomRegionAction
