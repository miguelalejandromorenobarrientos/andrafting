package masca.andrafting.ui.main.controllers

import android.graphics.DashPathEffect
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.str
import kotlin.random.Random

class SelectionAction : ActionListener
{
    private var start: PointF? = null
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private lateinit var originalSelection: ArrayList<ExerciseShape>

    override fun beforeAction(): SelectionAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        location = evt.location()
        logicalTouchLocation = exCanvas.toLogicalViewport( location )

        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                start = logicalTouchLocation
                originalSelection = ArrayList( Ctx.ctx.selectedShapes )
            }
            MotionEvent.ACTION_MOVE -> {
                // rectangular selection
                if ( logicalTouchLocation != start )
                {
                    val selector = createRectFFromCorners( start!!, logicalTouchLocation )
                    val allArea = false  // true for selecting by containing all the shape, else touching the shape (TODO not implemented true value)

                    Ctx.ctx.selectedShapes = ArrayList(originalSelection)

                    for ( shape in Ctx.ctx.exercise.shapesUntilFrameIndex )
                        if ( allArea || shape.path.isPoint() )  // contains all shape bounds
                        {
                            if ( selector.contains( shape.getBounds() ) )
                            {
                                if ( !originalSelection.contains(shape) )
                                    Ctx.ctx.selectedShapes.add(shape)
                            }
                        }
                        else  // touch shape path
                        {
                            for ( segment in shape.path.getPolySegments() )
                                if ( segmentRectangleIntersects( segment.start, segment.end, selector ) )
                                {
                                    if ( !originalSelection.contains(shape) )
                                        Ctx.ctx.selectedShapes.add(shape)
                                    break
                                }
                        }

                    exCanvas.invalidate()
                    MAct.act.updateShapeList()
                }
            }
            MotionEvent.ACTION_UP -> {
                // single selection
                if ( logicalTouchLocation == start )
                {
                    val selectedShape = exCanvas.getShapeAtCanvasPoint(location)
                    if (selectedShape != null)
                    {
                        if (Ctx.ctx.selectedShapes.contains(selectedShape))  // unselect
                            Ctx.ctx.selectedShapes.remove(selectedShape)
                        else  // select
                            Ctx.ctx.selectedShapes.add(selectedShape)
                        exCanvas.invalidate()
                        MAct.act.updateShapeList()
                    }
                    else  // clear selection
                    {
                        if (Ctx.ctx.selectedShapes.isNotEmpty())
                        {
                            Ctx.ctx.selectedShapes = arrayListOf()
                            exCanvas.invalidate()
                            MAct.act.updateShapeList()
                        }
                    }
                }
                else
                    exCanvas.invalidate()

                start = null  // reset rectangle
            }
        }  // when

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized || start ?: return == logicalTouchLocation )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )
        toolPaint.pathEffect = DashPathEffect( floatArrayOf( 10f, 10f ), Random.nextFloat() * 20f )

        exCanvas.usePhysicalViewport {
            it.canvas.drawRect( createRectFFromCorners( exCanvas.toPhysicalViewport( start!! ),
                                              exCanvas.toPhysicalViewport( logicalTouchLocation ) ),
                                              toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            else -> str(R.string.status_selection2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_selection1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // SelectionAction
