package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.*

class FreeHandAction: ActionListenerDoubleTap()
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private val serialPath by lazy { SerialPath() }  // free hand polygonal path shape
    private val splines by lazy { mutableListOf<MutableList<PointF>>() }  // splines for every free hand track

    override fun beforeAction(): ActionListener
    {
        setStatusBar()

        return this
    }

    override fun action(view: View?, evt: InputEvent?): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
        else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPointer = true

                splines.add( mutableListOf(logicalTouchLocation) )  // MOVE_TO

                serialPath.moveTo( logicalTouchLocation )
            }
            MotionEvent.ACTION_MOVE -> {
                splines.last().add( logicalTouchLocation )  // LINE_TO

                serialPath.lineTo( logicalTouchLocation )
            }
            MotionEvent.ACTION_UP -> {
                draggingPointer = false

                if ( checkDoubleTap() )  // finish
                {
                    // create serial path with first spline
                    val serialPath = if ( splines.first().size > 1 )
                                         SerialPath().storeSpline( *splines.first().toTypedArray() )
                                     else
                                         SerialPath().storePoint( logicalTouchLocation )
                    // append serial paths
                    for ( i in 1 until splines.size )
                        serialPath += if ( splines[i].size > 1 )
                                          SerialPath().storeSpline( *splines[i].toTypedArray() )
                                      else
                                          SerialPath().storePoint( logicalTouchLocation )
                    serialPath.forceUpdate()

                    // add free hand splines to exercise
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val shape = ExerciseShape( "",
                                               str(R.string.new_freehand),
                                               serialPath,
                                               paint.asSerialPaint( Ctx.ctx.fillColor ) )

                    Ctx.ctx.exercise.add(shape)

                    // add extremes
                    if (Ctx.ctx.addExtremes)
                    {
                        val transaction = object : UndoRedoTransaction() {
                            override fun getDescription()
                                = "${str(R.string.new_spline)} ${str(R.string.undoredo_and_extremes).format(2)}"
                        }

                        transaction.add( UndoRedoableNewShape( shape,
                                                               Ctx.ctx.exercise.indexOf(shape),
                                                               str(R.string.new_freehand) ) )

                        paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                        for (extreme in arrayOf( splines.first().first(), splines.last().last() ) )
                            ExerciseShape( "",
                                           str(R.string.desc_extremes),
                                           SerialPath().storePoint(extreme),
                                           paint.asSerialPaint() ).run {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                                                this,
                                                                Ctx.ctx.exercise.indexOf(this),
                                                                str(R.string.desc_extremes) ) )
                            }

                        Ctx.ctx.undoRedoManager.addItem(transaction)
                    }
                    // only the shape
                    else
                        Ctx.ctx.undoRedoManager.addItem(
                                UndoRedoableNewShape(
                                        shape,
                                        Ctx.ctx.exercise.indexOf(shape),
                                        str(R.string.new_spline) ) )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if (Ctx.ctx.keepTool) FreeHandAction() else defaultAction).beforeAction()
                }  // checkDoubleTap
            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw touch pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( serialPath ).asPath(), toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            else ->
                str(R.string.status_freehand2,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_freehand1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class FreeHandAction
