package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*

class BisectrixAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var segment1: Pair<ExerciseShape,PathSegment>? = null  // first shape & segment selected for bisectrix
    private var segment2: Pair<ExerciseShape,PathSegment>? = null  // second shape & segment selected for bisectrix
    private var start: PointF? = null  // bisectrix start

    override fun beforeAction(): BisectrixAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( segment1 == null )  // set first segment or side
                {
                    segment1 = exCanvas.getSideAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation) )
                }
                else if ( segment2 == null )  // set second segment or side
                {
                    segment2 = exCanvas.getSideAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation) )
                    if ( segment2 != null )
                    {
                        if ( getBisectrix() == null )
                        {
                            AlertDialog.Builder(MAct.act)
                                    .setTitle( R.string.new_bisectrix )
                                    .setIcon( R.mipmap.error_icon )
                                    .setMessage( R.string.error_bisectrix )
                                    .show()

                            // update or keep tool
                            Ctx.ctx.currentActionForCanvas.value =
                                    (if (Ctx.ctx.keepTool) BisectrixAction() else defaultAction)
                                            .beforeAction()
                        }
                    }
                }
                else if ( start == null )  // set start of the bisectrix
                {
                    start = getBisectrix()?.end
                }
                else  // add bisectrix
                {
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val descHtml = str(R.string.new_bisectrix,
                                       Ctx.ctx.getHexColor(R.color.name_item),
                                       elvis(segment1!!.first.name,"?"),
                                       elvis(segment2!!.first.name,"?"))

                    val bisectrixSegment = getBisectrix()
                    val bisectrix = ExerciseShape( "",
                                                   descHtml,
                                                   SerialPath().storeSegment(bisectrixSegment!!),
                                                   paint.asSerialPaint( Ctx.ctx.fillColor )
                    )

                    Ctx.ctx.exercise.add(bisectrix)
                    val undoRedoNew = UndoRedoableNewShape( bisectrix,
                                                            Ctx.ctx.exercise.indexOf(bisectrix),
                                                            descHtml )

                    if (Ctx.ctx.addExtremes)
                    {
                        val transaction = object : UndoRedoTransaction()
                        {
                            override fun getDescription() =
                                    "$descHtml ${str(R.string.undoredo_and_extremes).format(2) }"
                        }

                        transaction.add(undoRedoNew)

                        paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                        for (extreme in arrayOf(bisectrixSegment.start, bisectrixSegment.end))
                            ExerciseShape( "",
                                           str(R.string.desc_extremes2,
                                               Ctx.ctx.getHexColor(R.color.name_item),
                                               elvis(bisectrix.name,"?")),
                                    SerialPath().storePoint(extreme),
                                    paint.asSerialPaint() ).run {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                                            this,
                                                            Ctx.ctx.exercise.indexOf(this),
                                                            "${R.string.new_point} [extreme]" ) )
                            }

                        Ctx.ctx.undoRedoManager.addItem(transaction)
                    }
                    else
                        Ctx.ctx.undoRedoManager.addItem(undoRedoNew)

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if (Ctx.ctx.keepTool) BisectrixAction() else defaultAction)
                                    .beforeAction()
                }
            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getBisectrix(): PathSegment?
    {
        // calculate intersection between segments
        val vertex1 = segment1!!.second.start
        val vertex2 = segment1!!.second.end
        val vertex3 = segment2!!.second.start
        val vertex4 = segment2!!.second.end
        val v1 = vertex2 - vertex1
        val v2 = vertex4 - vertex3
        val intersection = linesIntersection( vertex1, vertex2, vertex3, vertex4 ) ?: return null

        // calculate bisectrix angle
        var ang = (v1.arg() + v2.arg()) / 2f
        val region = logicalTouchLocation.relativeTo( segment1!!.second ) *
                     logicalTouchLocation.relativeTo( segment2!!.second )
        if ( region > 0f )  // bisectrix 1 or 2 (orthogonal)
            ang += HPIf

        // get bisectrix extremes
        val p1 = start ?: intersection
        val p2 = if ( start == null || start!!.distance( intersection ) < 0.000001f )
                    p1.pointRelativeToCenter( ang, 1f )
                else
                    intersection
        val q1 = logicalTouchLocation
        val q2 = q1 + (p2 - p1).normal()
        val end = linesIntersection( p1, p2, q1, q2 ) ?: return null

        return PathSegment( p1, 0f, end, 1f )
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        // draw segment/side 1
        val localSegment1 = segment1 ?: exCanvas.getSideAtCanvasPoint(
                                    exCanvas.toPhysicalViewport(logicalTouchLocation) ) ?: return

        exCanvas.usePhysicalViewport {
            val p = it.toPhysicalViewport(localSegment1.second.start)
            val q = it.toPhysicalViewport(localSegment1.second.end)
            it.canvas.drawLine( p.x, p.y, q.x, q.y, toolPaint )
        }

        segment1 ?: return

        // draw segment/side 2
        val localSegment2 = segment2 ?: exCanvas.getSideAtCanvasPoint(
                exCanvas.toPhysicalViewport(logicalTouchLocation) ) ?: return

        exCanvas.usePhysicalViewport {
            val p = it.toPhysicalViewport(localSegment2.second.start)
            val q = it.toPhysicalViewport(localSegment2.second.end)
            it.canvas.drawLine( p.x, p.y, q.x, q.y, toolPaint )
        }

        segment2 ?: return

        // draw circle centered in start
        if ( start != null )
            drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw bisectrix
        val bisectrix = getBisectrix() ?: return
        exCanvas.usePhysicalViewport {
            val a = it.toPhysicalViewport( bisectrix.start )
            val b = it.toPhysicalViewport( bisectrix.end )
            it.canvas.drawLine( a.x, a.y, b.x, b.y, toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            segment1 == null ->
                str(R.string.status_bisectrix2,Ctx.ctx.getHexColor(R.color.tool_item))

            segment2 == null ->
                str(R.string.status_bisectrix3,Ctx.ctx.getHexColor(R.color.tool_item))

            start == null ->
                str(R.string.status_bisectrix4,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_bisectrix5,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_bisectrix1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
            // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class BisectrixAction
