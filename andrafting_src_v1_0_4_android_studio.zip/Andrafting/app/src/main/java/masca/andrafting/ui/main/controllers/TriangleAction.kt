package masca.andrafting.ui.main.controllers

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.PointF
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import android.widget.ImageButton
import androidx.core.graphics.PathSegment
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.controllers.TriangleAction.TriangleOpType.*
import masca.andrafting.ui.main.pointerLocation
import masca.andrafting.ui.main.str
import kotlin.math.sign

class TriangleAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var a: PointF? = null
    private var b: PointF? = null
    private var type: TriangleOpType = GENERAL

    private enum class TriangleOpType { GENERAL, RECTANGLE, EQUILATERAL, CIRCUMCENTER, ORTHOCENTER,
                                        INCENTER, BARYCENTER }

    init
    {
        self = this
    }

    inner class TriangleDialog( context: Context ): Dialog( context ), View.OnClickListener
    {
        override fun onCreate(savedInstanceState: Bundle?)
        {
            super.onCreate(savedInstanceState)

            setContentView( R.layout.triangle_dialog )

            findViewById<ImageButton>(R.id.btn_general).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_rectangle).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_equilateral).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_circumcenter).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_orthocenter).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_incenter).setOnClickListener( this )
            findViewById<ImageButton>(R.id.btn_barycenter).setOnClickListener( this )

            setOnCancelListener {
                Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
            }

            window?.setBackgroundDrawable( ColorDrawable( Color.TRANSPARENT ) )
        }

        override fun onClick(v: View) {
             when( v.id ) {
                R.id.btn_general -> type = GENERAL
                R.id.btn_rectangle -> type = RECTANGLE
                R.id.btn_equilateral -> type = EQUILATERAL
                R.id.btn_orthocenter -> type = ORTHOCENTER
                R.id.btn_circumcenter -> type = CIRCUMCENTER
                R.id.btn_incenter -> type = INCENTER
                R.id.btn_barycenter -> type = BARYCENTER
                else -> cancel()
            }
            dismiss()
        }
    }  // class TriangleDialog

    override fun beforeAction(): TriangleAction
    {
        TriangleDialogFragment().show( MAct.act.supportFragmentManager, "tag TriangleDialog" )

        setStatusBar()

        return this
    }

    override fun action(view: View?, evt: InputEvent?): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( a == null )  // set A
                    a = logicalTouchLocation
                else if ( b == null )  // set B
                    b = logicalTouchLocation
                else  // add triangle or special points
                {
                    addSelectedShape()

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if ( Ctx.ctx.keepTool ) TriangleAction() else defaultAction)
                                    .beforeAction()
                }
            }
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun addSelectedShape()
    {
        val shape: ExerciseShape

        when( type )
        {
            in setOf(GENERAL, RECTANGLE, EQUILATERAL) ->
            {
                val paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                          color = Ctx.ctx.strokeColor,
                                          cap = Ctx.ctx.cap,
                                          join = Ctx.ctx.join,
                                          dash = Ctx.ctx.dashPathEffect )

                shape = ExerciseShape( "",
                                        str( when(type)
                                                {
                                                    GENERAL -> R.string.triangle_triangle
                                                    RECTANGLE -> R.string.triangle_rectangle_full
                                                    else -> R.string.triangle_equilateral_full
                                                } ),
                                        getTriangle()!!,
                                        paint.asSerialPaint( Ctx.ctx.fillColor ) )
            }
            BARYCENTER ->
            {
                val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                          color = Ctx.ctx.pointColor )

                shape = ExerciseShape( "",
                                        str(R.string.triangle_barycenter),
                                        SerialPath().storePoint( MidpointAction.centroid( getTriangle()!! ) ),
                                        paint.asSerialPaint() )
            }
            ORTHOCENTER ->
            {
                val orthocenter = orthocenter( getTriangle()!! ) ?: PointF(Float.NaN, Float.NaN)
                val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                          color = Ctx.ctx.pointColor )

                shape = ExerciseShape( "",
                                        str(R.string.triangle_orthocenter),
                                        SerialPath().storePoint( orthocenter ),
                                        paint.asSerialPaint() )
            }
            INCENTER ->
            {
                val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                          color = Ctx.ctx.pointColor )

                shape = ExerciseShape( "",
                                        str(R.string.triangle_incenter),
                                        SerialPath().storePoint( incenter( getTriangle()!! ) ),
                                        paint.asSerialPaint() )
            }
            CIRCUMCENTER ->
            {
                val paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                          color = Ctx.ctx.pointColor )

                shape = ExerciseShape( "",
                                        str(R.string.triangle_circumcenter),
                                        SerialPath().storePoint( circumcenter( getTriangle()!! ) ),
                                        paint.asSerialPaint() )
            }
            else -> throw IllegalArgumentException()
        }

        Ctx.ctx.exercise.add( shape )

        Ctx.ctx.undoRedoManager.addItem( UndoRedoableNewShape( shape,
                                            Ctx.ctx.exercise.indexOf(shape), shape.description ) )
    }

    private fun getTriangle(): SerialPath?
    {
        a ?: return null

        return SerialPath().apply {
            moveTo(a!!)
            if ( b == null )
            {
                lineTo( logicalTouchLocation )
                close()
                return this
            }
            else
                lineTo( b!! )
            when(type)
            {
                RECTANGLE ->
                {
                    val v = b!! - a!!
                    val n = v.normal()
                    val p = if ( logicalTouchLocation.distanceSqr(a!!) <
                                 logicalTouchLocation.distanceSqr(b!!) ) a!! else b!!
                    val c = linesIntersection( p, p + n,
                            logicalTouchLocation, logicalTouchLocation + v )
                    lineTo( c!! )
                }
                EQUILATERAL ->
                {
                    val factor = K.toFloat() * sign( logicalTouchLocation.relativeTo(
                                                                PathSegment( b!!, 0f, a!!, 1f ) ) )
                    val v = b!!- a!!
                    val n = v.normal() * factor
                    val c = PathSegment( a!!, 0f, b!!, 1f ).midpoint() + n
                    lineTo( c )
                }
                else -> lineTo( logicalTouchLocation )
            }  // when
            close()
        }  // apply
    }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        if (!this::logicalTouchLocation.isInitialized)
            return

        // contrasted paint
        val toolPaint = defaultToolPaint(Ctx.ctx.exercise.background, 3f)

        // draw pointer
        if (draggingPointer)
            drawCircleTouch(exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted)

        a ?: return

        // draw A point
        drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(a!!))

        val triangle = getTriangle()!!

        // draw triangle
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath(it.transformedShapeToPhysical(triangle).asPath(), toolPaint)
        }

        b ?: return

        // draw B point
        drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(b!!))

        // draw special points
        exCanvas.usePhysicalViewport {
            if ( triangle.getAllPolyVertices().size > 2 )
            {
                val point: PointF? = when(type)
                {
                    CIRCUMCENTER -> circumcenter(triangle)
                    ORTHOCENTER -> orthocenter(triangle)
                    INCENTER -> incenter(triangle)
                    BARYCENTER -> MidpointAction.centroid(triangle)
                    else -> null
                }
                if (point != null)
                {
                    toolPaint.strokeWidth = Ctx.ctx.pointWidth
                    val pPoint = it.toPhysicalViewport(point)
                    it.canvas.drawPoint(pPoint.x, pPoint.y, toolPaint)
                }
            }
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            a == null ->
                str(R.string.status_triangle2,Ctx.ctx.getHexColor(R.color.tool_item))

            b == null ->
                str(R.string.status_triangle3,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_triangle4,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_triangle1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

    companion object
    {
        lateinit var self: TriangleAction

        fun orthocenter( serialPath: SerialPath ): PointF?
        {
            if ( serialPath.getAllPolyVertices().size < 3 )
                return serialPath.getAllPolyVertices()[0]

            val (A,B,C) = serialPath.getAllPolyVertices()
            val nBC = (C - B).normal()
            val nAC = (C - A).normal()

            return linesIntersection( A, A + nBC, B, B + nAC)
        }

        fun incenter( serialPath: SerialPath ): PointF
        {
            if ( serialPath.getAllPolyVertices().size < 3 )
                return serialPath.getAllPolyVertices()[0]

            val (A,B,C) = serialPath.getAllPolyVertices()
            val a = (C-B).length()
            val b = (C-A).length()
            val c = (B-A).length()
            val abc = a + b + c

            return PointF( ( a*A.x + b*B.x + c*C.x ) / abc, ( a*A.y + b*B.y + c*C.y ) / abc )
        }

        fun circumcenter( serialPath: SerialPath ): PointF
        {
            if ( serialPath.getAllPolyVertices().size < 3 )
                return serialPath.getAllPolyVertices()[0]

            val (A,B,C) = serialPath.getAllPolyVertices()
            val dCBx = C.x - B.x
            val dBCy = B.y - C.y
            val dACx = A.x - C.x
            val dCAy = C.y - A.y
            val dBAx = B.x - A.x
            val dABy = A.y - B.y
            val d = 2 * ( A.x * dBCy + B.x * dCAy + C.x * dABy )

            return PointF(
                ((A.x * A.x + A.y * A.y) * dBCy + (B.x * B.x + B.y * B.y) * dCAy + (C.x * C.x + C.y * C.y) * dABy) / d,
                ((A.x * A.x + A.y * A.y) * dCBx + (B.x * B.x + B.y * B.y) * dACx + (C.x * C.x + C.y * C.y) * dBAx) / d )
        }
    }

}  // class TriangleAction


class TriangleDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return TriangleAction.self.TriangleDialog( MAct.act )
    }
}


/** sqrt(3)/2 = 0.8660254037844386 */
private const val K = 0.8660254037844386