package masca.andrafting.ui.main.controllers

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.InputEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.DialogFragment
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.pointerLocation
import masca.andrafting.ui.main.str
import kotlin.math.max
import kotlin.math.min

class CommentAction: ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var start: PointF? = null

    companion object
    {
        lateinit var self: CommentAction
    }

    init
    {
        self = this
    }

    override fun beforeAction(): CommentAction
    {
        setStatusBar()

        return this
    }

    override fun action(view: View?, evt: InputEvent?): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if ( start == null )  // set start
                    start = logicalTouchLocation
                else  // show font dialog
                {
                    CommentDialogFragment()
                            .show( MAct.act.supportFragmentManager, "app CommentDialog" )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if ( Ctx.ctx.keepTool ) CommentAction() else defaultAction)
                                    .beforeAction()
                }
            }
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getCommentBox(): RectF
    {
        var left = min( logicalTouchLocation.x, start!!.x )
        var right = max( logicalTouchLocation.x, start!!.x )
        if ( Ctx.ctx.useRuler )
        {
            if ( logicalTouchLocation.x < start!!.x )
                left = start!!.x - Ctx.ctx.rulerDistanceMul
            else
                right = start!!.x + Ctx.ctx.rulerDistanceMul
        }

        return RectF( left,
                      min( logicalTouchLocation.y, start!!.y ),
                      right,
                      max( logicalTouchLocation.y, start!!.y ) )
    }

    fun createFontDialog(): AlertDialog
    {
        val root = LayoutInflater.from( Ctx.ctx ).inflate( R.layout.comment_dialog, null )

        val editComment = root.findViewById<EditText>(R.id.edit_comment).apply { setText("") }
        val checkBold = root.findViewById<CheckBox>(R.id.check_bold)
        val checkItalic = root.findViewById<CheckBox>(R.id.check_italic)
        val spinnerFont = root.findViewById<Spinner>(R.id.spinner_font_family).apply {
            adapter = ArrayAdapter.createFromResource(
                                MAct.act, R.array.typeface, android.R.layout.simple_list_item_1 )
            setSelection(2)
        }

        return AlertDialog.Builder( MAct.act )
                .setView( root )
                .setTitle( R.string.btn_comment )
                .setIcon( R.mipmap.text )
                .setPositiveButton( R.string.btn_ok ) { _, _ ->

                    val paint = defaultPaint( color = Ctx.ctx.strokeColor ).apply {
                        typeface = Typeface.create(
                                when ( spinnerFont.selectedItemPosition )
                                {
                                    0 -> Typeface.SERIF
                                    1 -> Typeface.SANS_SERIF
                                    2 -> Typeface.MONOSPACE
                                    else -> Typeface.MONOSPACE
                                },
                                when
                                {
                                    checkBold.isChecked && checkItalic.isChecked -> Typeface.BOLD_ITALIC
                                    checkBold.isChecked -> Typeface.BOLD
                                    checkItalic.isChecked -> Typeface.ITALIC
                                    else -> Typeface.NORMAL
                                }
                        )  // #create
                    }  // Positive

                    val commentBox = ExerciseShape( "",
                            editComment.text.toString(),
                            SerialPath().storeRectangle( getCommentBox() ),
                            paint.asSerialPaint( Ctx.ctx.fillColor ).apply {
                                textFamily = arrayOf("SERIF","SANS-SERIF","MONOSPACE")[spinnerFont.selectedItemPosition].lowercase()  // TODO improve
                            })
                    commentBox.isComment = true

                    Ctx.ctx.exercise.add( commentBox )

                    Ctx.ctx.undoRedoManager.addItem( UndoRedoableNewShape( commentBox,
                            Ctx.ctx.exercise.indexOf(commentBox), str(R.string.new_rectangle) ) )
                }
                .setNegativeButton( R.string.btn_cancel, null )
                .create().apply {
                    window?.setBackgroundDrawable(
                            AppCompatResources.getDrawable(MAct.act, R.drawable.dialog_background))
                }
    }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        start ?: return

        // draw start point
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw box
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical(
                            SerialPath().storeRectangle( getCommentBox() ) ).asPath(), toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            start == null ->
                str(R.string.status_comment2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_comment3,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_comment1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class CommentAction


class CommentDialogFragment: DialogFragment()
{
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        return CommentAction.self.createFontDialog()
    }
}  // CommentDialogFragment
