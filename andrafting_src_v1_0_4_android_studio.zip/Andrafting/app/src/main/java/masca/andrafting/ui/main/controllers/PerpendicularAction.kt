package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import androidx.core.graphics.minus
import masca.andrafting.*
import masca.andrafting.ui.main.*

class PerpendicularAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var sideInfo: Pair<ExerciseShape,PathSegment>? = null  // shape and side
    private var start: PointF? = null

    override fun beforeAction(): PerpendicularAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> draggingPointer = true
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP ->
            {
                draggingPointer = false

                if (sideInfo == null)  // set segment or side
                {
                    sideInfo = exCanvas.getSideAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation) )
                }
                else if ( start == null )  // set start of the perpendicular
                {
                    start = logicalTouchLocation
                }
                else  // add perpendicular
                {
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val descHtml = str(R.string.new_perpendicular,
                                       Ctx.ctx.getHexColor(R.color.name_item),
                                       elvis(sideInfo!!.first.name,"?"))

                    val perpendicularSegment = getPerpendicular()
                    val perpendicular = ExerciseShape( "",
                                                       descHtml,
                                                SerialPath().storeSegment( perpendicularSegment ),
                                                paint.asSerialPaint() )

                    Ctx.ctx.exercise.add( perpendicular )
                    val undoRedoNew = UndoRedoableNewShape( perpendicular,
                                                            Ctx.ctx.exercise.indexOf(perpendicular),
                                                            descHtml )

                    if ( Ctx.ctx.addExtremes )
                    {
                        val transaction = object: UndoRedoTransaction() {
                            override fun getDescription() =
                                            "$descHtml ${str(R.string.undoredo_and_extremes).format(2)}"
                        }

                        transaction.add( undoRedoNew )

                        paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor )

                        for ( extreme in arrayOf(perpendicularSegment.start, perpendicularSegment.end) )
                            ExerciseShape( "",
                                           str(R.string.desc_extremes2,
                                               Ctx.ctx.getHexColor(R.color.name_item),
                                               elvis(perpendicular.name,"?")),
                                    SerialPath().storePoint( extreme ),
                                    paint.asSerialPaint() ).run {
                                Ctx.ctx.exercise.add(this)
                                transaction.add( UndoRedoableNewShape(
                                                        this,
                                                        Ctx.ctx.exercise.indexOf(this),
                                                        "${str(R.string.new_point)} [extreme]" ) )
                            }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }
                    else
                        Ctx.ctx.undoRedoManager.addItem( undoRedoNew )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                            (if ( Ctx.ctx.keepTool ) PerpendicularAction() else defaultAction)
                                    .beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    private fun getPerpendicular(): PathSegment
    {
        val side = sideInfo!!.second
        val vSide = side.end - side.start
        val nSide = vSide.normal()
        val p1 = start ?: logicalTouchLocation
        val p2 = if( start == null )  // foot
                     linesIntersection( side.start, side.end, p1, p1 + nSide )!!
                 else  // intersection between perpendicular line to p1 and parallel line to touch
                     linesIntersection( p1, p1 + nSide,
                                        logicalTouchLocation, logicalTouchLocation + vSide )

        return PathSegment( p1, 0f, p2 ?: p1, 1f )
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        val localSideInfo = sideInfo ?: exCanvas.getSideAtCanvasPoint(
                                    exCanvas.toPhysicalViewport(logicalTouchLocation) ) ?: return

        // draw side/segment
        toolPaint.strokeWidth = with( exCanvas ) {
            if (Ctx.ctx.scaleStrokeWidth)
                scaleStrokeWidth( localSideInfo.first.paint.strokeWidth + 2f,
                        logicalViewport.width(),
                        logicalViewport.height(),
                        canvas.width,
                        canvas.height )
            else
                fixedStrokeWidth( localSideInfo.first.paint.strokeWidth + 2f,
                        logicalViewport.width(),
                        logicalViewport.height(),
                        canvas.width,
                        canvas.height )
        }

        with( localSideInfo.second ) {
            exCanvas.canvas.drawLine( start.x, start.y, end.x, end.y, toolPaint )
        }

        sideInfo ?: return

        toolPaint.strokeWidth = 3f

        // draw circle centered in start
        if ( start != null )
            drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw perpendicular
        val perpendicular = getPerpendicular()
        exCanvas.usePhysicalViewport {
            val a = it.toPhysicalViewport( perpendicular.start )
            val b = it.toPhysicalViewport( perpendicular.end )
            it.canvas.drawLine( a.x, a.y, b.x, b.y, toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            sideInfo == null ->
                str(R.string.status_perpendicular2,Ctx.ctx.getHexColor(R.color.tool_item))

            start == null ->
                str(R.string.status_perpendicular3,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_perpendicular4,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_perpendicular1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class PerpendicularAction
