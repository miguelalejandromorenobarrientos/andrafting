package masca.andrafting.ui.main.controllers

import android.view.InputEvent
import android.view.View
import masca.andrafting.BuildConfig
import masca.andrafting.R
import masca.andrafting.html
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.str
import java.io.File

class NoAction : ActionListener
{
    override fun beforeAction(): NoAction
    {
        val name = Ctx.ctx.exercise.title.ifBlank {
            if (Ctx.ctx.currentFile != null)
                Ctx.ctx.currentFile!!.path ?: ""
            else ""
        }

        // set status bar message
        """<font color=#2020B0><b>${str(R.string.app_name)}</b></font> 
            |<small><font color=#444444>v${BuildConfig.VERSION_NAME}</font></small>
            |  -  $name""".trimMargin()
                .also { Ctx.ctx.statusBarMsg.value = it.html() }

        return this
    }

    override fun action(view: View?, evt: InputEvent?): Nothing? = null
}
