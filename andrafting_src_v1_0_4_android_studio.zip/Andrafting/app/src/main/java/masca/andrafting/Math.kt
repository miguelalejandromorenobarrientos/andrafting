package masca.andrafting

import android.graphics.Matrix
import android.graphics.Point
import android.graphics.PointF
import android.graphics.RectF
import androidx.core.graphics.PathSegment
import androidx.core.graphics.contains
import masca.andrafting.ui.main.FIXED_ANGLES_INTERVAL
import masca.andrafting.ui.main.MAX_WIDTH
import masca.andrafting.ui.main.MIN_WIDTH
import java.lang.Float.max
import java.lang.Float.min
import kotlin.math.*


const val PIf = 3.1415927f
const val PI2f = 6.2831855f  // 2PI
const val HPIf = 1.5707963f  // PI/2
const val RT2 = 1.4142135f  // SQRT(2)

fun PointF.mapPoint( viewport1 : RectF, viewport2 : RectF ) : PointF
{
    val x = viewport2.left + ( x - viewport1.left ) * viewport2.width() / viewport1.width()
    val y = viewport2.top + ( y - viewport1.top ) * viewport2.height() / viewport1.height()

    return PointF( x, y )
}

fun RectF.mapPoint( point : PointF, destViewport : RectF ) = point.mapPoint( this, destViewport )

/**
 * Map point by the lineal transform given by the matrix.
 * Note: *immutable action, new point returned*
 * @param transformMatrix lineal transform matrix
 * @receiver original point
 * @return new image point
 */
fun PointF.mapPoint( transformMatrix : Matrix ) : PointF
{
	val arrayPoint = floatArrayOf( x, y )
	transformMatrix.mapPoints( arrayPoint )

	return PointF( arrayPoint[0], arrayPoint[1] )
}

fun PointF.distance( other: PointF ) = hypot( x - other.x, y - other.y )
infix fun PointF.distTo( other: PointF ) = distance(other)

fun PointF.distanceSqr( other: PointF ) = (x-other.x)*(x-other.x) + (y-other.y)*(y-other.y)

fun PointF.arg() = atan2( y, x )

fun PointF.pointRelativeToCenter( ang: Float, radius: Float = 1f )
	= this + polar( ang, radius )

/**
 * Mutable zoom over viewport in **(x,y)** point
 * @param point (x,y)
 * @param factor zoom factor; **&gt;1 for zoom out**, **&lt;1 for zoom in**
 * @param minSize minimum width or height allowed
 * @param maxSize maximum width or height allowed
 * @return this viewport zoomed
 */
fun RectF.zoom( point : PointF,
			    factor: Float,
			    minSize: Float = MIN_WIDTH,
			    maxSize: Float = MAX_WIDTH ): RectF
{
	val newWidth = width() * factor
	val newHeight = height() * factor

	if ( newWidth !in minSize..maxSize || newHeight !in minSize..maxSize )
		return this

	left = point.x + ( left - point.x ) * factor
	top = point.y + ( top - point.y ) * factor
	right = left + newWidth
	bottom = top + newHeight

	return this
}

/**
 * Transform an original viewport to destiny viewport (like canvas to logic or logic to canvas)
 * @receiver initial viewport
 * @param dest destiny viewport
 * @return change transform
 */
fun RectF.getTransformMatrix( dest: RectF ): Matrix
{
	val transform = Matrix()

	// transform from original viewport to destiny viewport
	val sx = dest.width() / width()
	val sy = dest.height() / height()
	val tx = dest.left - left
	val ty = dest.top - top

	return transform.apply {
		preScale(sx, sy)
		preTranslate(tx, ty)
	}
}

/**
 * Get intersection point between two lines by general straight equation
 * @param a (a)x+by+cz=0
 * @param b ax+(b)y+cz=0
 * @param c ax+by+(c)z=0
 * @param a_ (a_)x+b_y+c_z=0
 * @param b_ a_x+(b_)y+c_z=0
 * @param c_ a_x+b_y+(c_)z=0
 * @return intersection point or null if lines are parallel or coincident
 */
fun linesIntersection( a: Double, b: Double, c: Double, a_: Double, b_: Double, c_: Double ): PointF?
{
	val err = 1E-12 // (solve accuracy bugs in vertical lines)
	// second line is vertical
	if ( abs(b_) < err )
		return if ( abs(b) < err ) null  // first line is vertical  (parallel or coincident)
			   else PointF( (-c_ / a_).toFloat(), ((a * c_ - a_ * c) / (a_ * b)).toFloat() )  // lines are secant

	val div = b_ * a - b * a_

	// lines are parallel or coincident
	if (div == 0.0) return null

	// lines are secant
	val x = (b * c_ - b_ * c) / div

	return PointF( x.toFloat(), ((-c_ - a_ * x) / b_).toFloat() )
}

/**
 * Get intersection point between two lines given by extreme points of segments
 * @param p1 first segment start
 * @param p2 first segment end
 * @param q1 second segment start
 * @param q2 second segment end
 * @return intersection point or null if lines are parallel or coincident
 */
fun linesIntersection( p1: PointF, p2: PointF, q1: PointF, q2: PointF ): PointF? =
	linesIntersection(
		p2.y.toDouble() - p1.y.toDouble(),  // a
		p1.x.toDouble() - p2.x.toDouble(),  // b
		p2.x.toDouble() * p1.y.toDouble() - p1.x.toDouble() * p2.y.toDouble(),  // c
		q2.y.toDouble() - q1.y.toDouble(),  // a_
		q1.x.toDouble() - q2.x.toDouble(),  // b_
		q2.x.toDouble() * q1.y.toDouble() - q1.x.toDouble() * q2.y.toDouble()  // c_
	)

/**
 * Get intersection point between two segments by extreme points
 * @param p1 first segment start
 * @param p2 first segment end
 * @param q1 second segment start
 * @param q2 second segment end
 * @return intersection point or null if segments are external or coincident
 */
fun segmentsIntersection( p1: PointF, p2: PointF, q1: PointF, q2: PointF ): PointF?
{
	// containing lines intersection
	val linesIntersection = linesIntersection( p1, p2, q1, q2 ) ?: return null

	// check parameters in [0,1]
	if ( p2.x - p1.x != 0f )  // oblique segment
	{
		val t = (linesIntersection.x - p1.x) / (p2.x - p1.x)
		if (t !in 0f..1f)
			return null
	}
	else  // vertical segment
	{
		if ( linesIntersection.y !in min( p1.y, p2.y)..max( p1.y, p2.y ) )
			return null
	}

	return if ( q2.x - q1.x != 0f )  // oblique segment
		   {
				val u = (linesIntersection.x - q1.x) / (q2.x - q1.x)
				if (u !in 0f..1f)
					null
				else
					linesIntersection
		   }
		   else  // vertical segment
		   {
				if ( linesIntersection.y !in min( q1.y, q2.y)..max( q1.y, q2.y ) )
					null
				else
					linesIntersection
		   }
}

/**
 * Check intersection segment-rectangle (only rectangle boundary)
 * @param p1 segment extreme
 * @param p2 segment extreme
 * @param r rectangle
 * @return true if intersection
 */
fun segmentRectangleBoundaryIntersects( p1: PointF, p2: PointF, r: RectF ): Boolean
{
	val vertex = r.vertex()

	return segmentsIntersection( p1, p2, vertex[0], vertex[1] ) != null
			|| segmentsIntersection( p1, p2, vertex[1], vertex[2] ) != null
			|| segmentsIntersection( p1, p2, vertex[2], vertex[3] ) != null
			|| segmentsIntersection( p1, p2, vertex[3], vertex[0] ) != null
}

/**
 * Check intersection segment-rectangle (interior included)
 * @param p1 segment extreme
 * @param p2 segment extreme
 * @param r rectangle
 * @return true if intersection
 */
fun segmentRectangleIntersects( p1: PointF, p2: PointF, r: RectF )
	= r.contains( p1 ) || r.contains( p2 ) || segmentRectangleBoundaryIntersects( p1, p2, r )

fun PathSegment.generalEquation() = arrayOf(
		end.y - start.y,  // A
		start.x - end.x,   // B
		start.y * ( end.x - start.x ) - start.x * ( end.y - start.y ) )  // C

/**
 * Get position of a point relative to a segment. Use *sign* function to get {-1,0,1} result
 */
infix fun PointF.relativeTo( segment: PathSegment ) = segment.generalEquation().let {
	x * it[0] + y * it[1] + it[2]
}

/**
 * Point-Line distance
 * @param segment line given by a segment
 * @return distance
 */
fun PointF.distance( segment: PathSegment ) = segment.generalEquation().let {
	abs( it[0]*x + it[1]*y + it[2] ) / hypot( it[0], it[1] )
}

fun PointF.normalize()= run {
	val length = length()
	if ( abs(length) >= 1E-9f ) PointF( x / length, y / length ) else PointF()
}

fun PathSegment.midpoint() = PointF( (start.x + end.x) / 2f, (start.y + end.y) / 2f )

/** Scalar product */
operator fun PointF.times( other: PointF ) = x * other.x + y * other.y

fun PointF.angle( other: PointF ) = acos( this * other / ( length() * other.length() ) )

fun toDegrees360( rad: Float ) = ((Math.toDegrees( rad.toDouble() ) + 360) % 360).toFloat()

operator fun Point.component1() = x
operator fun Point.component2() = y
operator fun PointF.component1() = x
operator fun PointF.component2() = y

/**
 * Normal vector in anticlockwise sense (levorrotation)
 */
fun PointF.normal() = PointF( -y, x )

operator fun PointF.times( factor: Float ) = PointF( x * factor, y * factor )

operator fun PointF.plus( other: PointF ) = PointF( x + other.x, y + other.y )

operator fun PointF.minus( other: PointF ) = PointF( x - other.x, y - other.y )

fun polar( ang: Float, r: Float = 1f ) = PointF(r*cos(ang),r*sin(ang))

/**
 * Calculate the end point of a segment taking account ruler and predefined angles
 * @param start start point of the segment
 * @param logicalTouchLocation logical touch position (maybe adjusted)
 * @param fixedAngles use predefined angles
 * @param rulerDist if using ruler, ruler measure multiplied by multiplier, else negative number
 * @param protractorAngle if using protractor, angle of the final point
 * @return the suitable end point of the segment
 */
fun endPoint( start: PointF = PointF(),
			  logicalTouchLocation: PointF,
			  fixedAngles: Boolean,
			  rulerDist: Float = -1f,
			  protractorAngle: Float = -1f )
	: PointF
{
	val v = logicalTouchLocation - start

	return when
	{
		protractorAngle >= 0f -> start.pointRelativeToCenter(
									protractorAngle, if (rulerDist < 0) v.length() else rulerDist )
		fixedAngles -> start.pointRelativeToCenter(
							round( v.arg() / FIXED_ANGLES_INTERVAL ) * FIXED_ANGLES_INTERVAL,
							if (rulerDist < 0) v.length() else rulerDist )
		rulerDist < 0 -> logicalTouchLocation
		else -> start + v.normalize() * rulerDist
	}
}

infix fun Float.clip( r: ClosedFloatingPointRange<Float> )
		= min(r.endInclusive, kotlin.math.max(r.start, this))

infix fun Int.clip( r: IntRange )
		= min( r.last, max( r.first, this ) )
