package masca.andrafting

import android.graphics.Color
import android.graphics.PointF
import android.graphics.RectF
import android.util.Log
import masca.andrafting.ui.main.APPNAME
import java.io.IOException
import java.io.ObjectInputStream
import java.io.Serializable
import java.lang.Integer.max

data class Exercise(
        var title : String = "",
        var description : String = "",
        val shapes : MutableList<ExerciseShape> = mutableListOf(),
        var background : Int = Color.WHITE,
        var startFrameIndex : Int = 0,
        @Transient var frameIndex : Int = shapes.size - 1
    ) : MutableList<ExerciseShape> by shapes, Serializable
{
    private fun readObject( ois: ObjectInputStream )
    {
        try
        {
            ois.defaultReadObject()
            frameIndex = size - 1
        }
        catch ( e: IOException )
        {
            Log.e( "$APPNAME ERROR #readObject", e.toString() )
        }
    }

    val shapesUntilFrameIndex: List<ExerciseShape>
        get() = subList( 0, frameIndex + 1 )

    val frameIndexAtEnd
        get() = frameIndex == size - 1

    val bounds: RectF
        get() {
            if ( isEmpty() )  // dummy bounds for empty exercise
                return createRectFFromCenter( PointF( 0f, 0f ), 1000f, 1000f )

            val rect = this[0].getBounds()
            for ( i in 1 until size )
                rect.union( this[i].getBounds() )

            return rect
        }

    // TODO MALFUNCTION
    /*fun canvasBounds( matrix: Matrix ): RectF
    {
        if ( isEmpty() )
            return bounds

        val rect = this[0].getBounds().transform( matrix ).also {
            it.inset( -this[0].paint.strokeWidth / 2f, -this[0].paint.strokeWidth / 2f )
        }
        for ( i in 1 until size )
            rect.union( this[i].getBounds().transform( matrix ).also {
                it.inset( -this[i].paint.strokeWidth / 2f, -this[i].paint.strokeWidth / 2f )
            } )

        return rect
    }*/

    override fun add( element: ExerciseShape ): Boolean
    {
        add( size, element )

        return true
    }

    override fun add( index: Int, element: ExerciseShape )
    {
        shapes.add( index, element )
        if ( index <= frameIndex + 1 )
            frameIndex++
    }

    /*override fun addAll( elements: Collection<ExerciseShape> ): Boolean
    {
        var res = false

        elements.forEach { res = add( it ) || res }

        return res
    }*/

    override fun removeAt( index: Int ) : ExerciseShape
    {
        val shape = shapes.removeAt( index )

        if ( index <= frameIndex )
            frameIndex--
        if ( startFrameIndex >= size )
            startFrameIndex = max( 0, size - 1 )

        return shape
    }

    override fun remove( element: ExerciseShape ) : Boolean
    {
        val index = indexOf( element )
        if ( index >= 0 )
        {
            removeAt(index)
            return true
        }
        return false
    }

    /*override fun removeAll( elements: Collection<ExerciseShape> ): Boolean
    {
        var res = false

        elements.forEach { res = remove( it ) || res }

        return res
    }*/
}