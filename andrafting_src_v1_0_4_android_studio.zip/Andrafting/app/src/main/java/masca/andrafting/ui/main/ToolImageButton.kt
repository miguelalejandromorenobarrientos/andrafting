package masca.andrafting.ui.main

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import androidx.appcompat.widget.AppCompatImageButton
import masca.andrafting.CANVAS_FRAGMENT_INDEX
import masca.andrafting.MainActivity

class ToolImageButton( context : Context, attr : AttributeSet )
    : AppCompatImageButton( context, attr )
{
    var onClick : (View) -> Unit = {}
    var onLongClick : (View) -> Boolean = { true }

    init
    {
        // default listeners
        if ( context is MainActivity )
        {
            setOnClickListener {
                context.binding.viewPager.currentItem = CANVAS_FRAGMENT_INDEX
                onClick( it )
            }
            /*setOnLongClickListener {
                Toast.makeText( context, contentDescription, Toast.LENGTH_LONG ).show()
                onLongClick( it )
            }*/
        }

        // set padding
        val padding = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            4f,
            resources.displayMetrics ).toInt()
        setPadding( padding, padding, padding, padding )

        // scale type
        scaleType = ScaleType.FIT_CENTER
    }
}
