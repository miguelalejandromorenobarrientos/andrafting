package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.*

class ParallelAction: ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF  // physical touch
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var draggingPointer = false
    private var origin: Pair<ExerciseShape,PathSegment>? = null  // shape and side
    private var start: PointF? = null  // start of the parallel
    private var initSecondPoint = false  // flag for second extreme

    override fun beforeAction(): ParallelAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!!
        else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPointer = true

                if ( start != null )
                    initSecondPoint = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                draggingPointer = false

                // set shape and side
                if ( origin == null )
                {
                    origin = exCanvas.getSideAtCanvasPoint(
                                                exCanvas.toPhysicalViewport(logicalTouchLocation) )
                }
                else
                {
                    // set start point of the parallel
                    if ( start == null )
                        start = getParallel().start
                    // set end point and add parallel
                    else
                    {
                        var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                                  color = Ctx.ctx.strokeColor,
                                                  cap = Ctx.ctx.cap,
                                                  join = Ctx.ctx.join,
                                                  dash = Ctx.ctx.dashPathEffect )

                        val descHtml = str(R.string.new_parallel,
                                           Ctx.ctx.getHexColor(R.color.name_item),
                                           elvis(origin!!.first.name,"?"))

                        val parallelSegment = getParallel()
                        val parallel = ExerciseShape( "",
                                                       descHtml,
                                                       SerialPath().storeSegment( parallelSegment ),
                                                       paint.asSerialPaint() )

                        Ctx.ctx.exercise.add( parallel )
                        val undoRedoNew = UndoRedoableNewShape( parallel,
                                                                Ctx.ctx.exercise.indexOf(parallel),
                                                                descHtml )

                        if ( Ctx.ctx.addExtremes )
                        {
                            val transaction = object: UndoRedoTransaction() {
                                override fun getDescription() =
                                    "$descHtml ${str(R.string.undoredo_and_extremes).format(2)}"
                            }

                            transaction.add( undoRedoNew )

                            paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                                  color = Ctx.ctx.pointColor )

                            for ( extreme in arrayOf(parallelSegment.start, parallelSegment.end) )
                                ExerciseShape( "",
                                               str(R.string.desc_extremes2,
                                                   Ctx.ctx.getHexColor(R.color.name_item),
                                                   elvis(parallel.name,"?")),
                                               SerialPath().storePoint( extreme ),
                                               paint.asSerialPaint() ).run {
                                    Ctx.ctx.exercise.add(this)
                                    transaction.add( UndoRedoableNewShape(
                                                        this,
                                                        Ctx.ctx.exercise.indexOf(this),
                                                        "${str(R.string.new_point)} [extreme]" ) )
                                }

                            Ctx.ctx.undoRedoManager.addItem( transaction )
                        }
                        else
                            Ctx.ctx.undoRedoManager.addItem( undoRedoNew )

                        // update or keep tool
                        Ctx.ctx.currentActionForCanvas.value =
                                (if ( Ctx.ctx.keepTool ) ParallelAction() else defaultAction)
                                    .beforeAction()
                    }
                }
            }  // case ACTION_UP
        }  // when

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw pointer
        if ( draggingPointer )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        val localOrigin = origin ?: exCanvas.getSideAtCanvasPoint(
                                    exCanvas.toPhysicalViewport(logicalTouchLocation) ) ?: return

        // draw segment/side
        toolPaint.strokeWidth = with( exCanvas ) {
                if (Ctx.ctx.scaleStrokeWidth)
                    scaleStrokeWidth( localOrigin.first.paint.strokeWidth + 2f,
                                      logicalViewport.width(),
                                      logicalViewport.height(),
                                      canvas.width,
                                      canvas.height )
                else
                    fixedStrokeWidth( localOrigin.first.paint.strokeWidth + 2f,
                                      logicalViewport.width(),
                                      logicalViewport.height(),
                                      canvas.width,
                                      canvas.height )
            }

        with( localOrigin.second ) {
            exCanvas.canvas.drawLine( start.x, start.y, end.x, end.y, toolPaint )
        }

        origin ?: return

        toolPaint.strokeWidth = 3f

        // draw circle centered in start
        if ( start != null )
            drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( start!! ) )

        // draw parallel
        val parallel = getParallel()
        exCanvas.usePhysicalViewport {
            val a = exCanvas.toPhysicalViewport(parallel.start)
            val b = exCanvas.toPhysicalViewport(parallel.end)
            it.canvas.drawLine(a.x, a.y, b.x, b.y, toolPaint)
        }
    }

    private fun getParallel(): PathSegment
    {
        val side = origin!!.second
        val vector = side.end - side.start
        val normal = vector.normal()
        val point = if ( Ctx.ctx.useRuler ) getFixedDistanceStart() else logicalTouchLocation
        val p1 = if ( start == null ) point else start!!
        val p2 = p1 + vector
        val q1 = if ( start == null ) (side.start + side.end)*0.5f else logicalTouchLocation
        val q2 = q1 + normal

        return PathSegment( p1, 0f, linesIntersection( p1, p2, q1, q2 )!!, 1f )
    }

    private fun getFixedDistanceStart(): PointF
    {
        val side = origin!!.second
        val normal = (side.end - side.start).normal()
        val foot = linesIntersection( side.start, side.end,
                                      logicalTouchLocation, logicalTouchLocation + normal )!!

        return foot + ( logicalTouchLocation - foot ).normalize() * Ctx.ctx.rulerDistanceMul
    }

    private fun setStatusBar()
    {
        val txt = when {

            origin == null ->
                str(R.string.status_parallel2,Ctx.ctx.getHexColor(R.color.tool_item))

            start == null ->
                str(R.string.status_parallel3,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_parallel4,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_parallel1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
            // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class ParallelAction
