package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathSegment
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas
import masca.andrafting.ui.main.pointerLocation
import masca.andrafting.ui.main.str
import kotlin.math.min
import kotlin.math.sign

class ProtractorAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var vertex: PointF? = null
    private var extreme1: PointF? = null
    private var draggingPoint = false

    override fun beforeAction(): ProtractorAction
    {
        setStatusBar(null)

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPoint = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                draggingPoint = false
                if ( vertex == null )  // set vertex
                    vertex = logicalTouchLocation
                else if ( extreme1 == null )  // set extreme 1
                    extreme1 = logicalTouchLocation
                else  // set captured angle
                {
                    Ctx.ctx.protractorStoredAngle =
                                ( logicalTouchLocation - vertex!! ).angle( extreme1!! - vertex!! )

                    Ctx.ctx.currentActionForCanvas.value = defaultAction.beforeAction()
                    MAct.act.binding.switchProtractor.isChecked = true
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar(evt)

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPoint )
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        if ( vertex != null )
        {
            // draw circle centered in vertex angle
            drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(vertex!!))
            // draw segment vertex-{extreme1|logicalTouchLocation}
            exCanvas.usePhysicalViewport {
                val p1 = it.toPhysicalViewport( vertex!! )
                val p2 = it.toPhysicalViewport( if ( extreme1 == null ) logicalTouchLocation else extreme1!! )
                it.canvas.drawLine( p1.x, p1.y, p2.x, p2.y, toolPaint )
            }
        }

        if ( extreme1 != null )
        {
            // draw circle centered in extreme1
            drawCircleTouch(exCanvas, toolPaint, false, exCanvas.toPhysicalViewport(extreme1!!))
            // draw segment vertex-logicalTouchLocation for extreme 2 and angle
            exCanvas.usePhysicalViewport {
                val p1 = it.toPhysicalViewport( vertex!! )
                val p2 = it.toPhysicalViewport( logicalTouchLocation )
                it.canvas.drawLine( p1.x, p1.y, p2.x, p2.y, toolPaint )
                val p3 = it.toPhysicalViewport( extreme1!! )
                val angle = Math.toDegrees( ( p2 - p1 ).angle( p3 - p1 ).toDouble() ).toFloat()
                val radius = min( (p3 - p1).length(), (p2 - p1).length() ) / 4f
                it.canvas.drawArc(
                    p1.x - radius, p1.y - radius, p1.x + radius, p1.y + radius,
                        Math.toDegrees(( p3 - p1 ).arg().toDouble()).toFloat(),
                sign( p2.relativeTo( PathSegment( p3, 0f, p1, 1f ) ) ) * angle,
                 false, toolPaint )
                toolPaint.pathEffect = null
                toolPaint.textSize = 24f
                it.canvas.drawText( "%.3fº".format(angle), p2.x + 24, p2.y - 24, toolPaint )
            }
        }
    }

    private fun setStatusBar( evt: MotionEvent? )
    {
       val txt = when {

           !this::logicalTouchLocation.isInitialized ->
                str(R.string.status_protractor2,Ctx.ctx.getHexColor(R.color.tool_item))

           vertex == null && draggingPoint ->
                str(R.string.status_protractor3,Ctx.ctx.getHexColor(R.color.tool_item))

           extreme1 == null && !draggingPoint ->
               str(R.string.status_protractor4,Ctx.ctx.getHexColor(R.color.tool_item))

           extreme1 == null ->
               str(R.string.status_protractor5,Ctx.ctx.getHexColor(R.color.tool_item))

           !draggingPoint ->
               str(R.string.status_protractor6,Ctx.ctx.getHexColor(R.color.tool_item))

           else -> str(R.string.status_protractor7,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_protractor1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class ProtractorAction
