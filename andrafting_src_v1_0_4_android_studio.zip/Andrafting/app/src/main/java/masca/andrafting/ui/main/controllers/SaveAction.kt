package masca.andrafting.ui.main.controllers

import android.net.Uri
import android.view.InputEvent
import android.view.View
import android.widget.Toast
import masca.andrafting.MAct
import masca.andrafting.R
import masca.andrafting.createFile
import masca.andrafting.html
import masca.andrafting.ui.main.BIN_TYPE
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.str
import java.io.File
import java.io.IOException
import java.io.ObjectOutputStream

class SaveAction( private val saveAs: Boolean = false ): ActionListener
{
    override fun action(view: View?, evt: InputEvent?)
    {
        if ( !saveAs && Ctx.ctx.currentFile != null )
        {
            try
            {
                save( Ctx.ctx.currentFile!! )

                Toast.makeText( MAct.act,
                                str(R.string.toast_saved, Ctx.ctx.currentFile!!.path ?: "" ).html(),
                                Toast.LENGTH_SHORT).show()
            }
            catch ( ex: IOException)
            {
                Toast.makeText( MAct.act, ex.message, Toast.LENGTH_LONG ).show()
            }
            return
        }

        MAct.act.createFile( Uri.EMPTY,
                             BIN_TYPE,
                             if ( Ctx.ctx.currentFile != null )
                                 File(Ctx.ctx.currentFile!!.path ?: "").name ?: ""
                             else "" )
    }

    companion object
    {
        @Throws(IOException::class)
        fun save( uri: Uri )
        {
            // write exercise
            ObjectOutputStream( Ctx.ctx.contentResolver.openOutputStream( uri ) ).use {
                it.writeObject( Ctx.ctx.exercise )
            }
            Ctx.ctx.currentFile = uri
            Ctx.ctx.undoRedoManager.clearAll()
            Ctx.ctx.currentActionForCanvas.value = NoAction().beforeAction()
        }
    }

}  // class SaveAction
