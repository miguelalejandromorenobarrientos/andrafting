package masca.andrafting.ui.main.controllers

import android.graphics.Matrix
import masca.andrafting.*
import masca.andrafting.ui.main.Ctx
import masca.andrafting.ui.main.ExerciseCanvas

class RotationAction: TranslateAction()
{
    override val descOp = R.string.desc_rotation
    override val status1 = R.string.status_rotation1
    override val status2 = R.string.status_rotation2
    override val status3 = R.string.status_rotation3

    override val getMatrix: Matrix
        get() {
            start ?: throw IllegalStateException( "CENTER NOT SET!" )
            val center = start!!
            val endPoint = endPoint( center,
                                     logicalTouchLocation,
                                     Ctx.ctx.fixedAngles,
                                     if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                     else -1f,
                                     if ( Ctx.ctx.useProtractor ) Ctx.ctx.protractorAngle
                                     else -1f )

            val degrees = Math.toDegrees( (endPoint - center).arg().toDouble() ).toFloat()

            return Matrix().apply {
                preTranslate( center.x, center.y )
                preRotate( degrees )
                preTranslate( -center.x, -center.y )
            }
        }

    override fun paintTool(exCanvas: ExerciseCanvas)
    {
        super.paintTool(exCanvas)

        start ?: return

        // draw degrees
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background ).apply {
            textSize = 24f
            pathEffect = null
        }

        val endPoint = endPoint( start!!,
                                 logicalTouchLocation,
                                 Ctx.ctx.fixedAngles,
                                 if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                 else -1f,
                                 if ( Ctx.ctx.useProtractor ) Ctx.ctx.protractorAngle
                                 else -1f )

        exCanvas.usePhysicalViewport {
            val p2 = it.toPhysicalViewport( endPoint )
            it.canvas.drawText( "%.3fº".format( toDegrees360( (endPoint - start!!).arg() ) ),
                                p2.x + toolPaint.textSize, p2.y - toolPaint.textSize, toolPaint )
        }
    }

}  // Class RotationAction
