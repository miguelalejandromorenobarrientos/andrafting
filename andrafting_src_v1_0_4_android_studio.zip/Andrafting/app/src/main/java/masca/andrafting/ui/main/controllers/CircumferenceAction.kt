package masca.andrafting.ui.main.controllers

import android.graphics.PointF
import android.view.InputEvent
import android.view.MotionEvent
import android.view.View
import masca.andrafting.*
import masca.andrafting.ui.main.*

class CircumferenceAction : ActionListener
{
    private lateinit var logicalTouchLocation: PointF
    private lateinit var location: PointF
    private var draggingPointer = false
    private var adjusted = false  // logicalTouchLocation is adjusted to a vertex/point
    private var center: PointF? = null

    override fun beforeAction(): CircumferenceAction
    {
        setStatusBar()

        return this
    }

    override fun action( view: View?, evt: InputEvent? ): Boolean
    {
        view?.performClick()
        view ?: return true
        if (evt !is MotionEvent) return true

        // get canvas
        val exCanvas = if (view is ExerciseCanvas) view else MAct.act.findViewById(R.id.canvas)

        // get location in touch
        location = pointerLocation( evt.location(), exCanvas, evt.getToolType(0) )
        val point = if ( Ctx.ctx.adjustTo ) exCanvas.adjustTo( location )
                    else exCanvas.adjustToPoint( location )
        adjusted = point != null
        logicalTouchLocation = if ( adjusted ) point!! else exCanvas.toLogicalViewport( location )

        // event action
        when ( evt.action )
        {
            MotionEvent.ACTION_DOWN -> {
                draggingPointer = true
            }
            //MotionEvent.ACTION_MOVE -> {}
            MotionEvent.ACTION_UP -> {
                draggingPointer = false

                if ( center == null )  // set center
                    center = logicalTouchLocation
                else  // radius
                {
                    // add segment to exercise
                    var paint = defaultPaint( width = Ctx.ctx.strokeWidth,
                                              color = Ctx.ctx.strokeColor,
                                              cap = Ctx.ctx.cap,
                                              join = Ctx.ctx.join,
                                              dash = Ctx.ctx.dashPathEffect )

                    val shape = ExerciseShape(
                            "",
                            str( R.string.new_circumference ),
                            SerialPath().storeCircle(
                                                    center!!,
                                                    if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                                    else logicalTouchLocation.distance(center!!) ),
                            paint.asSerialPaint( Ctx.ctx.fillColor ) )
                    Ctx.ctx.exercise.add( shape )
                    val undoRedoCircumference = UndoRedoableNewShape(
                                                    shape, Ctx.ctx.exercise.indexOf(shape),
                                                    Ctx.ctx.getString(R.string.new_circumference) )

                    if ( Ctx.ctx.addAuxiliaryShapes )
                    {
                        val transaction = object : UndoRedoTransaction() {
                            override fun getDescription() = "${str(R.string.new_circumference)} ${if (Ctx.ctx.addAuxiliaryShapes) str(R.string.desc_auxiliary_shapes) else ""}"
                        }

                        transaction.add( undoRedoCircumference )

                        paint = defaultPaint( width = Ctx.ctx.pointWidth,
                                              color = Ctx.ctx.pointColor)

                        // add center
                        ExerciseShape("",
                                       str(R.string.new_center_circumference,
                                           Ctx.ctx.getHexColor(R.color.name_item),
                                           elvis(shape.name,"?") ),
                                       SerialPath().storePoint( center!! ),
                                       paint.asSerialPaint()).apply {
                            Ctx.ctx.exercise.add(this)
                            transaction.add( UndoRedoableNewShape(
                                    this, Ctx.ctx.exercise.indexOf(this), "CIRCUMFERENCE CENTER"))
                        }

                        Ctx.ctx.undoRedoManager.addItem( transaction )
                    }
                    else
                        Ctx.ctx.undoRedoManager.addItem( undoRedoCircumference )

                    // update or keep tool
                    Ctx.ctx.currentActionForCanvas.value =
                        (if ( Ctx.ctx.keepTool ) CircumferenceAction() else defaultAction)
                            .beforeAction()
                }
            }
        }

        if ( Ctx.ctx.currentActionForCanvas.value === this )
            setStatusBar()

        exCanvas.invalidate()

        return true
    }

    override fun paintTool( exCanvas: ExerciseCanvas )
    {
        if ( !this::logicalTouchLocation.isInitialized )
            return

        // contrasted paint
        val toolPaint = defaultToolPaint( Ctx.ctx.exercise.background, 3f )

        // draw circle centered in touch
        if ( draggingPointer)
            drawCircleTouch( exCanvas, toolPaint, true, location, logicalTouchLocation, adjusted )

        center ?: return

        // draw circle centered in center
        drawCircleTouch( exCanvas, toolPaint, false, exCanvas.toPhysicalViewport( center!! ) )

        // draw circumference
        val circumference = SerialPath().storeCircle( center!!,
                                             if ( Ctx.ctx.useRuler ) Ctx.ctx.rulerDistanceMul
                                             else ( logicalTouchLocation - center!! ).length()  )
        exCanvas.usePhysicalViewport {
            it.canvas.drawPath( it.transformedShapeToPhysical( circumference ).asPath(), toolPaint )
        }
    }

    private fun setStatusBar()
    {
        val txt = when {

            center == null ->
                str(R.string.status_circumference2,Ctx.ctx.getHexColor(R.color.tool_item))

            else -> str(R.string.status_circumference3,Ctx.ctx.getHexColor(R.color.tool_item))

        }.let {
            "${str(R.string.status_circumference1,Ctx.ctx.getHexColor(R.color.tool_name))}: $it"
        }.html()

        if ( Ctx.ctx.statusBarMsg.value != txt )
        // update
            Ctx.ctx.statusBarMsg.value = txt
    }

}  // class CircumferenceAction
